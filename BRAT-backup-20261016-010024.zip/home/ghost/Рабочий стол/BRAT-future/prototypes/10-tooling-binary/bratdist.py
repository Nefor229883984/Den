#!/usr/bin/env python3
"""Prototype for proposal 10-tooling-binary: hermetic static/cross build.

Standalone: it shells out to the BRAT repo's cli.py for C emission and to a
C compiler for the binary, but changes nothing in the repo. The point is to
prove the seam that `lang/engine/toolchain.py` would own:

    resolve_cc() -> compiler argv
    argv(cfile, out, target, static) -> the exact command line

Run: python3 bratdist.py <file.brat> [--target TRIPLE] [--static] [-o OUT]
"""
import argparse
import hashlib
import os
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_REPO = os.path.abspath(os.path.join(HERE, "..", "..", "..", "BRAT"))
REPO = os.environ.get("BRAT_REPO", DEFAULT_REPO)
ENGINE = os.path.join(REPO, "lang", "engine")
CLI = os.path.join(ENGINE, "cli.py")


def resolve_cc():
    """Return the compiler argv prefix, most capable first, or exit closed.

    Order mirrors the proposal: BRAT_CC override, a real zig (cross + static),
    then clang/cc/gcc (host). Python's `python -m ziglang` is deliberately not
    tried; removing it from the build path is the point of the seam.
    """
    override = os.environ.get("BRAT_CC")
    if override:
        return override.split()
    zig = shutil.which("zig") or os.environ.get("BRAT_ZIG")
    if zig:
        return [zig, "cc"]
    for cc in ("clang", "cc", "gcc"):
        found = shutil.which(cc)
        if found:
            return [found]
    sys.exit("bratdist: no C compiler: set BRAT_CC, or install zig/cc/clang/gcc")


def emit_c(src, cfile):
    # --no-check keeps stdout pure: without it the ownership gate prints to
    # stdout too, and the C file's first line becomes a diagnostic (see
    # proposal section 4.1(2)).
    r = subprocess.run([sys.executable, CLI, "emit-c", "--no-check", src],
                       capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit("bratdist: emit-c failed: %s" % (r.stderr or r.stdout)[-400:])
    with open(cfile, "w", encoding="utf-8") as f:
        f.write(r.stdout)


def compile_binary(cc, cfile, out, target, static):
    argv = list(cc) + ["-O2", "-I", ENGINE]
    if target:
        argv += ["-target", target]
    if static:
        argv += ["-static"]
    argv += [cfile, "-o", out]
    r = subprocess.run(argv, capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit("bratdist: cc failed:\n%s" % (r.stdout + r.stderr)[-1500:])
    return argv


def describe(path):
    """file(1) class, sha256 and byte size -- independent of any BRAT code."""
    kind = subprocess.run(["file", "-b", path], capture_output=True,
                          text=True).stdout.strip()
    with open(path, "rb") as f:
        body = f.read()
    return kind, hashlib.sha256(body).hexdigest(), len(body)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("--target", default=None)
    ap.add_argument("--static", action="store_true")
    ap.add_argument("-o", dest="out", default=None)
    a = ap.parse_args()

    name = os.path.splitext(os.path.basename(a.src))[0]
    tag = name + (("-" + a.target) if a.target else "")
    out = a.out or os.path.join(HERE, "out", tag)
    os.makedirs(os.path.dirname(out), exist_ok=True)

    cc = resolve_cc()
    print("cc:     ", " ".join(cc))
    tmp = tempfile.mkdtemp(prefix="bratdist-")
    cfile = os.path.join(tmp, name + ".c")
    emit_c(a.src, cfile)
    argv = compile_binary(cc, cfile, out, a.target, a.static)
    print("compile:", " ".join(argv))
    kind, digest, size = describe(out)
    print("out:     ", out)
    print("file:    ", kind)
    print("sha256:  ", digest)
    print("size:    ", size, "bytes")


if __name__ == "__main__":
    main()
