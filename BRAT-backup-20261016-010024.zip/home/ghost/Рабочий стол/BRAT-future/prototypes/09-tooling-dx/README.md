# Прототип 09 — tooling-dx

Минимальный рабочий слой инструментов поверх движка BRAT. Читает репу
`/home/ghost/Рабочий стол/BRAT` **только на чтение**; путь можно переопределить
через `BRAT_ENGINE`.

## Что внутри

| файл | роль |
|---|---|
| `diag.py` | глубокий модуль: `check_program` + `to_human`/`to_json`/`to_lsp` + обучающий `CATALOG` |
| `bratdiag.py` | CLI: `check [--json]` \| `explain CODE` \| `lsp` |
| `test_diag.py` | самопроверка: паритет с `brat check`, JSON, LSP-фрейминг |

## Запуск

```bash
cd "BRAT-future/prototypes/09-tooling-dx"

# 1. Паритет + протокол + сервер: 24 ассерта
python -X utf8 test_diag.py

# 2. Человекочитаемая диагностика (та же, что у `brat check`)
python -X utf8 bratdiag.py check "../../../BRAT/lang/examples/own_bad.brat"

# 3. Машинный протокол v1
python -X utf8 bratdiag.py check "../../../BRAT/lang/examples/own_bad.brat" --json

# 4. Объяснение кода ошибки
python -X utf8 bratdiag.py explain E0499

# 5. Языковой сервер по stdio (LSP)
python -X utf8 bratdiag.py lsp
```

## Подключение к Neovim (проверка, что это настоящий LSP)

```lua
-- 'filetype' для .brat задаётся отдельно; lsp работает с любым буфером file://
vim.lsp.start({
  name = "brat",
  cmd = { "python", "-X", "utf8", "/абсолютный/путь/bratdiag.py", "lsp" },
  root_dir = vim.fn.getcwd(),
})
```

Ожидаемое: диагностики при открытии (`publishDiagnostics`), hover над строкой с
ошибкой показывает «почему» из каталога, `documentSymbol` даёт outline
функций/енумов.

## Что это доказывает

1. Диагностика **уже структурная** — протокол и LSP это адаптеры, а не второй
   компилятор.
2. Тёплая проверка (без spawn процесса) на порядки быстрее холодного
   `brat check`: 0.001-0.03 с против 0.39-0.48 с на обычных файлах.
3. Обучающий слой (код + «почему» + «fix») питает и `brat explain`, и hover
   редактора из одного `CATALOG`.

## Числа для перепроверки

```bash
python -X utf8 - <<'PY'
import time, subprocess, sys, os
CLI = "/home/ghost/Рабочий стол/BRAT/lang/engine/cli.py"
EX = "/home/ghost/Рабочий стол/BRAT/lang/examples"
def tsub(a, n=3):
    best = 9
    for _ in range(n):
        s = time.perf_counter()
        subprocess.run([sys.executable, "-X", "utf8", CLI] + a, capture_output=True)
        best = min(best, time.perf_counter() - s)
    return best
print("cli check hello  : %.3fs" % tsub(["check", os.path.join(EX, "hello.brat")]))
sys.path.insert(0, ".")
import diag
src = open(os.path.join(EX, "hello.brat"), encoding="utf-8").read()
diag.check_program(os.path.join(EX, "hello.brat"), src)  # warm the engine
s = time.perf_counter()
for _ in range(5):
    diag.check_program(os.path.join(EX, "hello.brat"), src)
print("warm check hello : %.3fs" % ((time.perf_counter() - s) / 5))
PY
```
