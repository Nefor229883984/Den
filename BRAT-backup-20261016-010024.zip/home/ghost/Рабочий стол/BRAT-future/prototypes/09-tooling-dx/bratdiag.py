"""`bratdiag` -- the prototype tooling surface over the BRAT engine.

Three commands, all reading the same `diag.py`:

  bratdiag check FILE [--json]   one-shot check; --json is the editor protocol
  bratdiag explain CODE          the teaching text for a diagnostic code
  bratdiag lsp                   a language server on stdin/stdout

Nothing here changes the engine. The point of the prototype is that the whole
surface is an adapter over modules that already exist and already return
structured errors -- so the cost of the DX story is a protocol, not a rewrite.
"""

import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import diag  # noqa: E402


def _read(path, text=None):
    if text is not None:
        return text
    try:
        with open(path, encoding="utf-8") as f:
            return f.read()
    except OSError as e:
        sys.stderr.write("bratdiag: cannot read %s: %s\n" % (path, e))
        return ""


def cmd_check(args):
    as_json = "--json" in args
    files = [a for a in args if not a.startswith("--")]
    if not files:
        sys.stderr.write("usage: bratdiag check FILE [--json]\n")
        return 2
    path = files[0]
    src = _read(path)
    diags, _prog = diag.check_program(path, src)
    if as_json:
        sys.stdout.write(diag.to_json(path, diags) + "\n")
    else:
        body = diag.to_human(path, src, diags)
        if body:
            sys.stdout.write(body + "\n")
        sys.stdout.write("%s: %d error(s), %d warning(s)\n"
                         % (path, sum(1 for d in diags if d["severity"] == "error"),
                            sum(1 for d in diags if d["severity"] == "warning")))
    return 1 if diag.has_errors(diags) else 0


def cmd_explain(args):
    if not args:
        sys.stderr.write("usage: bratdiag explain CODE\n")
        return 2
    code = args[0].upper()
    got = diag.explain(code)
    if got is None:
        sys.stdout.write("%s: no such code\n" % code)
        return 1
    title, why, fix = got
    sys.stdout.write("%s: %s\n\n%s\n\nfix: %s\n" % (code, title, why, fix))
    return 0


# --- language server --------------------------------------------------------

class Lsp:
    """Minimal LSP over stdio. FULL text sync, one open-buffer table."""

    def __init__(self):
        self.docs = {}
        self.diags = {}          # path -> [Diagnostic], for hover

    def log(self, msg):
        sys.stderr.write("brat-lsp: %s\n" % msg)
        sys.stderr.flush()

    def send(self, obj):
        body = json.dumps(obj).encode("utf-8")
        sys.stdout.buffer.write(b"Content-Length: %d\r\n\r\n" % len(body))
        sys.stdout.buffer.write(body)
        sys.stdout.buffer.flush()

    def reply(self, rid, result):
        self.send({"jsonrpc": "2.0", "id": rid, "result": result})

    def notify(self, method, params):
        self.send({"jsonrpc": "2.0", "method": method, "params": params})

    def loop(self):
        while True:
            msg = self.read_message()
            if msg is None:
                return 0
            self.handle(msg)

    def read_message(self):
        length = None
        while True:
            line = sys.stdin.buffer.readline()
            if not line:
                return None
            line = line.strip()
            if not line:
                break
            if line.lower().startswith(b"content-length:"):
                length = int(line.split(b":", 1)[1])
        if length is None:
            return None
        return json.loads(sys.stdin.buffer.read(length).decode("utf-8"))

    def handle(self, msg):
        method = msg.get("method")
        rid = msg.get("id")
        params = msg.get("params") or {}
        if method == "initialize":
            self.reply(rid, {"capabilities": {
                "textDocumentSync": 1,          # FULL
                "hoverProvider": True,
                "documentSymbolProvider": True,
            }, "serverInfo": {"name": "brat-lsp", "version": "0.0.1"}})
        elif method in ("initialized",):
            pass
        elif method in ("textDocument/didOpen", "textDocument/didChange"):
            doc = params.get("textDocument", {})
            uri = doc.get("uri", "")
            text = self.text_of(params, doc)
            path = self.uri_path(uri)
            self.docs[path] = text
            self.publish(path, text)
        elif method == "textDocument/hover":
            self.hover(rid, params)
        elif method == "textDocument/documentSymbol":
            self.symbols(rid, params)
        elif method == "shutdown":
            self.reply(rid, None)
        elif method == "exit":
            raise SystemExit(0)

    def text_of(self, params, doc):
        changes = params.get("contentChanges")
        if changes:
            return changes[-1].get("text", "")
        return doc.get("text", "")

    def uri_path(self, uri):
        if uri.startswith("file://"):
            return uri[len("file://"):]
        return uri

    def publish(self, path, text):
        diags, _prog = diag.check_program(path, text)
        self.diags[path] = diags
        self.notify("textDocument/publishDiagnostics",
                    {"uri": "file://" + os.path.abspath(path),
                     "diagnostics": diag.to_lsp(path, diags)})

    def hover(self, rid, params):
        path = self.uri_path(params["textDocument"]["uri"])
        ln = params["position"]["line"] + 1
        for d in self.diags.get(path, []):
            if d["line"] == ln:
                got = diag.explain(d["code"])
                body = "**%s** `%s`\n\n%s" % (d["code"], d["message"], got[1]) if got \
                    else d["message"]
                self.reply(rid, {"contents": {"kind": "markdown", "value": body}})
                return
        self.reply(rid, None)

    def symbols(self, rid, params):
        path = self.uri_path(params["textDocument"]["uri"])
        text = self.docs.get(path, "")
        _diags, prog = diag.check_program(path, text)
        self.reply(rid, [{"name": s["name"], "kind": s["kind"],
                          "range": self.zero_range(s["line"])}
                         for s in diag.outline(prog)] if prog else [])

    @staticmethod
    def zero_range(line):
        return {"start": {"line": line, "character": 0},
                "end": {"line": line, "character": 0}}


def cmd_lsp(_args):
    server = Lsp()
    server.log("ready")
    return server.loop()


def main(argv):
    if len(argv) < 2:
        sys.stderr.write("usage: bratdiag {check|explain|lsp} ...\n")
        return 2
    cmd = argv[1]
    if cmd == "check":
        return cmd_check(argv[2:])
    if cmd == "explain":
        return cmd_explain(argv[2:])
    if cmd == "lsp":
        return cmd_lsp(argv[2:])
    sys.stderr.write("bratdiag: unknown command %r\n" % cmd)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
