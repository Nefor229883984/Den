"""Structured diagnostics: the one owner of "what is wrong and why".

The BRAT engine already builds the data -- `borrow.py:15` and `typer.py:14`
each have an `Errs` accumulator, and both append `(line, message, note)` tuples.
What the engine does NOT have is a single place that decides how that data
reaches a person or an editor. Today there are three renderers that can drift:

  * `borrow.report`   (borrow.py:1281) -- `path:line: error: msg` + snippet
  * `typer.report`    (typer.py:23)    -- the same shape, a second copy
  * `cli.syntax_error` (cli.py:205)    -- a third, ad-hoc parse-error shape

An editor (LSP) that re-implements any of these shows the user a different set
of errors than `brat check` -- a parity violation in the diagnostic layer, which
is exactly what the language exists to avoid one layer down. So this module is
the *only* code that turns an internal error tuple into human text, JSON, or an
LSP Diagnostic. `to_human` reproduces the CLI byte-for-byte, which is how the
parity is tested (see test_diag.py).

The catalog adds the "why": a stable code per message shape, a one-paragraph
explanation, and a fix hint. `brat explain E0499` and LSP hover both read it.
This is the teaching layer the newcomer rule (BRIEF.md:21) needs: the ownership
guarantee is only as good as the sentence that explains the rejection.

Reads the BRAT checkout read-only; never writes into it.
"""

import importlib.util
import json
import os
import re
import sys

BRAT_ENGINE = os.environ.get(
    "BRAT_ENGINE",
    "/home/ghost/Рабочий стол/BRAT/lang/engine",
)

_MODS = {}


def _load(tag, path):
    spec = importlib.util.spec_from_file_location(tag, path)
    if spec is None or spec.loader is None:
        raise ImportError("cannot load " + path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def engine():
    """The BRAT engine, loaded once and reused.

    A process that answers many checks (the language server) must not pay
    `import` per request; this cache is the whole reason `brat lsp` beats a
    fresh `brat check` process. `own.load_brat` is rebound to the already-loaded
    interpreter, mirroring cli.py:274.
    """
    if _MODS:
        return _MODS
    if BRAT_ENGINE not in sys.path:
        sys.path.insert(0, BRAT_ENGINE)
    brat = _load("dx_brat", os.path.join(BRAT_ENGINE, "brat.py"))
    own = _load("dx_borrow", os.path.join(BRAT_ENGINE, "borrow.py"))
    tp = _load("dx_typer", os.path.join(BRAT_ENGINE, "typer.py"))
    own.load_brat = lambda path=None: brat
    tp.load_brat = lambda path=None: brat
    _MODS.update(brat=brat, own=own, typer=tp)
    return _MODS


# --- the teaching catalog ---------------------------------------------------
# code -> (title, why, fix). Regexes match the message the engine already emits,
# so no checker code changes to gain an explanation. Rust codes are used where
# the diagnostic is the exact analogue Rust has; BRAT-specific ones get B-codes
# so a Rust developer is not told a lie about compatibility.
CATALOG = [
    (re.compile(r"^use of undeclared var"), "B0101",
     "Name resolution",
     "The checker builds an environment per function: `let` bindings, parameters, "
     "`for`/`match` bindings, and functions from `fn`/`impl`. A name from another "
     "file is only visible through `import`.",
     "Check the spelling, declare it with `let`, or `import` the file that has it."),
    (re.compile(r"escapes via return"), "E0515",
     "Borrow escapes by return",
     "A `ref` is a view, not a value. A function that returns a view would hand the "
     "caller a pointer into a local that dies when the function returns. BRAT forbids "
     "this syntactically, so it is a hard error, not a warning.",
     "Return a value (drop the `ref`), or take `move` to transfer ownership out."),
    (re.compile(r"escapes via spawn"), "B0521",
     "Borrow escapes into a thread",
     "`spawn { }` copies the frame it captures, so a `ref` captured there could "
     "outlive the value it points at once the spawning scope ends.",
     "Copy the value in (`x.copy()`), or pass ownership with `move x`."),
    (re.compile(r"double mut borrow"), "E0499",
     "Two writers at once",
     "A mutable place is exclusive: while one name is a `mut` borrow of `m`, no second "
     "reader or writer of `m` may exist. Vivek's Law of Exclusivity -- one writer XOR "
     "many readers. The `note:` line names the first borrow, which is the one to end.",
     "Give the second name its own storage (`m.copy()`), or sequence the two uses so "
     "the first borrow ends before the second begins."),
    (re.compile(r"^(assign to immutable|cannot mutate immutable)"), "E0596",
     "Assignment to an immutable place",
     "BRAT is Rust-semantic: `let x = ...` is immutable. Assignment, and mutation "
     "through a builtin (`push`, `set`, `del`, `sort`, `ins`, `sort_by`), require the "
     "place to be declared `let mut`. `const` can never be assigned.",
     "Declare the binding `let mut x = ...` at its first `let`."),
    (re.compile(r"^use of moved"), "E0382",
     "Use after move",
     "`move x` transfers ownership; after it, `x` is dead. This is the check that has "
     "no runtime backstop yet -- `move` is a static annotation (SPEC.md 3), so the "
     "checker is the only thing standing between you and a silent alias.",
     "Use the new owner, or clone with `.copy()` if you need the original as well."),
    (re.compile(r"(move|moved) while borrowed"), "E0505",
     "Move out from under a live borrow",
     "You cannot move a value while something is still borrowing it: the mover would "
     "destroy the place the borrow points at. End the borrow first, then move.",
     "Let the borrow's last use happen before the `move`, or copy instead of move."),
    (re.compile(r"^method name .* is reserved"), "B0200",
     "Reserved method name",
     "`push`, `pop`, `sort`, `sort_by`, `ins`, `del`, `set` are the builtin mutators. "
     "An `impl` method may not shadow one, because then `v.push(x)` would mean two "
     "different things at two call sites.",
     "Rename the method."),
]

_BY_CODE = {code: (title, why, fix) for (_rx, code, title, why, fix) in CATALOG}


def classify(message):
    """The stable code for an engine message, or B0000 when no rule matches."""
    for rx, code, _title, _why, _fix in CATALOG:
        if rx.search(message):
            return code
    return "B0000"


def explain(code):
    """Title, why, fix for a code -- the body of `brat explain CODE`."""
    return _BY_CODE.get(code)


# --- the diagnostic type ----------------------------------------------------

def _mk(path, line, severity, message, note=None):
    code = classify(message) if severity != "warning" else "W0000"
    return {
        "file": _rel(path),
        "line": line,
        "severity": severity,
        "code": code,
        "message": message,
        "note": note,
    }


def _rel(path):
    """Repository-relative path, so JSON output does not leak the home dir."""
    try:
        return os.path.relpath(path)
    except ValueError:
        return path


def check_program(path, src, extra=None):
    """Run the full static pipeline on `src` and return [Diagnostic].

    Returns diagnostics only; a caller that wants an exit code uses
    `has_errors`. Parse errors are folded into the same list so the editor and
    the CLI report one stream, not two.
    """
    eng = engine()
    brat, own, tp = eng["brat"], eng["own"], eng["typer"]
    diags = []
    try:
        prog = brat.parse_prog(brat.Cur(brat.lex(src)))
    except SyntaxError as e:
        ln = _parse_line(e)
        diags.append(_mk(path, ln, "error", str(e)))
        return diags, None
    errs, warns = own.check(prog, extra)
    for entry in errs:
        ln, m = entry[0], entry[1]
        rel = entry[2] if len(entry) > 2 else None
        note = {"line": rel[0], "message": rel[1]} if rel else None
        diags.append(_mk(path, ln, "error", m, note))
    for entry in warns:
        ln, m = entry[0], entry[1]
        diags.append(_mk(path, ln, "warning", m))
    terrs = tp.check(prog, extra)
    for ln, m in terrs:
        diags.append(_mk(path, ln, "error", m))
    return diags, prog


def _parse_line(exc):
    m = re.search(r"\bat line (\d+)\s*\Z", str(exc))
    return int(m.group(1)) if m else None


def has_errors(diags):
    return any(d["severity"] == "error" for d in diags)


# --- renderers: one source, three targets ----------------------------------

def to_human(path, src, diags):
    """Reproduce `brat check` byte-for-byte (the parity anchor)."""
    lines = src.splitlines()
    out = []
    for d in diags:
        ln, kind = d["line"], d["severity"]
        if ln is not None and 1 <= ln <= len(lines):
            out.append("%s:%d: %s: %s" % (path, ln, kind, d["message"]))
            out.append("  | " + lines[ln - 1].strip())
        else:
            out.append("%s: %s: %s" % (path, kind, d["message"]))
        note = d.get("note")
        if note:
            rln, rm = note["line"], note["message"]
            if rln is not None and 1 <= rln <= len(lines):
                out.append("%s:%d: note: %s" % (path, rln, rm))
                out.append("  | " + lines[rln - 1].strip())
            else:
                out.append("%s: note: %s" % (path, rm))
    return "\n".join(out)


def to_json(path, diags):
    """The machine protocol. version is explicit so a client can refuse a bump."""
    doc = {
        "version": 1,
        "file": _rel(path),
        "diagnostics": [
            {
                "severity": d["severity"],
                "code": d["code"],
                "line": d["line"],
                "message": d["message"],
                "note": d["note"],
            }
            for d in diags
        ],
        "summary": {
            "errors": sum(1 for d in diags if d["severity"] == "error"),
            "warnings": sum(1 for d in diags if d["severity"] == "warning"),
        },
    }
    return json.dumps(doc, ensure_ascii=False)


def to_lsp(path, diags):
    """LSP Diagnostic objects: 0-based lines, integer severity, relatedInformation."""
    out = []
    for d in diags:
        ln = (d["line"] - 1) if d["line"] else 0
        item = {
            "range": {"start": {"line": ln, "character": 0},
                      "end": {"line": ln, "character": 1_000_000}},
            "severity": 1 if d["severity"] == "error" else 2,
            "code": d["code"],
            "source": "brat",
            "message": d["message"],
        }
        note = d.get("note")
        if note and note["line"]:
            rln = note["line"] - 1
            item["relatedInformation"] = [{
                "location": {
                    "uri": "file://" + os.path.abspath(path),
                    "range": {"start": {"line": rln, "character": 0},
                              "end": {"line": rln, "character": 1_000_000}},
                },
                "message": note["message"],
            }]
        out.append(item)
    return out


def outline(prog):
    """Top-level symbols from an already-parsed program, for documentSymbol.

    Cheap because the parser did the work: `prog[1]` is the statement list and
    each `fn`/`enum`/`trait`/`impl` node names itself. No second parser.
    """
    if not isinstance(prog, tuple) or len(prog) < 2:
        return []
    kinds = {"fn": 12, "enum": 10, "trait": 11, "struct": 23, "impl": 5}
    out = []
    for s in prog[1]:
        node = s[1] if (isinstance(s, tuple) and s and s[0] == "pub") else s
        if not (isinstance(node, tuple) and node):
            continue
        k = node[0]
        if k not in kinds:
            continue
        ln = engine()["own"]._LINES.get(id(node))
        name = node[1] if isinstance(node[1], str) else (node[1] or "?")
        out.append({"name": str(name), "kind": kinds[k], "line": (ln or 1) - 1})
    return out
