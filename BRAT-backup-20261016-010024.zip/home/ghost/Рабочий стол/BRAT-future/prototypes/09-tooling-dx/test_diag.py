"""Self-check for the tooling prototype. Asserts, no framework.

Run: python -X utf8 test_diag.py
Proves three claims the proposal rests on:
  1. the structured pipeline finds exactly the diagnostics `brat check` prints
     (parity -- a positive control on every negative case);
  2. the JSON protocol is stable and carries a teaching code per diagnostic;
  3. the language server answers `initialize` over real LSP framing.
"""

import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import diag  # noqa: E402

BRAT = "/home/ghost/Рабочий стол/BRAT"
CLI = os.path.join(BRAT, "lang", "engine", "cli.py")
EX = os.path.join(BRAT, "lang", "examples")

n = 0


def check(cond, msg):
    global n
    assert cond, msg
    n += 1


def check_program_messages(path):
    src = open(path, encoding="utf-8").read()
    diags, _ = diag.check_program(path, src)
    return diags


def cli_report(path):
    p = subprocess.run([sys.executable, "-X", "utf8", CLI, "check", path],
                       capture_output=True, text=True, timeout=120)
    return p.stdout + p.stderr


# --- 1. parity with `brat check`, positive control first --------------------
good = os.path.join(EX, "own_good.brat")
gd = check_program_messages(good)
check(gd == [], "own_good must be clean, got %r" % gd)

bad = os.path.join(EX, "own_bad.brat")
bd = check_program_messages(bad)
check(sum(1 for d in bd if d["severity"] == "error") == 4,
      "own_bad wants 4 errors, got %d" % len(bd))
check(sum(1 for d in bd if d["severity"] == "warning") == 1,
      "own_bad wants 1 warning")
# every message the prototype reports must appear in the CLI's own output.
out = cli_report(bad)
for d in bd:
    check(d["message"] in out, "message not in cli output: %r" % d["message"])
check("4 error(s)" in out and "1 warning(s)" in out, "cli summary drift")

# and the note with its line survives the round trip
e0499 = [d for d in bd if d["code"] == "E0499"]
check(len(e0499) == 1 and e0499[0]["note"]["line"] == 7,
      "E0499 must carry note line 7, got %r" % e0499)

# --- 2. JSON protocol -------------------------------------------------------
doc = json.loads(diag.to_json(bad, bd))
check(doc["version"] == 1, "json wants version 1")
check(doc["summary"] == {"errors": 4, "warnings": 1}, "json summary drift")
check(all(d["code"] for d in doc["diagnostics"]), "every diag needs a code")

lsp = diag.to_lsp(bad, bd)
check(all(d["range"]["start"]["line"] >= 0 for d in lsp), "lsp lines are 0-based")
check(lsp[1]["relatedInformation"][0]["message"] == "first borrow `a1` here",
      "lsp must carry the note as relatedInformation")

# --- 3. teaching catalog ----------------------------------------------------
for code in ("E0499", "E0515", "E0382", "E0505", "B0101", "E0596"):
    check(diag.explain(code) is not None, "catalog missing %s" % code)

# --- 4. the server answers initialize over real framing ---------------------
proc = subprocess.Popen([sys.executable, "-X", "utf8",
                         os.path.join(HERE, "bratdiag.py"), "lsp"],
                        stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE)
req = json.dumps({"jsonrpc": "2.0", "id": 1, "method": "initialize",
                  "params": {}}).encode()


def frame(body):
    return b"Content-Length: %d\r\n\r\n" % len(body) + body


proc.stdin.write(frame(req))
proc.stdin.flush()
header = proc.stdout.readline()
check(header.startswith(b"Content-Length:"), "lsp header, got %r" % header)
length = int(header.split(b":")[1])
proc.stdout.readline()  # blank line
resp = json.loads(proc.stdout.read(length))
check(resp["id"] == 1 and "capabilities" in resp["result"],
      "lsp initialize response, got %r" % resp)
check(resp["result"]["capabilities"]["documentSymbolProvider"] is True,
      "lsp wants documentSymbol")
proc.stdin.close()
proc.wait(timeout=10)

print("TOOLING-DX ALL GREEN (%d asserts)" % n)
