"""Ownership schedule: what the C emitter would place, and where it comes from.

The proposal's Stage 2 says the compiler releases a value at its death point,
using liveness the checker already computes. This script shows that the facts
are already inside borrow.py, and prints the C fragments the emitter would add.

It reuses the real checker primitives -- it does not reimplement the analysis:
  borrow.used_in_stmt   (borrow.py:400)
  borrow.COPY_ANNS      (borrow.py:42)
The liveness loop below is the four lines of borrow.walk_block
(borrow.py:767-771); the proposal lifts that value out of walk_block as a
return value instead of recomputing it here. The borrow/copy classification
is a stand-in for the checker's `decl` record (borrow.py:921-925); the real
emitter would read the record the checker already builds.

Read-only: imports the BRAT engine, never writes to the BRAT repo.
"""
import importlib.util
import os
import sys

ENGINE = "/home/ghost/Рабочий стол/BRAT/lang/engine"
sys.path.insert(0, ENGINE)

from brat.lexer import Cur, lex            # noqa: E402
from brat.parser import parse_prog        # noqa: E402

_spec = importlib.util.spec_from_file_location(
    "borrow_mod", os.path.join(ENGINE, "borrow.py"))
borrow = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(borrow)


def death_points(body):
    """name -> index of the statement holding its last use (borrow.py:767-771)."""
    last = {}
    for i, s in enumerate(body):
        for v in borrow.used_in_stmt(s, []):
            last[v] = i
    return last


def classify_lets(body):
    """Ownership of each binding: 'copy', 'borrow' or 'owned'.

    Stand-in for the checker's decl[i] record. `let y = x` over a bare place is
    a borrow (SPEC section 3); an annotated Copy type is a copy; anything else
    the binding owns and must be dropped.
    """
    kind = {}
    for s in body:
        if not (isinstance(s, tuple) and s and s[0] == "let"):
            continue
        name, e = s[1], s[2]
        ann = s[5] if len(s) > 5 else None
        if ann in borrow.COPY_ANNS:
            kind[name] = "copy"
        elif isinstance(e, tuple) and e and e[0] == "var":
            kind[name] = "borrow"
        elif isinstance(e, tuple) and e and e[0] in ("num", "bool"):
            kind[name] = "copy"
        else:
            kind[name] = "owned"
    return kind


def sub_blocks(s):
    """Bodies nested one level down, so the schedule follows the scoping that
    borrow.walk_block (borrow.py:766) itself uses."""
    k = s[0]
    if k == "forrange":
        return [s[4]]
    if k == "foriter":
        return [s[3]]
    if k == "while":
        return [s[2]]
    if k == "if":
        return [s[2]] + ([s[3]] if isinstance(s[3], list) else [])
    if k == "try":
        return [s[1], s[2]]
    return []


def emit_block(body, kind, last, indent):
    for i, s in enumerate(body):
        frag = []
        dropped = set()
        if isinstance(s, tuple) and s and s[0] == "set":
            tgt = s[1].split(".", 1)[0]
            if kind.get(tgt) == "owned":
                frag.append("vdrop(%s);  /* overwrite: old payload dies here */" % tgt)
                dropped.add(tgt)
        for name in sorted(n for n, k in kind.items() if k == "owned"):
            if last.get(name) == i and name not in dropped:
                frag.append("vdrop(%s);  /* last use */" % name)
        line = indent + "%2d %-10s" % (i, s[0])
        print(line + ("  ->  " + " ".join(frag) if frag else ""))
        for sub in sub_blocks(s):
            sub_kind = dict(kind, **classify_lets(sub))
            emit_block(sub, sub_kind, death_points(sub), indent + "  ")


def emit_schedule(fn_body, label):
    kind = classify_lets(fn_body)
    print("=== %s ===" % label)
    print("owned bindings: %s" % (sorted(n for n, k in kind.items() if k == "owned") or "none"))
    emit_block(fn_body, kind, death_points(fn_body), "  ")
    print()


REPRO = '''
fn main() -> i64 {
  let mut s = ""
  for i in 0..8000 { s = s + "x" }
  print(len(s))
  return 0
}
'''

BORROW = '''
fn main() -> i64 {
  let s = "abc"
  let a = s
  print(len(a))
  print(len(s))
  return 0
}
'''

MOVE = '''
fn take(s: move str) -> i64 { return len(s) }
fn main() -> i64 {
  let x = "hello"
  let n = take(move x)
  return n
}
'''


def parse_fn(src):
    prog = parse_prog(Cur(lex(src)))
    fn = [s for s in prog[1] if isinstance(s, tuple) and s[0] == "fn"]
    return fn[-1][3]


if __name__ == "__main__":
    emit_schedule(parse_fn(REPRO), "leak repro: s = s + \"x\"")
    emit_schedule(parse_fn(BORROW), "borrow: let a = s (no drop while a is live)")
    emit_schedule(parse_fn(MOVE), "move: take(move x)")
