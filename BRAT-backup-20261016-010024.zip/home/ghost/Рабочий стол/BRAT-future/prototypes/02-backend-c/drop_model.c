/* Ownership-driven reclamation, modelled.
 *
 * This is the runtime shape the proposal asks codegen_c to emit for:
 *
 *     let mut s = ""
 *     for i in 0..N { s = s + "x" }
 *
 * The only difference from today's crt.h is one line the *compiler* adds:
 * when `s` is overwritten, the old payload of `s` is released, because the
 * ownership checker proved no live borrow of it remains (borrow.py:766-793
 * already computes exactly that liveness). No GC, no refcount on the hot path.
 *
 * Build:  cc -O2 -o drop_model drop_model.c
 * Run:    ./drop_model            (default N = 8000)
 *         ./drop_model 100000
 *
 * What it proves: peak live payload is O(1) in N, while the current emitter
 * (which never frees) grows as N^2/2. See docs/ARCHITECTURE.md section 2.4.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Live-payload accounting, so the claim "flat" is a number and not a vibe. */
static long live_bytes = 0;
static long peak_bytes = 0;

static void *o_alloc(size_t n) {
    size_t *h = (size_t *)malloc(sizeof(size_t) + n);
    if (!h) { fputs("oom\n", stderr); exit(1); }
    *h = n;
    live_bytes += (long)n;
    if (live_bytes > peak_bytes) peak_bytes = live_bytes;
    return (void *)(h + 1);
}

static void o_free(void *p) {
    if (!p) return;
    size_t *h = (size_t *)p - 1;
    live_bytes -= (long)*h;
    free(h);
}

typedef enum { V_STR, V_MOVED } VTag;

typedef struct {
    VTag tag;
    char *str;   /* owned when V_STR; NULL when V_MOVED */
} Val;

static Val vstr(const char *s) {
    size_t n = strlen(s);
    char *p = (char *)o_alloc(n + 1);
    memcpy(p, s, n + 1);
    return (Val){V_STR, p};
}

/* vdrop is the single release primitive. A moved value releases nothing --
 * this is what makes the runtime backstop for a checker hole, and what makes
 * a double release a no-op instead of a use-after-free. */
static void vdrop(Val v) {
    if (v.tag == V_STR) o_free(v.str);
}

/* vmove is `move x` at runtime (SPEC section 12 step 1): the payload leaves
 * the source, the source becomes V_MOVED. Today this is a plain read
 * (codegen_c.py:780-781), so the checker is the only thing preventing aliasing. */
static Val vmove(Val *src) {
    Val v = *src;
    src->tag = V_MOVED;
    src->str = NULL;
    return v;
}

static Val vadd(Val a, Val b) {
    size_t la = a.tag == V_STR ? strlen(a.str) : 0;
    size_t lb = b.tag == V_STR ? strlen(b.str) : 0;
    char *out = (char *)o_alloc(la + lb + 1);
    if (la) memcpy(out, a.str, la);
    if (lb) memcpy(out + la, b.str, lb);
    out[la + lb] = 0;
    return (Val){V_STR, out};
}

/* The leak repro, with the drop the compiler inserts. Each statement's
 * temporaries die at the end of the statement; `s`'s old payload dies on the
 * assignment that overwrites it. */
static long leak_loop(long n) {
    Val s = vstr("");
    for (long i = 0; i < n; i++) {
        Val x = vstr("x");            /* temp */
        Val t = vadd(s, x);           /* t = s + x , fresh owner */
        vdrop(x);                     /* temp x dies */
        vdrop(s);                     /* ownership: s is not borrowed here */
        s = t;                        /* s now owns t's payload */
    }
    long len = strlen(s.str);
    vdrop(s);                         /* s dies at scope exit */
    return len;
}

/* A borrow is live, so the release is deferred. `let a = s` is a borrow
 * (SPEC section 3); dropping s on the next line would dangle `a`. The
 * checker reports a live borrow, the emitter emits no drop. */
static void borrow_gate_demo(void) {
    Val s = vstr("abc");
    Val a = s;                        /* let a = s : borrow, no copy */
    Val x = vstr("x");
    Val t = vadd(s, x);               /* t = s + x */
    vdrop(x);
    /* no vdrop(s): `a` is live. (If the emitter dropped here, `a` would dangle.) */
    long through_a = (long)strlen(a.str);
    printf("borrow_gate: len(a)=%ld\n", through_a);
    vdrop(t);
    vdrop(s);                         /* both `a` and `s` are dead now */
}

static void move_demo(void) {
    Val s = vstr("hello");
    Val d = vmove(&s);                /* move s -> d */
    vdrop(s);                         /* no-op: s is V_MOVED */
    long n = (long)strlen(d.str);
    printf("move_demo: d=%s len=%ld\n", d.str, n);
    vdrop(d);
}

int main(int argc, char **argv) {
    long n = argc > 1 ? atol(argv[1]) : 8000;
    long before = live_bytes;
    long len = leak_loop(n);
    long after = live_bytes;
    printf("leak_loop n=%ld len=%ld\n", n, len);
    printf("live_after=%ld peak=%ld leaked=%ld\n", after, peak_bytes, after - before);
    borrow_gate_demo();
    move_demo();
    printf("final_live=%ld (0 means every owner was released)\n", live_bytes);
    /* Today's emitter never frees: leaked would be ~ n*n/2 bytes. */
    if (after != before) { printf("FAIL: leak_loop leaked\n"); return 1; }
    if (live_bytes != 0) { printf("FAIL: not all owners released\n"); return 1; }
    printf("OK: flat memory, no GC\n");
    return 0;
}
