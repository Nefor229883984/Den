"""Prototype: a complete ownership diagnostic from the data borrow.py already has.

The strict position claims a diagnostic can carry four things the current output
lacks -- a stable code, the offending `file:LINE`, the site to fix, and a
machine-applicable edit -- without touching a line of checker logic. This file
proves it: it calls `borrow.check()` unchanged, classifies each `(line, msg, rel)`
record it returns, and renders the proposed form. For the cases where the fix is
mechanical it applies the edit and re-runs `check` to prove the suggestion is
correct (a fix that does not make the program pass is a lie with a code number).

Run:  python3 diag.py
"""

import importlib.util
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
_CANDIDATES = [
    os.environ.get("BRAT_REPO"),
    os.path.expanduser("~/Рабочий стол/BRAT"),
    "/home/ghost/Рабочий стол/BRAT",
]
BRAT_REPO = next((c for c in _CANDIDATES if c and os.path.isdir(os.path.join(c, "lang", "engine"))), None)
if BRAT_REPO is None:
    raise SystemExit("set BRAT_REPO to the BRAT checkout")
ENGINE = os.path.join(BRAT_REPO, "lang", "engine")
sys.path.insert(0, ENGINE)

from brat.lexer import Cur, lex            # noqa: E402
from brat.parser import parse_prog         # noqa: E402
import borrow                              # noqa: E402  (the checker, unchanged)


class Label:
    """A secondary location: `file:LINE` plus the source line to show."""

    def __init__(self, line, text):
        self.line = line
        self.text = text


class Fix:
    """A machine-applicable edit: at `line`, insert `insert` at column `col`."""

    def __init__(self, line, col, insert):
        self.line = line
        self.col = col
        self.insert = insert


class Diag:
    def __init__(self, code, line, message, labels, helps, fix):
        self.code = code
        self.line = line
        self.message = message
        self.labels = labels or []
        self.helps = helps or []
        self.fix = fix


# ---------------------------------------------------------------------------
# Classification: message text -> code + labels + help + fix.
#
# This is the one new artifact the strict checker needs. It is a table, not
# logic, because borrow.py already emits the fix site as its `rel` note -- the
# only thing missing is a code and a sentence telling the reader what to do.
# ---------------------------------------------------------------------------

_MOVED = re.compile(r"^use of moved `([^`]+)`")
_MOVE_BORROWED = re.compile(r"^cannot move `([^`]+)` while borrowed by `([^`]+)`")
_DOUBLE_MUT = re.compile(r"^double mut borrow of `([^`]+)`")
_IMMUTABLE = re.compile(r"^(?:assign to immutable|assign to const) `([^`]+)`")
_NO_MUT_METHOD = re.compile(r"^cannot mutate immutable `([^`]+)`")
_LOE = re.compile(r"^law of exclusivity")
_PASS_IMMUT = re.compile(r"^pass immutable `([^`]+)` as mut param `([^`]+)`")
_ESCAPE = re.compile(r"^ref `([^`]+)` escapes via (return|spawn)")
_UNDECL = re.compile(r"^use of undeclared var `([^`]+)`")
_MISSING = re.compile(r"^impl (\S+) for (\S+) missing (\S+)")


def _col_after_let(line_text):
    """Column just past `let ` on a declaration line, else None."""
    m = re.search(r"\blet\s+", line_text)
    return m.end() if m else None


def classify(line, msg, rel, lines):
    """Return a Diag for one borrow.py error record."""
    labels = []
    helps = []
    fix = None
    # A `rel` note that is already a `help:` sentence belongs on the help
    # channel, not the site channel -- borrow.py:617 emits exactly that shape.
    if (isinstance(rel, tuple) and len(rel) == 2 and isinstance(rel[1], str)
            and rel[1].startswith("help:")):
        helps.append(rel[1][len("help:"):].strip())
    elif rel is not None and isinstance(rel, tuple) and len(rel) == 2 and rel[0]:
        labels.append(Label(rel[0], lines[rel[0] - 1].strip() if rel[0] <= len(lines) else ""))

    m = _MOVED.match(msg)
    if m:
        name = m.group(1)
        ln = labels[0].line if labels else None
        where = "line %d" % ln if ln else "an earlier line"
        helps.append("`%s` was moved to `%s`; the owner is now the binding on %s. "
                     "To keep both values, bind the second one by borrow instead of "
                     "moving it: `let m = %s` (no `move`)."
                     % (name, _moved_into(lines, ln), where, name))
        return Diag("E0382", line, msg, labels, helps, fix)

    m = _MOVE_BORROWED.match(msg)
    if m:
        moved, holder = m.group(1), m.group(2)
        ln = labels[0].line if labels else None
        helps.append("`%s` is still borrowed by `%s`%s. Move it only after `%s` is "
                     "last used, or drop the borrow by writing `let %s = %s` (no `move`)."
                     % (moved, holder, " (line %d)" % ln if ln else "", holder, holder, moved))
        return Diag("E0505", line, msg, labels, helps, fix)

    m = _DOUBLE_MUT.match(msg)
    if m:
        name = m.group(1)
        return Diag("E0499", line, msg, labels, helps, fix)

    m = _IMMUTABLE.match(msg)
    if m:
        name = m.group(1)
        helps.append("declare the binding mutable where it is created; the `note:` "
                     "line above is the site to change.")
        if labels and "const" not in msg:
            col = _col_after_let(lines[labels[0].line - 1])
            if col is not None:
                fix = Fix(labels[0].line, col, "mut ")
        return Diag("E0596", line, msg, labels, helps, fix)

    m = _NO_MUT_METHOD.match(msg)
    if m:
        name = m.group(1)
        helps.append("`%s` writes through its receiver, so the receiver must be a "
                     "`mut` place. Add `mut` at the binding shown in the note." % name)
        if labels:
            col = _col_after_let(lines[labels[0].line - 1])
            if col is not None:
                fix = Fix(labels[0].line, col, "mut ")
        return Diag("E0596", line, msg, labels, helps, fix)

    if _LOE.match(msg) or _PASS_IMMUT.match(msg):
        return Diag("E0502", line, msg, labels, helps, fix)

    m = _ESCAPE.match(msg)
    if m:
        return Diag("E0515", line, msg, labels, helps, fix)

    m = _UNDECL.match(msg)
    if m:
        return Diag("E0425", line, msg, labels, helps, fix)

    m = _MISSING.match(msg)
    if m:
        return Diag("E0046", line, msg, labels, helps, fix)

    return Diag("E0BRAT", line, msg, labels, helps, fix)


def _moved_into(lines, ln):
    """Name of the binding a value was moved into, for the help line."""
    if not ln or ln > len(lines):
        return "?"
    m = re.search(r"\blet\s+(?:mut\s+)?([A-Za-z_]\w*)\s*=", lines[ln - 1])
    return m.group(1) if m else "?"


def render(path, diags, lines):
    """Rust-style, line-oriented: an agent or editor keys on `error[CODE]` + `-->`."""
    out = []
    for d in diags:
        loc = "%s:%d" % (path, d.line) if d.line else path
        out.append("%s: error[%s]: %s" % (loc, d.code, d.message))
        out.append("  --> %s:%d" % (path, d.line) if d.line else "  --> %s" % path)
        if d.line and 1 <= d.line <= len(lines):
            out.append("  |   " + lines[d.line - 1].strip())
        for lab in d.labels:
            out.append("  = note: at %s:%d" % (path, lab.line))
            out.append("  |   " + lab.text)
        for h in d.helps:
            out.append("  = help: " + h)
        if d.fix is not None:
            out.append("  = fix[%s:%d]: insert %r  (machine-applicable)"
                       % (path, d.fix.line, d.fix.insert))
    return "\n".join(out)


def diagnose(path, src):
    prog = parse_prog(Cur(lex(src)))
    errs, _warns = borrow.check(prog)
    lines = src.splitlines()
    return [classify(ln, msg, rel, lines) for (ln, msg, rel) in errs], lines


def apply_fix(src, fix):
    lines = src.splitlines(keepends=True)
    ln = lines[fix.line - 1]
    lines[fix.line - 1] = ln[:fix.col] + fix.insert + ln[fix.col:]
    return "".join(lines)


# ---------------------------------------------------------------------------
# Self-check: the whole point of the strict design is that a `fix` is not prose.
# ---------------------------------------------------------------------------

PROBES = {
    "use_after_move": (
        'fn main() -> i64 {\n  let s = "x"\n  let m = move s\n'
        '  print(m)\n  print(s)\n  return 0\n}\n',
        "E0382", False),
    "move_while_borrowed": (
        'fn main() -> i64 {\n  let s = "x"\n  let r = s\n'
        '  let m = move s\n  print(r)\n  return 0\n}\n',
        "E0505", False),
    "double_mut_borrow": (
        'fn main() -> i64 {\n  let mut v = [1, 2]\n  let mut y = v\n'
        '  y[0] = 99\n  print(v[0])\n  return 0\n}\n',
        "E0499", False),
    "assign_immutable": (
        "fn main() -> i64 {\n  let x = 1\n  x = 2\n  return x\n}\n",
        "E0596", True),
    "push_immutable": (
        "fn main() -> i64 {\n  let v = [1, 2]\n  v.push(3)\n"
        "  print(len(v))\n  return 0\n}\n",
        "E0596", True),
}


def main():
    n = 0
    for name, (src, want_code, fixable) in PROBES.items():
        diags, lines = diagnose(name, src)
        assert diags, "%s: expected a diagnostic" % name
        d = diags[0]
        assert d.code == want_code, "%s: code %s want %s" % (name, d.code, want_code)
        assert d.line, "%s: diagnostic has no line" % name
        text = render(name, diags, lines)
        assert "error[%s]" % want_code in text, name
        assert "--> %s:%d" % (name, d.line) in text, name
        assert "= help:" in text, "%s: no help line" % name
        n += 1
        print(text)
        if fixable:
            assert d.fix is not None, "%s: expected a machine fix" % name
            fixed = apply_fix(src, d.fix)
            after, _ = diagnose(name, fixed)
            assert not after, "%s: applying the suggested fix left %d error(s): %s" % (
                name, len(after), [a.message for a in after])
            print("  [fix applied -> 0 errors]")
            n += 1
        print()

    # A sound program must produce nothing at all -- the diagnostic surface must
    # not invent work for the newcomer.
    clean = ('fn main() -> i64 {\n  let mut v = [1, 2]\n  v.push(3)\n'
             '  print(len(v))\n  return 0\n}\n')
    diags, _ = diagnose("clean", clean)
    assert not diags, "clean program produced diagnostics: %s" % [d.message for d in diags]
    n += 1

    print("DIAG PROTOTYPE GREEN (%d asserts)" % n)


if __name__ == "__main__":
    main()
