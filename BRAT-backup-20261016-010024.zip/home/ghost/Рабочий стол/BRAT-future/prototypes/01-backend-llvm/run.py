"""Driver for the LLVM-backend prototype.

Steps, all on one tiny program (no heavy builds, in-process JIT avoided on
purpose so the pipeline is exactly `emit -> clang -> run`):

  1. emit unoptimized LLVM IR from demo.brat through the repository's parser
  2. compile with clang -O2 and run
  3. run the same program in the tree-walk interpreter
  4. compare stdout byte for byte
  5. re-emit the optimized IR and count alloca/load/store, to show the memory
     the naive IR used is gone after -O2 (the optimization the C emitter's
     `compute_fast` hand-codes, done here for free)

Run: python3 run.py
"""

import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import llvm_backend  # noqa: E402

DEMO = os.path.join(HERE, "demo.brat")
ENG = llvm_backend.BRAT_ENGINE
BRAT = os.path.join(ENG, "brat.py")


def run(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, timeout=120, **kw)


def main():
    ir_text = llvm_backend.emit_file(DEMO)
    raw_ll = os.path.join(HERE, "demo.ll")
    with open(raw_ll, "w", encoding="utf-8") as f:
        f.write(ir_text)
    print("emitted IR: %d lines -> demo.ll" % ir_text.count("\n"))

    exe = os.path.join(HERE, "demo.exe")
    r = run(["clang", "-O2", raw_ll, "-o", exe])
    assert r.returncode == 0, "clang failed:\n%s" % (r.stdout + r.stderr)[-2000:]
    print("clang -O2 ok -> demo.exe")

    native = run([exe])
    assert native.returncode == 0, "native rc=%d\n%s" % (native.returncode, native.stderr)

    interp = run([sys.executable, "-X", "utf8", BRAT, DEMO])
    assert interp.returncode == 0, "interp rc=%d\n%s" % (interp.returncode, interp.stderr)

    print("interpreter stdout: %r" % interp.stdout)
    print("llvm-backend stdout: %r" % native.stdout)
    if interp.stdout != native.stdout:
        print("PARITY FAIL")
        return 1
    print("PARITY OK: byte-identical stdout")

    opt_ll = os.path.join(HERE, "demo.opt.ll")
    r = run(["clang", "-O2", "-S", "-emit-llvm", raw_ll, "-o", opt_ll])
    assert r.returncode == 0, r.stderr[-2000:]

    def counts(path):
        t = open(path, encoding="utf-8").read()
        return {k: t.count(" " + k + " ") for k in ("alloca", "load", "store")}

    before, after = counts(raw_ll), counts(opt_ll)
    print("frame ops before -O2: %s" % before)
    print("frame ops after  -O2: %s" % after)
    assert after["alloca"] == 0, "allocas survived -O2"
    print("OK: every alloca was promoted to a register by LLVM passes")

    # Same IR text, other targets. This is the cost of a new backend being a
    # target triple, not a new emitter.
    for target, out in (("aarch64-linux-gnu", "demo.aarch64.o"),
                        ("wasm32", "demo.wasm.o")):
        obj = os.path.join(HERE, out)
        r = run(["clang", "--target=" + target, "-O2", "-c", raw_ll, "-o", obj])
        assert r.returncode == 0, "%s cross-compile failed:\n%s" % (target, r.stderr[-2000:])
        print("cross-compiled %s -> %s (%d bytes)" % (target, out, os.path.getsize(obj)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
