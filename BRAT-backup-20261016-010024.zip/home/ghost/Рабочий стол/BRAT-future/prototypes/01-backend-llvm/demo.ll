; ModuleID = "brat"
target triple = "x86_64-unknown-linux-gnu"
target datalayout = ""

@"str.0" = private constant [6 x i8] c"%lld\0a\00"
declare i32 @"printf"(i8* %".1", ...)

define i64 @"fib"(i64 %".1")
{
entry:
  %"n" = alloca i64
  store i64 %".1", i64* %"n"
  %".4" = load i64, i64* %"n"
  %".5" = icmp slt i64 %".4", 2
  br i1 %".5", label %"if.then", label %"if.else"
if.then:
  %".7" = load i64, i64* %"n"
  ret i64 %".7"
if.else:
  br label %"if.end"
if.end:
  %".11" = load i64, i64* %"n"
  %".12" = sub i64 %".11", 1
  %".13" = call i64 @"fib"(i64 %".12")
  %".14" = load i64, i64* %"n"
  %".15" = sub i64 %".14", 2
  %".16" = call i64 @"fib"(i64 %".15")
  %".17" = add i64 %".13", %".16"
  ret i64 %".17"
dead:
  br label %"if.end"
dead.1:
  ret i64 0
}

define i64 @"main"()
{
entry:
  %"total" = alloca i64
  store i64 0, i64* %"total"
  %"i" = alloca i64
  store i64 0, i64* %"i"
  br label %"for.cond"
for.cond:
  %".5" = load i64, i64* %"i"
  %".6" = icmp slt i64 %".5", 1000
  br i1 %".6", label %"for.body", label %"for.end"
for.body:
  %".8" = load i64, i64* %"total"
  %".9" = load i64, i64* %"i"
  %".10" = mul i64 %".9", 2
  %".11" = add i64 %".8", %".10"
  store i64 %".11", i64* %"total"
  %".13" = load i64, i64* %"i"
  %".14" = add i64 %".13", 1
  store i64 %".14", i64* %"i"
  br label %"for.cond"
for.end:
  %".17" = load i64, i64* %"total"
  %".18" = bitcast [6 x i8]* @"str.0" to i8*
  %".19" = call i32 (i8*, ...) @"printf"(i8* %".18", i64 %".17")
  %".20" = call i64 @"fib"(i64 20)
  %".21" = bitcast [6 x i8]* @"str.0" to i8*
  %".22" = call i32 (i8*, ...) @"printf"(i8* %".21", i64 %".20")
  %"n" = alloca i64
  store i64 0, i64* %"n"
  %"acc" = alloca i64
  store i64 0, i64* %"acc"
  br label %"while.cond"
while.cond:
  %".26" = load i64, i64* %"n"
  %".27" = icmp slt i64 %".26", 100
  br i1 %".27", label %"while.body", label %"while.end"
while.body:
  %".29" = load i64, i64* %"acc"
  %".30" = load i64, i64* %"n"
  %".31" = add i64 %".29", %".30"
  store i64 %".31", i64* %"acc"
  %".33" = load i64, i64* %"n"
  %".34" = add i64 %".33", 1
  store i64 %".34", i64* %"n"
  br label %"while.cond"
while.end:
  %".37" = load i64, i64* %"acc"
  %".38" = bitcast [6 x i8]* @"str.0" to i8*
  %".39" = call i32 (i8*, ...) @"printf"(i8* %".38", i64 %".37")
  %".40" = load i64, i64* %"acc"
  %".41" = load i64, i64* %"total"
  %".42" = icmp sgt i64 %".40", %".41"
  br i1 %".42", label %"if.then", label %"if.else"
if.then:
  %".44" = bitcast [6 x i8]* @"str.0" to i8*
  %".45" = call i32 (i8*, ...) @"printf"(i8* %".44", i64 1)
  br label %"if.end"
if.else:
  %".47" = bitcast [6 x i8]* @"str.0" to i8*
  %".48" = call i32 (i8*, ...) @"printf"(i8* %".47", i64 0)
  br label %"if.end"
if.end:
  ret i64 0
dead:
  ret i64 0
}
