; ModuleID = '/home/ghost/Рабочий стол/BRAT-future/prototypes/01-backend-llvm/demo.ll'
source_filename = "/home/ghost/\D0\A0\D0\B0\D0\B1\D0\BE\D1\87\D0\B8\D0\B9 \D1\81\D1\82\D0\BE\D0\BB/BRAT-future/prototypes/01-backend-llvm/demo.ll"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@str.0 = private constant [6 x i8] c"%lld\0A\00"

; Function Attrs: nofree nounwind
declare noundef i32 @printf(ptr noundef readonly captures(none), ...) local_unnamed_addr #0

; Function Attrs: nofree nosync nounwind memory(none)
define i64 @fib(i64 %.1) local_unnamed_addr #1 {
entry:
  %.54 = icmp slt i64 %.1, 2
  br i1 %.54, label %common.ret, label %if.end

common.ret:                                       ; preds = %if.end, %entry
  %accumulator.tr.lcssa = phi i64 [ 0, %entry ], [ %.17, %if.end ]
  %.1.tr.lcssa = phi i64 [ %.1, %entry ], [ %.15, %if.end ]
  %accumulator.ret.tr = add i64 %.1.tr.lcssa, %accumulator.tr.lcssa
  ret i64 %accumulator.ret.tr

if.end:                                           ; preds = %entry, %if.end
  %.1.tr6 = phi i64 [ %.15, %if.end ], [ %.1, %entry ]
  %accumulator.tr5 = phi i64 [ %.17, %if.end ], [ 0, %entry ]
  %.12 = add nsw i64 %.1.tr6, -1
  %.13 = tail call i64 @fib(i64 %.12)
  %.15 = add nsw i64 %.1.tr6, -2
  %.17 = add i64 %.13, %accumulator.tr5
  %.5 = icmp samesign ult i64 %.1.tr6, 4
  br i1 %.5, label %common.ret, label %if.end
}

; Function Attrs: nofree nounwind
define noundef i64 @main() local_unnamed_addr #0 {
if.end:
  %.19 = tail call i32 (ptr, ...) @printf(ptr nonnull dereferenceable(1) @str.0, i64 999000)
  %.20 = tail call i64 @fib(i64 20)
  %.22 = tail call i32 (ptr, ...) @printf(ptr nonnull dereferenceable(1) @str.0, i64 %.20)
  %.39 = tail call i32 (ptr, ...) @printf(ptr nonnull dereferenceable(1) @str.0, i64 4950)
  %.48 = tail call i32 (ptr, ...) @printf(ptr nonnull dereferenceable(1) @str.0, i64 0)
  ret i64 0
}

attributes #0 = { nofree nounwind }
attributes #1 = { nofree nosync nounwind memory(none) }
