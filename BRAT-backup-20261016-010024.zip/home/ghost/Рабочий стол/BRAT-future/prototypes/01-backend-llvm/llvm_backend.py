"""Minimal BRAT -> LLVM IR emitter for the annotated i64 subset.

Prototype for proposal 01-backend-llvm. It is deliberately small: it covers
exactly the subset the C emitter's hand-written `compute_fast` fast path covers
(`lang/engine/codegen_c.py:389`), so both can be compared on the same programs.

It reads real `.brat` source through the repository's own parser
(`lang/engine/brat/parser.py`); it is not a toy grammar. Anything the subset does
not cover raises `NotImplementedError` with the offending node, so a silent
fallback cannot hide a gap.

Supported: `fn` with i64 params/return, `let`/`set`, `return`, `if`/`else`,
`while`, `for i in a..b`, integer `+ - *` and comparisons, calls to i64
functions, `print(<i64>)`.
"""

import importlib.util
import os
import sys

from llvmlite import ir

I64 = ir.IntType(64)
I1 = ir.IntType(1)
I8 = ir.IntType(8)
I32 = ir.IntType(32)
I8P = I8.as_pointer()

BRAT_ENGINE = os.environ.get(
    "BRAT_ENGINE",
    "/home/ghost/Рабочий стол/BRAT/lang/engine",
)


def _load_brat():
    """Load the repository's brat.py the same way codegen_c.py does."""
    path = os.path.join(BRAT_ENGINE, "brat.py")
    spec = importlib.util.spec_from_file_location("brat_llvm_proto", path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod


_brat = _load_brat()


def parse_src(src):
    return _brat.parse_prog(_brat.Cur(_brat.lex(src)))


class Unsupported(Exception):
    pass


class LLVEmitter:
    def __init__(self, prog):
        self.prog = prog
        self.mod = ir.Module(name="brat")
        self.mod.triple = "x86_64-unknown-linux-gnu"
        self.fmt = self._str_const("%lld\n")
        self.printf = ir.Function(
            self.mod, ir.FunctionType(I32, [I8P], var_arg=True), name="printf"
        )
        self.sigs = {}  # name -> (param_i64_count, ret_kind)
        self.funcs = {}

    # -- module-level helpers ------------------------------------------------

    def _str_const(self, s):
        data = bytearray(s.encode("utf-8")) + b"\x00"
        typ = ir.ArrayType(I8, len(data))
        g = ir.GlobalVariable(self.mod, typ, name=self._fresh_global("str"))
        g.global_constant = True
        g.initializer = ir.Constant(typ, data)
        g.linkage = "private"
        return g

    def _fresh_global(self, tag):
        n = len(list(self.mod.global_values))
        return "%s.%d" % (tag, n)

    # -- reachability check for the subset -----------------------------------

    @staticmethod
    def _ann(elem):
        return elem[2] if isinstance(elem, tuple) and len(elem) > 2 else None

    def _collect(self):
        for s in self.prog[1]:
            node = s[1] if (isinstance(s, tuple) and s and s[0] == "pub") else s
            if not (isinstance(node, tuple) and node and node[0] == "fn"):
                continue
            params = node[2]
            for p in params:
                if self._ann(p) != "i64":
                    raise Unsupported("param without i64 annotation: %r" % (p,))
            ret = node[5] if len(node) > 5 else None
            if ret != "i64":
                raise Unsupported("fn `%s` does not return i64 (got %r)" % (node[1], ret))
            self.sigs[node[1]] = (len(params), "i64")

    def emit(self):
        self._collect()
        for s in self.prog[1]:
            node = s[1] if (isinstance(s, tuple) and s and s[0] == "pub") else s
            if not (isinstance(node, tuple) and node and node[0] == "fn"):
                raise Unsupported("top-level node not a fn: %r" % (node[0] if isinstance(node, tuple) else node,))
            self._emit_fn(node)
        return str(self.mod)

    # -- functions -----------------------------------------------------------

    def _emit_fn(self, node):
        _, name, params, body = node[0], node[1], node[2], node[3]
        n = len(params)
        fn = ir.Function(self.mod, ir.FunctionType(I64, [I64] * n), name=name)
        self.funcs[name] = fn
        entry = fn.append_basic_block("entry")
        b = ir.IRBuilder(entry)
        self.env = {}
        for i, p in enumerate(params):
            pname = p[0]
            slot = b.alloca(I64, name=pname)
            b.store(fn.args[i], slot)
            self.env[pname] = slot
        end = self._block(body, b)
        if not end.block.is_terminated:
            end.ret(ir.Constant(I64, 0))
        return fn

    # -- statements ----------------------------------------------------------

    def _block(self, body, b):
        for s in body:
            b = self._stmt(s, b)
        return b

    def _stmt(self, s, b):
        k = s[0]
        if k == "let":
            slot = b.alloca(I64, name=s[1])
            b.store(self._expr(s[2], b), slot)
            self.env[s[1]] = slot
            return b
        if k == "set":
            if s[1] not in self.env:
                raise Unsupported("assign to unknown `%s`" % s[1])
            b.store(self._expr(s[2], b), self.env[s[1]])
            return b
        if k == "return":
            b.ret(self._expr(s[1], b))
            return ir.IRBuilder(self._dead_block(b))
        if k == "expr":
            return self._expr_stmt(s[1], b)
        if k == "while":
            cond = b.function.append_basic_block("while.cond")
            body = b.function.append_basic_block("while.body")
            cont = b.function.append_basic_block("while.end")
            b.branch(cond)
            cb = ir.IRBuilder(cond)
            cb.cbranch(self._cond(s[1], cb), body, cont)
            bb = ir.IRBuilder(body)
            bb = self._block(s[2], bb)
            if not bb.block.is_terminated:
                bb.branch(cond)
            return ir.IRBuilder(cont)
        if k == "forrange":
            return self._forrange(s, b)
        if k == "if":
            return self._if(s, b)
        raise Unsupported("stmt %r" % (k,))

    def _if(self, s, b):
        then = b.function.append_basic_block("if.then")
        els = b.function.append_basic_block("if.else")
        cont = b.function.append_basic_block("if.end")
        b.cbranch(self._cond(s[1], b), then, els)
        tb = ir.IRBuilder(then)
        tb = self._block(s[2], tb)
        if not tb.block.is_terminated:
            tb.branch(cont)
        eb = ir.IRBuilder(els)
        if s[3]:
            eb = self._block(s[3] if isinstance(s[3], list) else [s[3]], eb)
        if not eb.block.is_terminated:
            eb.branch(cont)
        return ir.IRBuilder(cont)

    def _forrange(self, s, b):
        _, name, start, end, body = s
        sval = self._expr(start, b)
        evalt = self._expr(end, b)
        slot = b.alloca(I64, name=name)
        b.store(sval, slot)
        cond = b.function.append_basic_block("for.cond")
        body_b = b.function.append_basic_block("for.body")
        cont = b.function.append_basic_block("for.end")
        b.branch(cond)
        cb = ir.IRBuilder(cond)
        cb.cbranch(
            cb.icmp_signed("<", cb.load(slot), evalt), body_b, cont
        )
        saved = self.env.get(name)
        self.env[name] = slot
        bb = ir.IRBuilder(body_b)
        bb = self._block(body, bb)
        if not bb.block.is_terminated:
            bb.store(bb.add(bb.load(slot), ir.Constant(I64, 1)), slot)
            bb.branch(cond)
        if saved is None:
            self.env.pop(name, None)
        else:
            self.env[name] = saved
        return ir.IRBuilder(cont)

    def _dead_block(self, b):
        return b.function.append_basic_block("dead")

    def _expr_stmt(self, e, b):
        if isinstance(e, tuple) and e and e[0] == "call" and e[1] == "print":
            if len(e[2]) != 1:
                raise Unsupported("print with %d args" % len(e[2]))
            v = self._expr(e[2][0], b)
            if v.type != I64:
                raise Unsupported("print of non-i64 value: %s" % v.type)
            ptr = b.bitcast(self.fmt, I8P)
            b.call(self.printf, [ptr, v])
            return b
        raise Unsupported("expression statement %r" % (e[0] if isinstance(e, tuple) else e,))

    # -- expressions ---------------------------------------------------------

    def _cond(self, e, b):
        v = self._expr(e, b)
        if v.type == I1:
            return v
        if v.type == I64:
            return b.icmp_signed("!=", v, ir.Constant(I64, 0))
        raise Unsupported("condition of type %s" % v.type)

    def _expr(self, e, b):
        if not isinstance(e, tuple) or not e:
            raise Unsupported("empty expr")
        k = e[0]
        if k == "num":
            if isinstance(e[1], bool):
                return ir.Constant(I1, int(e[1]))
            return ir.Constant(I64, int(e[1]))
        if k == "bool":
            return ir.Constant(I1, int(e[1]))
        if k == "var":
            if e[1] not in self.env:
                raise Unsupported("read of unknown `%s`" % e[1])
            return b.load(self.env[e[1]])
        if k == "un":
            if e[1] == "-":
                return b.sub(ir.Constant(I64, 0), self._expr(e[2], b))
            if e[1] == "!":
                truth = self._cond(e[2], b)  # i1
                return b.icmp_signed("==", truth, ir.Constant(I1, 0))
            raise Unsupported("unary %r" % e[1])
        if k == "bin":
            return self._bin(e, b)
        if k == "call":
            return self._call(e, b)
        raise Unsupported("expr %r" % (k,))

    def _bin(self, e, b):
        op = e[1]
        a = self._expr(e[2], b)
        c = self._expr(e[3], b)
        if op == "+":
            return b.add(a, c)
        if op == "-":
            return b.sub(a, c)
        if op == "*":
            return b.mul(a, c)
        if op in ("==", "!=", "<", ">", "<=", ">="):
            return b.icmp_signed({"==": "==", "!=": "!=", "<": "<", ">": ">",
                                  "<=": "<=", ">=": ">="}[op], a, c)
        raise Unsupported("binary %r" % op)

    def _call(self, e, b):
        name = e[1]
        fn = self.funcs.get(name)
        if fn is None:
            raise Unsupported("call to non-i64 fn `%s`" % name)
        args = [self._expr(a, b) for a in e[2]]
        return b.call(fn, args)


def emit_src(src):
    return LLVEmitter(parse_src(src)).emit()


def emit_file(path):
    with open(path, encoding="utf-8") as f:
        return emit_src(f.read())
