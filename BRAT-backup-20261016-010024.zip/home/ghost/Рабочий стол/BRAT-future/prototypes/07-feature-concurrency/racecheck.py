#!/usr/bin/env python3
"""Prototype of the proposed ownership rule for BRAT concurrency.

Today `brat check` accepts a program where two `spawn` blocks write through the
same mutable container (`cases/racy.brat`): the frame is copied, the container
is shared, and the write race is "the user's responsibility" (SPEC §7; measured
at 3/200 lost writes natively in PLAN-heavy-items.md Item 3). This script is the
missing rule: a container captured mutably by more than one spawn, or a value
sent through a channel and used after the move, is a compile error.

It parses real BRAT with the repo's own parser (read only) and reports against
the same AST shape borrow.py walks, so the rule can be added there directly.
"""
import os
import sys

ENGINE = os.environ.get(
    "BRAT_ENGINE", "/home/ghost/Рабочий стол/BRAT/lang/engine")
sys.path.insert(0, ENGINE)
from brat.lexer import Cur, lex          # noqa: E402
from brat.parser import parse_prog       # noqa: E402

# Built-in vec/map mutators; the same list borrow.py enforces for `let mut`.
MUTATORS = {"push", "pop", "sort", "sort_by", "ins", "del", "set"}

# Constructors whose result is safe to share across tasks. A value behind one of
# these is not a bare container, so the multi-writer rule does not apply.
SAFE_CTORS = {"shared", "channel"}


def walk(node, visit):
    """Depth-first over the tuple/list AST, calling visit on every node."""
    visit(node)
    if isinstance(node, tuple):
        for x in node[1:]:
            walk(x, visit)
    elif isinstance(node, list):
        for x in node:
            walk(x, visit)


def root_of(expr):
    """Binding name at the root of a path expression, or None."""
    while isinstance(expr, tuple):
        if expr[0] == "var":
            return expr[1]
        if expr[0] in ("idx", "field"):
            expr = expr[1]
            continue
        return None
    return None


def writes_through(body):
    """Binding names mutated through within this block."""
    hits = set()

    def visit(n):
        if not isinstance(n, tuple) or not n:
            return
        if n[0] in ("setidx", "setfield"):
            r = root_of(n[1])
            if r:
                hits.add(r)
        elif n[0] == "call" and isinstance(n[1], str) and "." in n[1]:
            meth = n[1].rsplit(".", 1)[1]
            if meth in MUTATORS:
                receiver = n[1].rsplit(".", 1)[0]
                r = receiver.split(".", 1)[0]
                if r:
                    hits.add(r)

    walk(body, visit)
    return hits


def moved_in_send(node):
    """Binding moved by a `<receiver>.send(value)` call, or None."""
    if (isinstance(node, tuple) and node and node[0] == "expr"):
        node = node[1]
    if (isinstance(node, tuple) and node and node[0] == "call"
            and isinstance(node[1], str) and node[1].endswith(".send") and node[2]):
        return root_of(node[2][0])
    return None


def names_in(node):
    """Every binding name referenced in a subtree."""
    hits = set()

    def visit(n):
        if isinstance(n, tuple) and n and n[0] == "var":
            hits.add(n[1])

    walk(node, visit)
    return hits


def use_after_send(stmts):
    """A binding sent through a channel and read after the send.

    Order-sensitive within one block: `tx.send(v)` is a move, so any later
    statement in the same block that names `v` is a use-after-move.
    """
    errs = []
    moved = set()
    for st in stmts:
        if moved:
            still = names_in(st) & moved
            for name in sorted(still):
                errs.append("use of moved `%s`: sent through a channel" % name)
                moved.discard(name)
        m = moved_in_send(st)
        if m:
            moved.add(m)
    return errs


def declared_safe(fn_body):
    """Bindings whose initializer is shared(...)/channel(...)."""
    safe = set()

    def visit(n):
        if isinstance(n, tuple) and n and n[0] == "let":
            init = n[2]
            if (isinstance(init, tuple) and init and init[0] == "call"
                    and init[1] in SAFE_CTORS):
                safe.add(n[1])

    walk(fn_body, visit)
    return safe


def spawns_in(body):
    """Sibling spawn blocks directly in this body (the scope's children)."""
    return [s for s in body if isinstance(s, tuple) and s and s[0] == "spawn"]


def check_function(name, body, errs):
    safe = declared_safe(body)
    kids = spawns_in(body)
    writers = {}
    for i, sp in enumerate(kids):
        for binding in writes_through(sp[1]):
            if binding in safe:
                continue
            writers.setdefault(binding, []).append(i)
    for binding, idxs in writers.items():
        if len(idxs) >= 2:
            errs.append(
                "data race: `%s` is written through by %d spawns (tasks %s); "
                "move it into one task, or wrap it as shared(...) / pass it "
                "through a channel" % (binding, len(idxs),
                                       ", ".join(str(x) for x in idxs)))
    for sp in kids:
        for e in use_after_send(sp[1]):
            errs.append(e)


def check_src(src):
    prog = parse_prog(Cur(lex(src)))
    errs = []
    for stmt in prog[1]:
        if isinstance(stmt, tuple) and stmt and stmt[0] == "fn":
            check_function(stmt[1], stmt[3], errs)
    return errs


def main(argv):
    rc = 0
    for path in argv[1:]:
        with open(path, encoding="utf-8") as f:
            src = f.read()
        errs = check_src(src)
        if errs:
            for e in errs:
                print("%s: error: %s" % (path, e))
            rc = 2
        else:
            print("%s: 0 concurrency error(s)" % path)
    return rc


if __name__ == "__main__":
    sys.exit(main(sys.argv))
