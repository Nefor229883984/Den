#!/usr/bin/env bash
# Reproducible proof for proposal 07 (feature-concurrency). Run from anywhere.
#
#   ./run.sh
#
# It shows three things:
#   1. today's `brat check` is silent on a shared-container write race
#      (0 errors), which is the gap the proposal closes;
#   2. the proposed rule (racecheck.py) rejects it;
#   3. the same rule accepts the two safe rewrites and the two
#      positive controls (channel + shared), so it is not a rubber stamp.
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
BRAT_ENGINE="${BRAT_ENGINE:-/home/ghost/Рабочий стол/BRAT/lang/engine}"
CLI="$BRAT_ENGINE/cli.py"
C="$HERE/cases"
fails=0

note() { printf '%s\n' "$*"; }
ok()   { printf '  ok: %s\n' "$*"; }
bad()  { printf '  FAIL: %s\n' "$*"; fails=$((fails + 1)); }

note "1. today's checker on the racy program (shared Vec) must be silent"
out="$(PYTHONIOENCODING=utf-8 BRAT_FILES=1 python3 "$CLI" check "$C/racy_shared_vec.brat" 2>&1)"
if printf '%s' "$out" | grep -q "0 error(s)"; then
  ok "brat check: 0 errors (the gate the proposal adds is missing today)"
else
  bad "expected brat check to accept the racy program, got: $out"
fi

note "2. the proposed rule must reject the racy program"
out="$(python3 "$HERE/racecheck.py" "$C/racy_shared_vec.brat" 2>&1)"
if printf '%s' "$out" | grep -q "data race"; then
  ok "racecheck: data race reported"
else
  bad "racecheck did not flag the race: $out"
fi

out="$(python3 "$HERE/racecheck.py" "$C/racy_send_reuse.brat" 2>&1)"
if printf '%s' "$out" | grep -q "use of moved"; then
  ok "racecheck: use-after-send reported"
else
  bad "racecheck did not flag use-after-send: $out"
fi

note "3. the proposed rule must accept the safe rewrites (positive control)"
for f in safe_channel safe_shared; do
  out="$(python3 "$HERE/racecheck.py" "$C/$f.brat" 2>&1)"
  if printf '%s' "$out" | grep -q "0 concurrency error(s)"; then
    ok "$f.brat: clean"
  else
    bad "$f.brat should be clean, got: $out"
  fi
done

if [ "$fails" -eq 0 ]; then
  note "PASS"
  exit 0
fi
note "FAILED: $fails"
exit 1
