# Предлагаемый синтаксис (цель v0.2, НЕ компилируется сегодня)

Это не код для прогона — `scope`, `channel`, `shared` в грамматику v0.1 не
входят (`lang/engine/brat/parser.py`, `lang/spec/SPEC.md` §7 знает только
`spawn {}` + `join_all()`). Здесь зафиксирована поверхность, под которую
написана архитектура в `proposals/07-feature-concurrency.md`.

## Структурный скоуп

```brat
fn main() -> i64 {
  let srv = tcp_listen("127.0.0.1:8099")?
  scope {                          // все spawn внутри живут до конца scope
    for _ in 0..100 {
      let conn = tcp_accept(srv)?
      spawn { handle(conn) }       // ребёнок scope; ошибка внутри -> выход scope
    }
  }                                // здесь ждём всех; первая ошибка идёт наружу
  return 0
}
```

`join_all()` остаётся (совместимость) и означает «дождаться детей текущего
скоупа». `scope` — это `join_all` как лексическая гарантия, а не «в конце
всей программы» (`crt.h:2474`, `runtime.py:1419`).

## Каналы — передача владения

```brat
let jobs = channel(64)             // ограниченный: send блокирует при заполнении
let done = channel(0)              // 0 = неbuffered, рукопожатие
spawn {
  for j in jobs {
    done.send(j * 2)
  }
}
jobs.send(42)                      // 42 ПЕРЕМЕЩАЕТСЯ; после этого 42 недоступен
jobs.close()                       // for ... in jobs завершится
print(done.recv())                 // recv -> T или Err(reason) если канал закрыт
```

`send(v)` — это `move v`: статическая проверка та же, что у `move x`
(`borrow.py: scan_moves`). Содержимое канала типизировано: `Sender[T]`,
`Receiver[T]`, `T` выводится из первого `send`.

## Общее мутабельное состояние

```brat
let total = shared(0)              // refcounted ячейка под мьютексом
scope {
  spawn { total.with(fn(x) { return x + 1 }) }
  spawn { total.with(fn(x) { return x + 2 }) }
}
print(total.with(fn(x) { return x }))
```

`.with(f)` берёт лок на время `f` и возвращает результат `f`. Нет `lock()`/
`unlock()` — нет забытого unlock и нет отравленного мьютекса как отдельного
состояния (Ousterhout §VIII, «define errors out of existence»).

## Что отвергается компилятором

```brat
let mut seen = []
spawn { seen.push(1) }             // error: data race: `seen` пишется из 2 spawn
spawn { seen.push(2) }             //        -> сдери move / shared / channel
join_all()
```
