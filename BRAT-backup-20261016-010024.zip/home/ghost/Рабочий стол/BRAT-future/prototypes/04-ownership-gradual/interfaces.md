# Interface sketch — gradual ownership

Concrete types and signatures, with the point in the existing code each one
lands on. No implementation bodies: this file fixes names and seams only.

## 1. Policy (new: `lang/engine/policy.py`)

```python
class Mem(IntEnum):          # the scalar
    MANAGED, CHECKED, STRICT, LINEAR = 0, 1, 2, 3

class Policy:
    mem: Mem
    rc: bool                 # emit refcounting        (mem <= STRICT)
    checker: str             # "advisory" | "error"    (mem >= CHECKED)
    elide_rc: bool           # per-value RC elision    (mem >= STRICT)
    def for_dependency(self, other: "Policy") -> "Policy": ...  # min(mem)

def resolve(command: str, argv: list[str], src: str) -> Policy
```

`resolve` is the only new interface the CLI, `borrow.py` and `codegen_c.py`
share. Anchors: `cli.py:580` (`main`, command dispatch), `cli.py:267`
(`do_check`), `cli.py:499` (`_gate_ownership`), `cli.py:525` (`do_build`).

## 2. Checker (`lang/engine/borrow.py`)

```python
def check(prog, extra=None, mode="error")   # borrow.py:1215
```

`mode="advisory"` prints the same diagnostics, keeps `errs` for the summary,
but `main` returns 0 and the summary line reads `N error(s) (advisory)`.
`mode="error"` is today's behavior. Anchors: `borrow.py:1257` (the walk),
`borrow.py:1374-1375` (call + summary), `borrow.py:1323` (`main`), argument
loop `borrow.py:1348`. Existing rule knowledge reused for elision/cycles:
`place_of` `borrow.py:66`, `scan_moves` `borrow.py:510`.

## 3. Managed runtime (`lang/engine/crt.h`)

```c
typedef struct BHead { long rc; } BHead;      /* payload-1 header */

BFN void *balloc(size_t n);                    /* calloc + header, rc=1 */
BFN void *bgrow_rc(void *p, size_t n);         /* realloc, header intact */
BFN Val   vrc_inc(Val v);                      /* incref heap payload, return v */
BFN void  vrc_dec(Val v);                      /* decref; free at 0 */
```

Allocation sites routed through `balloc`: `vstrn` `crt.h:89`, `vvec`
`crt.h:90`, `vmap` `crt.h:100`, `vadd` `crt.h:550`, `vtxt` `crt.h:533`.
Realloc site: `bgrow` `crt.h:66`. `V_STR` needs a length-header variant so
`strlen(as.str)` keeps working. `VRcKind` routes `vrc_dec` to the right free.

## 4. Emitter (`lang/engine/codegen_c.py`)

Insertion points where a value's lifetime is decided:

- binding: `let` `codegen_c.py:1332`; scope body `emit_block:1522`
- reassignment: `set` `1345`, dotted write `1354`, `setidx` `588`
- return: `emit_fn` `1658-1669` (`volatile Val __ret`, `__fin_` label)
- unwind: `main` handler `1851`, `emit_fn` `1659` — releases run before `__fin`
- `move`: dynamic `ex` `780-781`, fast paths `249/287/490` (scalars: untouched)
- LINEAR mode: `move` becomes a destructive take (`vmove(&slot)`), and scope
  exit emits a drop instead of a decref.

Two codegen shapes behind one policy:

```
MANAGED/CHECKED  bind → vrc_inc ; scope exit → vrc_dec ; move → copy (no-op)
STRICT           elide both on values the checker proves linear
LINEAR           move → destructive take ; scope exit → drop ; no rc at all
```

## 5. Contract notes

- Refcounts and releases emit no output, so `test_diff.py` / `test_native.py`
  stdout comparison is unaffected; they fix the §2.4 divergences that are
  failures today.
- `check` output must not change: `test_ownership.py:32` drives
  `cli.py check`, `test_newcomer.py:34` and `test_bratb.py` compare its bytes.
  Every rung above MANAGED must reproduce today's diagnostics exactly.
