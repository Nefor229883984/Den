"""Why a managed runtime is the default, in allocation counts.

This is a counting model of the native backend, not a benchmark. It reproduces
the arithmetic the repo already measured (docs/ARCHITECTURE.md 2.4): the string
path of `vadd` mallocs a fresh buffer per `s = s + x` and releases nothing, so
the never-freed total is n(n+1)/2 bytes for len-1 appends -- 30.5 MiB at n=8000,
the measured 32 MB threshold to a `ulimit -v 32768` OOM.

Two models, one shape:

  bare     old buffer has no owner; live bytes grow with every step
  managed  old buffer is decref'd and freed; live bytes track the binding

The third block is the honest limit: refcounting alone cannot reclaim a
reference cycle, and a cycle is exactly what the ownership checker can see.
"""


def bare(n):
    """Every append mallocs; nothing is freed. Returns (peak_live, live_at_end)."""
    live = 0
    peak = 0
    length = 0
    for _ in range(n):
        length += 1
        live += length          # vadd's malloc, never freed
        peak = max(peak, live)
    return peak, live


def managed(n):
    """Same mallocs, but the previous buffer is released first."""
    live = 0
    peak = 0
    length = 0
    for _ in range(n):
        length += 1
        live += length          # new buffer
        if length > 1:
            live -= length - 1  # old buffer decref'd to zero and freed
        peak = max(peak, live)
    return peak, live


if __name__ == "__main__":
    n = 8000
    bp, be = bare(n)
    mp, me = managed(n)
    print("n=%d  bare peak=%d B (%.1f MiB) live_at_end=%d B"
          % (n, bp, bp / 1048576, be))
    print("n=%d  managed peak=%d B live_at_end=%d B" % (n, mp, me))

    # The managed model must not grow with n: that is the whole claim.
    assert mp <= 2 * n, mp
    assert me <= n, me
    # The bare model must reproduce the repo's own number, not a made-up one.
    assert abs(bp - n * (n + 1) // 2) <= n, (bp, n * (n + 1) // 2)
    assert abs(bp / 1048576 - 30.5) < 0.1, bp / 1048576

    # Extrapolation the repo states: n=100000 -> ~5 GB.
    big = 100000 * (100000 + 1) // 2
    print("n=100000 bare live_at_end=%.2f GiB (ARCHITECTURE.md: ~5 GB)"
          % (big / 1073741824))

    # Honest limit: refcounting cannot break a cycle.
    m = {"self": None}
    m["self"] = m          # one internal reference, rc never reaches zero
    assert m["self"] is m
    print("cycle: rc(m)=1 from itself -> leaked even under managed; "
          "the checker knows this alias and can warn")

    print("rc_model self-test: PASS (managed O(n), bare O(n^2), cycle caveat)")
