#!/usr/bin/env bash
# Evidence for the proposal, run against the real engine read-only.
# No build (zig cc), no bench: only `brat check` and `brat run`, which the
# brief allows. Every line printed here is captured from the repo's own tools.
set -u
BRAT="${BRAT:-/home/ghost/Рабочий стол/BRAT}"
PY="${PY:-python3}"
CLI="$BRAT/lang/engine/cli.py"
HERE="$(cd "$(dirname "$0")" && pwd)"

echo "== 1. beginner program, no ownership annotations =="
echo "-- brat check (the mandatory static verdict) --"
"$PY" -X utf8 "$CLI" check "$HERE/naive.brat"; echo "exit=$?"
echo "-- brat run (interpreter, safety by default) --"
"$PY" -X utf8 "$CLI" run "$HERE/naive.brat"; echo "exit=$?"

echo
echo "== 2. the gate is not a guarantee: checker-clean, still unsafe natively =="
echo "-- brat check accepts it: --"
"$PY" -X utf8 "$CLI" check "$HERE/leak_clean.brat"; echo "exit=$?"
echo "-- interpreter runs it correctly: --"
"$PY" -X utf8 "$CLI" run "$HERE/leak_clean.brat"; echo "exit=$?"
echo "(native leaks n(n+1)/2 bytes here; docs/ARCHITECTURE.md 2.4 measures"
echo " 32 MB at n=8000 and OOM/segfault under ulimit -v 32768)"

echo
echo "== 3. the scalar itself =="
"$PY" "$HERE/policy.py"
"$PY" "$HERE/rc_model.py"
