"""Strictness policy for gradual ownership.

One scalar decides how much the compiler demands statically and how much the
runtime carries. It is an integer on purpose, like `-O`: each rung is a
superset of static demand, and each rung unlocks removing runtime cost.

    MANAGED  value refcounting carries safety, checker advises   (default build)
    CHECKED  checker errors are hard, runtime still carries      (default `check`)
    STRICT   CHECKED + refcount elided on provably-linear values
    LINEAR   whole program proven linear; no refcount emitted at all

LINEAR is not an "unsafe" escape hatch: it is only reachable when the checker
proves every value single-owner, so freed-on-last-use cannot double-free. That
is what keeps it inside the backend parity contract -- a naive `--no-manager`
mode would OOM natively where the interpreter does not, and the contract
(test_diff.py) compares stdout byte for byte.

`resolve()` is the whole interface the CLI, checker and emitter share.
Precedence: CLI flag > `//!mem` file header > command default.
"""
from enum import IntEnum

MEM_NAMES = {"managed": 0, "checked": 1, "strict": 2, "linear": 3}

# What each command means when the user says nothing. `check` is a request for a
# static verdict, so it stays strict by default; a build ships a program, and a
# shipped program must be memory-safe even when the user has never heard of
# ownership -- that is MANAGED, not the (incomplete) checker.
COMMAND_DEFAULT = {
    "run": 0,
    "build": 0,
    "emit-c": 0,
    "check": 1,
}


class Mem(IntEnum):
    MANAGED = 0
    CHECKED = 1
    STRICT = 2
    LINEAR = 3


class PolicyError(Exception):
    pass


class Policy:
    def __init__(self, mem):
        self.mem = Mem(mem)

    # --- what the rest of the compiler reads -----------------------------
    @property
    def rc(self):
        """Emit refcount traffic in the native backend."""
        return self.mem <= Mem.STRICT

    @property
    def checker(self):
        """How ownership findings are treated: hard errors or advice."""
        return "error" if self.mem >= Mem.CHECKED else "advisory"

    @property
    def elide_rc(self):
        """Skip refcount traffic on values the checker proves single-owner."""
        return self.mem >= Mem.STRICT

    def for_dependency(self, other):
        """Runtime level of `import`ed code is the most conservative of the
        two; a checker rung is per compilation unit, so the app keeps its own.
        This is the directional lattice that stops a graded language from
        forking into dialects: a strict library stays callable from a managed
        app, which just inherits the library's cost locally."""
        return Policy(min(self.mem, other.mem))

    def __repr__(self):
        return "Policy(%s, rc=%s, checker=%s, elide=%s)" % (
            self.mem.name, self.rc, self.checker, self.elide_rc)


def _header_level(src):
    """`//!mem N` or `//!mem name` in the file header, else None."""
    for line in src.splitlines():
        s = line.strip()
        if not s:
            continue
        if not s.startswith("//!"):
            break
        for token in s[3:].split():
            if token in MEM_NAMES:
                return MEM_NAMES[token]
            if token.isdigit() and 0 <= int(token) <= 3:
                return int(token)
    return None


def resolve(command, argv, src):
    """argv is the command's arguments without the command word."""
    level = COMMAND_DEFAULT[command]
    hdr = _header_level(src)
    if hdr is not None:
        level = hdr
    for a in argv:
        if a.startswith("--mem="):
            v = a.split("=", 1)[1]
            if v in MEM_NAMES:
                level = MEM_NAMES[v]
            elif v.isdigit() and 0 <= int(v) <= 3:
                level = int(v)
            else:
                raise PolicyError("unknown --mem %r (want managed|checked|strict|linear)" % v)
    return Policy(level)


if __name__ == "__main__":
    # Self-test: the table is the contract, and a wrong rung is a wrong guarantee.
    def t(command, argv, src, mem, rc, checker, elide):
        p = resolve(command, argv, src)
        assert p.mem == Mem[mem], (command, argv, p, mem)
        assert p.rc == rc and p.checker == checker and p.elide_rc == elide, p

    t("build", [], "", "MANAGED", True, "advisory", False)
    t("check", [], "", "CHECKED", True, "error", False)
    t("check", ["--mem=strict"], "", "STRICT", True, "error", True)
    t("build", [], "//!mem 2\nfn main() -> i64 { return 0 }\n", "STRICT", True, "error", True)
    t("build", ["--mem=linear"], "", "LINEAR", False, "error", True)
    t("build", ["--mem=managed"], "//!mem 2\n", "MANAGED", True, "advisory", False)

    try:
        resolve("build", ["--mem=outer-space"], "")
    except PolicyError as e:
        assert "unknown --mem" in str(e), e
    else:
        raise AssertionError("an unknown rung must be refused, not defaulted")

    # A library may be stricter than the app; the runtime is the min of the two.
    app = resolve("build", [], "")
    lib = Policy(Mem.STRICT)
    assert app.for_dependency(lib).rc is True
    assert Policy(Mem.LINEAR).for_dependency(app).mem == Mem.MANAGED
    # LINEAR survives only when every unit is linear.
    assert Policy(Mem.LINEAR).for_dependency(Policy(Mem.LINEAR)).mem == Mem.LINEAR

    print("policy self-test: PASS (table + precedence + reject-unknown + dependency min)")
