#!/usr/bin/env python3
"""Drop-site computation for the affine-memory proposal (06-mem-affine).

This is an ANALYSIS prototype, not an emitter. It loads the real BRAT parser and
the real borrow checker from the repo, then, for the owners that the checker's
existing model already separates from borrows, prints where a `vdrop` would be
inserted under a linear/affine ownership rule. It does not produce or compile C.

Why it is honest about being analysis-only: the claim the proposal makes is that
the *placement* of reclaim points is a static consequence of ownership the
checker already computes -- no refcount, no runtime bookkeeping. That is the part
worth proving before touching crt.h. Proving the C emitter half would require the
whole runtime change and is out of scope here.

Run:
    python3 drops.py            # all examples
    python3 drops.py FILE.brat  # one file
"""

import importlib.util
import os
import sys

ENGINE = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))))),
    "BRAT", "lang", "engine")
HERE = os.path.dirname(os.path.abspath(__file__))
EXAMPLES = os.path.join(HERE, "examples")


def _load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


borrow = _load("brat_borrow", os.path.join(ENGINE, "borrow.py"))
brat = borrow.load_brat()  # the parser: parse_prog, Cur, lex
from brat.parser import _LINES  # noqa: E402  (brat.py put ENGINE on sys.path)

# Calls whose result is an immediate (Copy) value; the checker's is_copy_expr
# does not see through calls, so a `let n = len(s)` would otherwise look like a
# fresh heap owner. Kept deliberately tiny -- it only has to cover what the
# examples use.
_SCALAR_CALLS = {"len", "time_ms", "is_err", "is_none", "is_vec", "is_str",
                 "is_map", "tagof", "join_all", "re_match", "sbuf_add",
                 "sbuf_len", "sleep_ms", "exit"}


def is_owner(e, decl, funcs):
    """True when binding this expression transfers a heap value the binding owns.

    A `move X` transfers ownership to the new binding. A value that aliases an
    existing local (`let r = k`) is a view, not an owner. A Copy value owns
    nothing. Everything else -- a literal string, a container, a struct, a call
    returning a compound -- is a fresh owner.
    """
    if isinstance(e, tuple) and e and e[0] == "move":
        return True
    if borrow.borrow_srcs(e, decl, funcs):
        return False
    if borrow.is_copy_expr(e, decl):
        return False
    if isinstance(e, tuple) and e and e[0] == "call" and e[1] in _SCALAR_CALLS:
        return False
    return True


class Drop:
    def __init__(self, line, kind, name, why):
        self.line = line
        self.kind = kind
        self.name = name
        self.why = why

    def __str__(self):
        return "L%-3s %-7s %-6s %s" % (self.line, self.kind, self.name, self.why)


def line_of(node):
    return _LINES.get(id(node))


def analyze_body(body, decl, funcs, out, seed=()):
    """Walk one block; record rebind and block-exit drops, then recurse.

    `decl` maps a name to {owner, copy, moved, line}. Nested blocks get a shallow
    copy so a declaration inside an `if` does not leak upward, matching the
    checker's own scope discipline (`walk_block`). Branches and loops are walked
    for their own drops; the proposal's README states where this is conservative.
    `seed` names bindings the enclosing frame already owns (e.g. `move` params),
    so they are dropped at this frame's exit.
    """
    last = {}
    declared_here = set(seed)
    for i, s in enumerate(body):
        if isinstance(s, tuple) and s:
            for v in borrow.used_in_stmt(s, []):
                last[v] = i

    for i, s in enumerate(body):
        if not isinstance(s, tuple) or not s:
            continue
        k = s[0]
        if k == "let":
            _, name, e = s[0], s[1], s[2]
            ann = s[5] if len(s) > 5 else None
            declared_here.add(name)
            for src in borrow.moved_targets(e, []):
                root = src.split(".", 1)[0]
                if root in decl:
                    decl[root]["moved"] = True
            decl[name] = {
                "owner": is_owner(e, decl, funcs),
                "copy": ann in borrow.COPY_ANNS or borrow.is_copy_expr(e, decl),
                "moved": False,
                "line": line_of(s),
            }
        elif k == "set":
            tgt = s[1]
            for src in borrow.moved_targets(s[2], []):
                root = src.split(".", 1)[0]
                if root in decl:
                    decl[root]["moved"] = True
            d = decl.get(tgt)
            if d is not None and d.get("owner"):
                out.append(Drop(line_of(s), "rebind", tgt,
                                "unique owner re-bound: free the old value once"))
        elif k == "return":
            _rie(s[1], decl, out, line_of(s))
        elif k == "expr":
            for src in borrow.moved_targets(s[1], []):
                root = src.split(".", 1)[0]
                if root in decl:
                    decl[root]["moved"] = True
        elif k in ("if", "while", "foriter", "forrange", "try", "spawn", "defer"):
            inner = dict((n, dict(d)) for n, d in decl.items())
            _recurse(s, inner, funcs, out)

    # Block exit: every owner declared here that is still live and not moved out
    # is dropped at the closing brace, innermost first.
    for name in declared_here:
        d = decl.get(name)
        if not d or not d.get("owner") or d.get("moved"):
            continue
        if name in last:
            out.append(Drop(d.get("line"), "exit", name,
                            "last owner leaves scope at block exit"))


def _rie(e, decl, out, ln):
    """Classify a return expression: transfer, copy at boundary, or fresh."""
    while isinstance(e, tuple) and len(e) > 1 and e[0] == "quest":
        e = e[1]
    if isinstance(e, tuple) and e and e[0] == "move":
        out.append(Drop(ln, "transfer", "-", "return moves ownership to caller; no drop here"))
        return
    if isinstance(e, tuple) and e and e[0] == "var":
        d = decl.get(e[1])
        if d and d.get("owner"):
            out.append(Drop(ln, "transfer", e[1], "return transfers the owned local to caller"))
            d["moved"] = True
        elif d and not d.get("copy"):
            out.append(Drop(ln, "copy", e[1], "return of a borrowed view: deep-copy at the boundary (affine rule)"))


def _recurse(s, decl, funcs, out):
    k = s[0]
    if k == "if":
        analyze_body(s[2], dict((n, dict(d)) for n, d in decl.items()), funcs, out)
        if s[3]:
            eb = s[3]
            analyze_body(eb if isinstance(eb, list) else [eb], decl, funcs, out)
    elif k == "while":
        analyze_body(s[2], dict((n, dict(d)) for n, d in decl.items()), funcs, out)
    elif k == "foriter":
        analyze_body(s[3], decl, funcs, out)
    elif k == "forrange":
        analyze_body(s[4], decl, funcs, out)
    elif k == "try":
        analyze_body(s[1], dict((n, dict(d)) for n, d in decl.items()), funcs, out)
        analyze_body(s[2], decl, funcs, out)
    elif k == "spawn":
        analyze_body(s[1], dict((n, dict(d)) for n, d in decl.items()), funcs, out)
    elif k == "defer":
        pass


def find_fn(node):
    return node[1] if (isinstance(node, tuple) and node and node[0] == "pub") else node


def analyze(path):
    src = open(path, encoding="utf-8").read()
    prog = brat.parse_prog(brat.Cur(brat.lex(src)))
    funcs = borrow.fn_table({})
    for s in prog[1]:
        n = find_fn(s)
        if isinstance(n, tuple) and n and n[0] == "fn":
            funcs[n[1]] = borrow.fn_modes(n[2])
    errs, warns = borrow.check(prog)
    drops = []
    for s in prog[1]:
        n = find_fn(s)
        if isinstance(n, tuple) and n and n[0] == "fn":
            decl = {}
            move_params = set()
            for p in n[2]:
                pn = p[0] if isinstance(p, tuple) else p
                mode = p[1] if isinstance(p, tuple) and len(p) > 1 else "ref"
                # Affine rule: a `move` param is owned by the callee and dropped
                # there (or moved onward); `ref`/`mut` are non-owning views the
                # caller keeps and drops.
                if mode == "move":
                    move_params.add(pn)
                decl[pn] = {"owner": mode == "move", "copy": False, "moved": False,
                            "line": line_of(n), "param": mode}
            analyze_body(n[3], decl, funcs, drops, move_params)
    return src, errs, warns, drops


def main(argv):
    files = argv[1:] or [os.path.join(EXAMPLES, f) for f in sorted(os.listdir(EXAMPLES))]
    for f in files:
        src, errs, warns, drops = analyze(f)
        print("%s" % os.path.basename(f))
        print("  checker: %d error(s), %d warning(s)" % (len(errs), len(warns)))
        for e in errs:
            print("    error: %s" % (e,))
        if not drops:
            print("  drop sites: none (no unique heap owners)")
        else:
            print("  drop sites (affine model, no refcount):")
            for d in drops:
                print("    " + str(d))
        print()


if __name__ == "__main__":
    sys.exit(main(sys.argv))
