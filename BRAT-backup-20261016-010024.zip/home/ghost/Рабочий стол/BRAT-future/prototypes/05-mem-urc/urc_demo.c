/*
 * urc_demo.c -- deferred reference counting (Blackburn-McKinley URC shape) +
 * a synchronous trial-deletion cycle collector, modelled on crt.h's Val.
 *
 * It proves four things with asserts and a measured max-RSS number, on the
 * exact allocation pattern the native backend has today (docs/ARCHITECTURE.md
 * 2.4, docs/PLAN-heavy-items.md item 1):
 *
 *   1. `s = s + "y"` in a loop is O(n) memory, not O(n^2), when the store
 *      releases the old value and the source literal is not owned.
 *   2. `let b = a` still aliases: overwriting `a` must not free the object
 *      while `b` holds a reference (measured: the interpreter prints "a").
 *   3. A container shared by two names survives one of them going away.
 *   4. Two containers pointing at each other are freed by the cycle collector
 *      after their external references drop (measured: `brat check` accepts
 *      and runs a self-referential map today, so cycles are reachable).
 *
 * Build/run:  cc -O2 -o urc_demo urc_demo.c && ./urc_demo
 * Baseline (the runtime as it is now): cc -O2 -DNO_RC -o urc_no_rc urc_demo.c && ./urc_no_rc
 *
 * Honesty note: this is a miniature of the runtime, not the runtime. It does
 * not model threads, the error path (vraise/longjmp), or the emitter's
 * temporary discipline; the proposal names which of those remain open.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>

static long live_objects = 0;
static long freed_objects = 0;

static void check_fail(const char *what) {
    fprintf(stderr, "FAIL %s\n", what);
    exit(1);
}
#define CHECK(cond, what) do { if (!(cond)) check_fail(what); } while (0)

/* ---- colors and the common header ---------------------------------------- */

enum { GREEN = 0, PURPLE = 1, GRAY = 2, BLACK = 3, WHITE = 4 };

/* Every heap object starts with this layout, so Vec, Map and a string's header
 * are interchangeable at the pointer level. Color and onlist are only ever
 * touched for Vec/Map; a string cannot be part of a cycle. */
typedef struct { unsigned long rc; unsigned char color, onlist; } Hdr;

typedef enum { T_NIL, T_INT, T_STR, T_VEC, T_MAP } Tag;
typedef struct Val Val;
typedef struct Vec Vec;
typedef struct Map Map;

struct Vec { unsigned long rc; unsigned char color, onlist; Val *items; long len, cap; };
struct Map { unsigned long rc; unsigned char color, onlist; Val *keys, *vals; long len, cap; };

/* `owned` is the discriminator the runtime needs: a source literal emitted as
 * vlit() points into .rodata and must never be freed, while vstr() allocates
 * and must be. This fits in padding Val already has. */
struct Val { Tag tag; unsigned char owned; union { long i; char *str; Vec *vec; Map *map; } as; };

static Hdr *hdr_of(Val v) {
    switch (v.tag) {
    case T_STR: return (Hdr *)v.as.str - 1;
    case T_VEC: return (Hdr *)v.as.vec;
    case T_MAP: return (Hdr *)v.as.map;
    default:    return NULL;
    }
}

/* ---- the deferred candidate list (URC's roots/update buffer) ------------- */

static Val *roots;
static long roots_len, roots_cap;

static void roots_push(Val v) {
    Hdr *h = hdr_of(v);
    if (h->onlist) return;
    h->onlist = 1;
    h->color = PURPLE;
    if (roots_len >= roots_cap) {
        roots_cap = roots_cap ? roots_cap * 2 : 256;
        roots = (Val *)realloc(roots, sizeof(Val) * (size_t)roots_cap);
        if (!roots) { fputs("oom\n", stderr); abort(); }
    }
    roots[roots_len++] = v;
}

static Val  vretain(Val v);
static void vrel(Val v);
static void vdestroy(Val v);
static void vcollect(void);

/* ---- constructors --------------------------------------------------------- */

static Val vlit(const char *s) { Val v; v.tag = T_STR; v.owned = 0; v.as.str = (char *)s; return v; }

static Val vstrn(const char *s, long n) {
    Hdr *h = (Hdr *)malloc(sizeof(Hdr) + (size_t)n + 1);
    if (!h) { fputs("oom\n", stderr); abort(); }
    h->rc = 1; h->color = GREEN; h->onlist = 0;
    memcpy(h + 1, s, (size_t)n);
    ((char *)(h + 1))[n] = 0;
    Val v; v.tag = T_STR; v.owned = 1; v.as.str = (char *)(h + 1);
    live_objects++;
    return v;
}
static Val vstr(const char *s) { return vstrn(s, (long)strlen(s)); }

static Val vvec(void) {
    Vec *v = (Vec *)malloc(sizeof(Vec));
    if (!v) { fputs("oom\n", stderr); abort(); }
    v->rc = 1; v->color = GREEN; v->onlist = 0; v->len = 0; v->cap = 4;
    v->items = (Val *)malloc(sizeof(Val) * 4);
    if (!v->items) { fputs("oom\n", stderr); abort(); }
    Val r; r.tag = T_VEC; r.owned = 1; r.as.vec = v;
    live_objects++;
    return r;
}
static Val vmap(void) {
    Map *m = (Map *)malloc(sizeof(Map));
    if (!m) { fputs("oom\n", stderr); abort(); }
    m->rc = 1; m->color = GREEN; m->onlist = 0; m->len = 0; m->cap = 4;
    m->keys = (Val *)malloc(sizeof(Val) * 4);
    m->vals = (Val *)malloc(sizeof(Val) * 4);
    if (!m->keys || !m->vals) { fputs("oom\n", stderr); abort(); }
    Val r; r.tag = T_MAP; r.owned = 1; r.as.map = m;
    live_objects++;
    return r;
}

/* ---- retain / release (the core) ----------------------------------------- */

#ifdef NO_RC
/* The runtime as it exists today: constructors hand back a value, nothing is
 * ever counted and nothing is ever freed. This is the leak. */
static Val vretain(Val v) { return v; }
static void vrel(Val v)   { (void)v; }
static void vcollect(void) {}
#else
static Val vretain(Val v) {
    if (v.owned) hdr_of(v)->rc++;
    return v;
}

static void vrel(Val v) {
    if (!v.owned) return;
    Hdr *h = hdr_of(v);
    if (h->rc == 0) return;              /* already being torn down */
    if (--h->rc == 0) {
        h->color = GREEN;
        vdestroy(v);
        return;
    }
    /* Did not reach zero: it may still be inside a cycle. Defer the decision
     * to the collector rather than paying a mark pass on the hot path. */
    roots_push(v);
    if (roots_len >= 512) vcollect();
}
#endif

/* ---- container writers: the container takes its own reference ------------ */

static void vec_push(Vec *v, Val x) {
    if (v->len >= v->cap) {
        v->cap *= 2;
        v->items = (Val *)realloc(v->items, sizeof(Val) * (size_t)v->cap);
        if (!v->items) { fputs("oom\n", stderr); abort(); }
    }
    v->items[v->len++] = vretain(x);
}

static void map_set(Map *m, Val k, Val x) {
    if (m->len >= m->cap) {
        m->cap *= 2;
        m->keys = (Val *)realloc(m->keys, sizeof(Val) * (size_t)m->cap);
        m->vals = (Val *)realloc(m->vals, sizeof(Val) * (size_t)m->cap);
    }
    m->keys[m->len] = vretain(k);
    m->vals[m->len] = vretain(x);
    m->len++;
}

/* ---- string concat: exactly the vadd() string path in crt.h:544 ---------- */

static Val vadd(Val a, Val b) {
    CHECK(a.tag == T_STR && b.tag == T_STR, "vadd wants strings in this demo");
    long la = (long)strlen(a.as.str), lb = (long)strlen(b.as.str);
    Hdr *h = (Hdr *)malloc(sizeof(Hdr) + (size_t)(la + lb) + 1);
    if (!h) { fputs("oom\n", stderr); abort(); }
    h->rc = 1; h->color = GREEN; h->onlist = 0;
    memcpy(h + 1, a.as.str, (size_t)la);
    memcpy((char *)(h + 1) + la, b.as.str, (size_t)lb);
    ((char *)(h + 1))[la + lb] = 0;
    live_objects++;
    Val r; r.tag = T_STR; r.owned = 1; r.as.str = (char *)(h + 1);
    return r;
}

/* ---- destroy and the cycle collector ------------------------------------- */

static void vdestroy(Val v) {
    if (!v.owned) return;
    switch (v.tag) {
    case T_STR:
        free(hdr_of(v));                     /* payload lives in the same block */
        break;
    case T_VEC: {
        Vec *q = v.as.vec;
        for (long i = 0; i < q->len; i++) if (q->items[i].owned) vrel(q->items[i]);
        free(q->items);
        free(q);
        break;
    }
    case T_MAP: {
        Map *q = v.as.map;
        for (long i = 0; i < q->len; i++) {
            if (q->keys[i].owned) vrel(q->keys[i]);
            if (q->vals[i].owned) vrel(q->vals[i]);
        }
        free(q->keys); free(q->vals); free(q);
        break;
    }
    default: return;
    }
    live_objects--;
    freed_objects++;
}

#ifndef NO_RC
/* Bacon-Rajan synchronous trial deletion. markGray subtracts each internal
 * edge from the count (and stops at an already-gray node, so a node with two
 * internal edges keeps the surplus and is never trial-deleted to zero); scanBlack
 * restores the edges of anything still externally reachable (rc ends > 0). A
 * node left white has no external references and is garbage. */
static void markGray(Val v) {
    if (!v.owned) return;
    Hdr *h = hdr_of(v);
    if (h->color == GRAY) return;
    h->color = GRAY;
    if (v.tag == T_VEC) {
        Vec *q = v.as.vec;
        for (long i = 0; i < q->len; i++) if (q->items[i].owned) { hdr_of(q->items[i])->rc--; markGray(q->items[i]); }
    } else if (v.tag == T_MAP) {
        Map *q = v.as.map;
        for (long i = 0; i < q->len; i++) {
            if (q->keys[i].owned) { hdr_of(q->keys[i])->rc--; markGray(q->keys[i]); }
            if (q->vals[i].owned) { hdr_of(q->vals[i])->rc--; markGray(q->vals[i]); }
        }
    }
}
static void scanBlack(Val v) {
    if (!v.owned) return;
    Hdr *h = hdr_of(v);
    h->color = BLACK;
    if (v.tag == T_VEC) {
        Vec *q = v.as.vec;
        for (long i = 0; i < q->len; i++) if (q->items[i].owned) { hdr_of(q->items[i])->rc++; if (hdr_of(q->items[i])->color != BLACK) scanBlack(q->items[i]); }
    } else if (v.tag == T_MAP) {
        Map *q = v.as.map;
        for (long i = 0; i < q->len; i++) {
            if (q->keys[i].owned) { hdr_of(q->keys[i])->rc++; if (hdr_of(q->keys[i])->color != BLACK) scanBlack(q->keys[i]); }
            if (q->vals[i].owned) { hdr_of(q->vals[i])->rc++; if (hdr_of(q->vals[i])->color != BLACK) scanBlack(q->vals[i]); }
        }
    }
}
static void scan(Val v) {
    if (!v.owned) return;
    Hdr *h = hdr_of(v);
    if (h->color == GRAY) {
        if (h->rc > 0) scanBlack(v);
        else h->color = WHITE;
    }
}
static void collectWhite(Val v) {
    if (!v.owned) return;
    Hdr *h = hdr_of(v);
    if (h->color == WHITE && !h->onlist) {
        h->color = BLACK;                    /* never revisit; also breaks re-entry */
        if (v.tag == T_VEC) {
            Vec *q = v.as.vec;
            for (long i = 0; i < q->len; i++) collectWhite(q->items[i]);
        } else if (v.tag == T_MAP) {
            Map *q = v.as.map;
            for (long i = 0; i < q->len; i++) { collectWhite(q->keys[i]); collectWhite(q->vals[i]); }
        }
        vdestroy(v);
    }
}
static void vcollect(void) {
    long n = roots_len;
    for (long i = 0; i < n; i++) markGray(roots[i]);
    for (long i = 0; i < n; i++) scan(roots[i]);
    roots_len = 0;
    for (long i = 0; i < n; i++) {
        hdr_of(roots[i])->onlist = 0;        /* this root's turn has come */
        collectWhite(roots[i]);
    }
}
#endif

/* ---- scenarios ------------------------------------------------------------ */

static long peak_kb(void) {
    struct rusage ru;
    getrusage(RUSAGE_SELF, &ru);
    return ru.ru_maxrss;
}

/* (1) the measured 2.4 bug: s = s + "y" in a loop. */
static void scenario_concat(long n) {
    Val s = vlit("x");                 /* source literal: not owned */
    for (long i = 0; i < n; i++) {
        Val t = vadd(s, vlit("y"));    /* fresh string, owned, rc=1 */
        vrel(s);                       /* store: drop the old value */
        s = t;                         /* adopt the fresh one: no retain */
    }
    printf("concat n=%ld len=%ld peak_rss=%ldKB live=%ld\n",
           n, (long)strlen(s.as.str), peak_kb(), live_objects);
    vrel(s);
}

/* (2) aliasing: the interpreter prints "a" here (measured by run). */
static void scenario_alias(void) {
    Val a = vstr("a");
    Val b = vretain(a);                /* let b = a */
    Val u = vadd(a, vlit("b"));        /* let u = a + "b" */
    vrel(a);                           /* a = ... : b keeps the object alive */
    CHECK(strcmp(b.as.str, "a") == 0, "alias survived overwrite");
    CHECK(strcmp(u.as.str, "ab") == 0, "concat value");
    printf("alias b=%s u=%s\n", b.as.str, u.as.str);
    vrel(b); vrel(u);
}

/* (3) a shared container survives one name going away. */
static void scenario_shared_vec(void) {
    Val a = vvec();
    Val e = vstr("x");
    vec_push(a.as.vec, e);             /* the container takes its own ref */
    vrel(e);                           /* the statement temp dies (emitter flush) */
    Val b = vretain(a);                /* let b = a */
    vrel(a);                           /* overwrite a */
    CHECK(b.as.vec->len == 1, "shared vec still has its element");
    printf("shared_vec len=%ld\n", b.as.vec->len);
    vrel(b);
}

/* (4) a cycle the checker does not reject today (measured: cyc.brat passes
 * `brat check` 0 errors and runs). Eager rc alone leaks it; the collector frees it. */
static void scenario_cycle(void) {
#ifndef NO_RC
    Val m1 = vmap(), m2 = vmap();
    map_set(m1.as.map, vstr("peer"), m2);   /* m1 -> m2 */
    map_set(m2.as.map, vstr("peer"), m1);   /* m2 -> m1 : cycle */
    long before = freed_objects;
    vrel(m1);                               /* drop both external refs */
    vrel(m2);
    vcollect();
    CHECK(freed_objects - before == 2, "collector freed both cycle nodes");
    printf("cycle freed=%ld (want 2)\n", freed_objects - before);
#else
    printf("cycle skipped under NO_RC\n");
#endif
}

int main(void) {
    scenario_alias();
    scenario_shared_vec();
    scenario_cycle();
    scenario_concat(20000);
    scenario_concat(40000);
#ifndef NO_RC
    vcollect();
    CHECK(live_objects == 0, "all demo objects reclaimed");
#endif
    printf("PASS cmp=%s live=%ld freed=%ld peak=%ldKB\n",
#ifdef NO_RC
           "no-rc",
#else
           "urc",
#endif
           live_objects, freed_objects, peak_kb());
    return 0;
}
