# Balancer DESIGN (на BRAT) — передовой, открытый

## Ядро
- L4 TCP + L7 HTTP/1.1 (v0.3: H2/H3, TLS 1.3, gRPC)
- Алгоритмы: round-robin, least-conn, ip-hash, ewma-latency
- Health-check: active (http/tcp) + passive (outlier ejection)
- Event-loop: epoll сейчас, io_uring в v0.3, один бинарь, zero-copy где можно

## Почему передовой
1. Политика балансировки — кодом на BRAT, хот-релоад без рестарта
2. WAF-правила (CRS-совместимые) как функции BRAT, тюнинг одной кнопкой
3. Телеметрия из языка: каждый `proxy()` авто-пишет trace + histogram, экспорт OTLP/Prometheus
4. Детерминированный p99: нет GC-пауз (владение), бэкпрессура и shed-load из коробки
5. eBPF-хуки (план v0.4): L4 в ядре, L7 в юзерспейсе

## Телеметрия и логгер
- Логи: JSONL `{ts,lvl,msg,trace_id,up,code,ms}`, уровни, сэмплинг
- Метрики: requests, errors, latency histogram, up health, saturation
- Трейсы: span на route/proxy/health, W3C traceparent
- Экспорт: stdout, OTLP gRPC, Prometheus `/metrics`, S3-архив

## Проверено 01.10.2026
- `balancer/lb.py`: живой TCP round-robin, active health-check 2с, JSONL `{ts,lvl,msg,trace_id,up,ms}`, метрики `lb_requests/lb_errors/lb_latency_p50_p99/lb_up_ok`
- `balancer/test_lb.py`: 2 эхо-бэкенда, 6 хитов ходят на обе ноды, kill одной ноды, 3 хита только на живую, `/metrics` отдает `lb_requests`, все строки лога валидный JSON с `trace_id`+`up`
- Прогон: `python balancer\test_lb.py` → ALL GREEN (10 routed)

## Open-source модель
- Core Apache-2.0: прокси, LB, WAF-движок, OTel
- PRO (позже): SSO, мультикластер, AI-автотюнинг false-positive, compliance-пакеты, managed Cloud
- Виральность: бенч `wrk` vs Nginx/HAProxy/Caddy, статья "25 строк вместо 200", воспроизводимый docker-bench

## Проверено 2026-10-01 evening (B4)
- Регрессия зеленая:
  - `python balancer\test_lb.py` → `round-robin ok`, `failover ok: B1 serves alone`, `metrics ok`, `logs ok: 10 routed, all JSON`, `ALL GREEN`
  - `python "C:\Users\1F1C~1\AppData\Local\Temp\opencode\run_bench_b4.py"` (2 echo-бэкенда + реальный `lb.py`, LB-порт 58272) → `BENCH_VERIFY_DONE`, обе точки 0 errors
- Бенч `bench.py` через реальный `lb.py` (loopback, single run per point, Python 3.14.7, Athlon X4 840):
  - `2 x 20 (total 40)`: rps 778.7, conn p50/p99 0.19/12.36 ms, roundtrip p50/p99 1.38/3.34 ms
  - `16 x 25 (total 400)`: rps 475.4, conn p50/p99 0.24/11.09 ms, roundtrip p50/p99 17.12/309.04 ms (p99-хвост — GIL/шедулинг на 4 ядрах, не steady-state)
- До продакшена не хватает: TLS 1.3 termination, HTTP/2, io_uring event-loop (сейчас threads+GIL), LLVM codegen (нет llvmlite/lli/clang на хосте — см. `compiler/LLVM_NOTES.md`), сравнение с nginx/HAProxy через wrk, многократные прогоны + LAN/WAN замеры.

## Проверено 2026-10-01 night (production push)
- LLVM настоящий: `python lang\engine\codegen_llvm.py` → `LLVM-JIT OK: add(40,2)=42 fib(20)=6765` (llvmlite 0.50, MCJIT, нативное исполнение).
- Медиана 3 прогонов `bench/rounds.py`: light rps=799.4 p99=2.95ms, heavy rps=934.9 p99=19.76ms, errors=0.
- lb.py: graceful shutdown с дренированием, --max-conns, --config JSON, lb_inflight. `test_lb.py` ALL GREEN.
- TLS: `mkcert.py` (stdlib RSA+X.509 ~0.8s) + `tls.py` (TLS 1.2+, sni в логах). `test_tls.py` ALL GREEN.
- SNI: `sni.py` exact+wildcard, fuzz 200 без падений. `test_sni.py` ALL GREEN.
- L7 keep-alive: 100 reqs/conn, trace_id на запрос. `test_l7.py` ALL GREEN (25 asserts).
- pool: 4 алгоритма, eject/resurrect, race-тест. `test_pool2.py` ALL GREEN.
- Язык единый: hello/balancer/control через `brat.py` exit 0; borrow 0/0/0/0/4.
- Остаток до продакшена: HTTP/2, io_uring (Linux), wrk-сравнение, C compile+run, OTLP-binary, L7 backend reuse.

## Nginx parity (refs/parity.md)

Счет 8 done / 2 partial / 5 missing. Топ-3 missing: X-Forwarded-* injection,
rate limit 429, weighted RR. Детали по строкам — в `refs/parity.md`.
