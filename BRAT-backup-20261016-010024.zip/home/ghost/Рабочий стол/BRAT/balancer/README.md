# balancer — BRAT edge gateway

## Engine (`engine/`)

| File | Role |
|------|------|
| `lb.py` | TCP round-robin LB: health-check, JSONL, `/metrics`, shutdown, max-conns, config |
| `pool.py` | Pools over `algos.py` pickers |
| `algos.py` | RoundRobin / LeastConn / IpHash / EwmaPicker |
| `gateway.py` | L7 Host routing + keep-alive + WAF hook |
| `tls.py` | TLS 1.2+ termination, SNI in logs |
| `mkcert.py` | Test-only stdlib self-signed certs |
| `sni.py` | ClientHello SNI sniff, exact + wildcard tables |
| `http_parse.py` | HTTP/1.1 parser on raw bytes |
| `waf.py` | SQLi/XSS/traversal/RCE rule pack |
| `otel.py` | Batcher, sampler, OTLP mapping, Prometheus extras |

## Tests (`tests/`)

One file per area: `test_lb`, `test_pool2`, `test_l7`, `test_l7waf`, `test_tls`,
`test_sni`, `test_http`, `test_algos`, `test_otel`. No test lives next to the engine.

## Examples / refs / design

- `examples/balancer.brat` — policy on BRAT.
- `refs/nginx-ops.md` — vendored nginx parity reference (MIT).
- `DESIGN.md` — architecture + verified measurements.
