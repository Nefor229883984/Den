import os as _o, sys as _s
_s.path.insert(0, _o.path.join(_o.path.dirname(_o.path.abspath(__file__)), '..', 'engine'))
from algos import RoundRobin, LeastConn, IpHash, EwmaPicker


def check_round_robin():
    rr = RoundRobin()
    ups = ["a", "b", "c"]
    got = [rr.pick(ups) for _ in range(6)]
    assert got == ["a", "b", "c", "a", "b", "c"], got
    one = ["solo"]
    assert [rr.pick(one) for _ in range(3)] == ["solo"] * 3


def check_least_conn():
    lc = LeastConn()
    ups = ["a", "b"]
    assert lc.pick(ups) in ups
    lc.acquire("a")
    lc.acquire("a")
    assert lc.pick(ups) == "b", "busy node must be avoided"
    lc.release("a")
    lc.release("a")
    assert lc.pick(ups) == "a"
    lc.release("a")
    assert lc.pick(ups) == "a"


def check_iphash():
    ih = IpHash()
    ups = ["a", "b", "c"]
    for ip in ["10.0.0.1", "192.168.1.7", ""]:
        assert ih.pick(ups, ip) == ih.pick(ups, ip), ip
    seen = {ih.pick(ups, f"10.0.0.{i}") for i in range(100)}
    assert len(seen) > 1, seen


def check_ewma():
    ew = EwmaPicker()
    ups = ["fast", "slow"]
    for _ in range(20):
        ew.observe("fast", 10.0)
        ew.observe("slow", 300.0)
    assert ew.pick(ups) == "fast"
    for _ in range(50):
        ew.observe("slow", 5.0)
    assert ew.pick(ups) == "slow"


def check_empty():
    for p in (RoundRobin(), LeastConn(), IpHash(), EwmaPicker()):
        try:
            p.pick([])
        except ValueError:
            continue
        raise AssertionError(f"{type(p).__name__} must raise on empty healthy")


def main():
    check_round_robin()
    check_least_conn()
    check_iphash()
    check_ewma()
    check_empty()
    print("ALL GREEN")


if __name__ == "__main__":
    main()
