"""Tests for PoolV2. Fake upstreams; real sockets only in health-probe check."""
import os
import socket
import sys
import threading

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'engine'))

from lb import Log, Metrics
from pool import PoolV2

ALGOS = ["round-robin", "least-conn", "ip-hash", "ewma"]
UPS = ["a", "b", "c"]


def make(algo, ups=None):
    return PoolV2(list(ups or UPS), Log(), Metrics(), algo=algo)


def check_all_pick():
    for algo in ALGOS:
        p = make(algo)
        got = p.pick(client_ip="10.0.0.1")
        assert got in UPS, (algo, got)
        got2 = p.pick()
        assert got2 in UPS, (algo, got2)
        before = p.metrics.requests
        p.release(got)
        p.release(got2)
        p.note(got, 5.0, True)
        assert p.metrics.requests == before + 1, (algo, p.metrics.requests)
    print("ok all-pick")


def check_eject_zero_picks():
    for algo in ALGOS:
        p = make(algo)
        p.mark_down("b")
        assert p.alive["b"] is False, algo
        assert p.metrics.up_ok["b"] == 0, (algo, p.metrics.up_ok)
        for i in range(20):
            got = p.pick(client_ip="10.9.0.%d" % i)
            assert got in ("a", "c"), (algo, got)
            p.release(got)
    print("ok eject-zero-picks")


def check_resurrect():
    p = make("round-robin")
    p.mark_down("b")
    p.mark_up("b")
    assert p.metrics.up_ok["b"] == 1, p.metrics.up_ok
    got = [p.pick() for _ in range(6)]
    assert "b" in got, ("round-robin", got)

    p = make("least-conn")
    p.mark_down("b")
    p.mark_up("b")
    p.mark_down("a")
    p.mark_down("c")
    try:
        assert p.pick() == "b", "sole survivor must be picked"
    finally:
        p.mark_up("a")
        p.mark_up("c")

    p = make("ip-hash")
    p.mark_down("b")
    p.mark_up("b")
    found = None
    for i in range(500):
        ip = "192.168.7.%d" % i
        if p.pick(client_ip=ip) == "b":
            found = ip
            break
    assert found is not None, "resurrected node must be routable"

    p = make("ewma")
    p.mark_down("b")
    p.mark_up("b")
    for _ in range(10):
        p.note("a", 300.0, True)
        p.note("c", 300.0, True)
        p.note("b", 5.0, True)
    assert p.pick() == "b", "fast resurrected node must win ewma"
    print("ok resurrect")


def check_unknown():
    for bad in ("nope", "random", ""):
        try:
            make(bad)
        except ValueError:
            continue
        raise AssertionError("algo %r must raise ValueError" % (bad,))
    print("ok unknown-algo")


def check_empty_none():
    for algo in ALGOS:
        p = make(algo)
        for u in UPS:
            p.mark_down(u)
        assert p.pick() is None, algo
        p.mark_up("a")
        assert p.pick() == "a", algo
    print("ok empty-none")


def check_health_dial():
    srv = socket.socket()
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("127.0.0.1", 0))
    srv.listen(1)
    port = srv.getsockname()[1]
    try:
        p = make("round-robin", ["127.0.0.1:%d" % port])
        assert p.healthy("127.0.0.1:%d" % port) is True
    finally:
        srv.close()
    tmp = socket.socket()
    tmp.bind(("127.0.0.1", 0))
    closed = tmp.getsockname()[1]
    tmp.close()
    p = make("round-robin", ["127.0.0.1:%d" % closed])
    assert p.healthy("127.0.0.1:%d" % closed) is False
    print("ok health-dial")


def check_threads():
    for algo in ("round-robin", "least-conn"):
        p = make(algo)

        def worker():
            for i in range(100):
                u = p.pick(client_ip="10.0.0.%d" % (i % 8))
                p.note(u, 1.0, True)
                p.release(u)

        ts = [threading.Thread(target=worker) for _ in range(8)]
        for t in ts:
            t.start()
        for t in ts:
            t.join()
    print("ok threads")


def main():
    check_all_pick()
    check_eject_zero_picks()
    check_resurrect()
    check_unknown()
    check_empty_none()
    check_health_dial()
    check_threads()
    print("ALL GREEN")


if __name__ == "__main__":
    main()
