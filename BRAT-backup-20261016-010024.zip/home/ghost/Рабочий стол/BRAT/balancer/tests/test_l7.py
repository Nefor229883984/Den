"""L7 asserts for brat-lb: real sockets, Host routing, 400 survival."""
import json
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time

import os as _o
L7 = _o.path.join(_o.path.dirname(_o.path.abspath(__file__)), '..', 'engine', 'gateway.py')


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def start_backend(port, tag, stop, seen):
    srv = socket.socket()
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("127.0.0.1", port))
    srv.listen(32)
    srv.settimeout(0.5)

    def read_head(c):
        buf = b""
        c.settimeout(5.0)
        while b"\r\n\r\n" not in buf:
            chunk = c.recv(4096)
            if not chunk:
                break
            buf += chunk
            if len(buf) > 65536:
                break
        return buf

    def handle(c):
        try:
            buf = read_head(c)
            if not buf:
                return
            head, _, rest = buf.partition(b"\r\n\r\n")
            lines = head.split(b"\r\n")
            target = b"/"
            try:
                parts = lines[0].decode("latin-1").split(" ")
                if len(parts) == 3:
                    target = parts[1].encode("latin-1")
            except (IndexError, ValueError):
                pass
            clen = 0
            for raw in lines[1:]:
                if b":" in raw:
                    k, v = raw.split(b":", 1)
                    if k.strip().lower() == b"content-length":
                        try:
                            clen = int(v.strip())
                        except ValueError:
                            clen = 0
            body = rest
            while len(body) < clen:
                chunk = c.recv(4096)
                if not chunk:
                    break
                body += chunk
            seen.append((target, body[:clen]))
            payload = b"FROM:" + tag + b":" + target
            resp = (b"HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n"
                    b"Content-Length: %d\r\nConnection: close\r\n\r\n"
                    % len(payload)) + payload
            c.sendall(resp)
        except OSError:
            pass
        finally:
            try:
                c.close()
            except OSError:
                pass

    def loop():
        while not stop.is_set():
            try:
                c, _ = srv.accept()
            except socket.timeout:
                continue
            except OSError:
                return
            threading.Thread(target=handle, args=(c,),
                             daemon=True).start()
        srv.close()

    threading.Thread(target=loop, daemon=True).start()
    return srv


def request(port, payload, timeout=5):
    s = socket.create_connection(("127.0.0.1", port), timeout=timeout)
    s.settimeout(timeout)
    s.sendall(payload)
    try:
        s.shutdown(socket.SHUT_WR)
    except OSError:
        pass
    out = b""
    while True:
        try:
            chunk = s.recv(65536)
        except socket.timeout:
            break
        if not chunk:
            break
        out += chunk
    s.close()
    return out


def wait_for(port, tries=100):
    for _ in range(tries):
        try:
            s = socket.create_connection(("127.0.0.1", port), timeout=1)
            s.close()
            return
        except OSError:
            time.sleep(0.1)
    raise RuntimeError("port never opened %d" % port)


def read_one_response(s, leftover, timeout=5):
    s.settimeout(timeout)
    buf = leftover
    while b"\r\n\r\n" not in buf:
        chunk = s.recv(65536)
        if not chunk:
            raise ConnectionError("closed before head")
        buf += chunk
    sep = buf.find(b"\r\n\r\n")
    head = buf[:sep + 4]
    clen = 0
    try:
        hs = head.decode("latin-1")
        for line in hs.split("\r\n")[1:]:
            if ":" in line:
                k, v = line.split(":", 1)
                if k.strip().lower() == "content-length":
                    clen = int(v.strip())
    except (ValueError, IndexError):
        clen = 0
    total = sep + 4 + clen
    while len(buf) < total:
        chunk = s.recv(65536)
        if not chunk:
            break
        buf += chunk
    full = buf[:total]
    rest = buf[total:]
    return full, rest


def main():
    n = 0

    def check(cond, msg):
        nonlocal n
        assert cond, msg
        n += 1
        print("ok: %s" % msg, flush=True)

    b1, b2 = free_port(), free_port()
    lp, mp = free_port(), free_port()
    stop1, stop2 = threading.Event(), threading.Event()
    seen1, seen2 = [], []
    start_backend(b1, b"h1", stop1, seen1)
    start_backend(b2, b"h2", stop2, seen2)
    fd, logpath = tempfile.mkstemp(prefix="brat-l7-", suffix=".jsonl")
    os.close(fd)
    lb = subprocess.Popen(
        [sys.executable, L7, "--listen", "127.0.0.1:%d" % lp,
         "--route", "h1=127.0.0.1:%d;h2=127.0.0.1:%d" % (b1, b2),
         "--log", logpath, "--metrics-port", str(mp)],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    try:
        wait_for(lp)
        wait_for(mp)
        r = request(lp, b"GET /a HTTP/1.1\r\nHost: h1\r\n"
                       b"Connection: close\r\n\r\n")
        check(b"FROM:h1" in r and b"/a" in r, "Host h1 hits pool h1")
        r = request(lp, b"GET /a HTTP/1.1\r\nHost: h2\r\n"
                       b"Connection: close\r\n\r\n")
        check(b"FROM:h2" in r and b"/a" in r, "Host h2 hits pool h2")
        r = request(lp, b"GET /b HTTP/1.1\r\nHost: h1:9999\r\n"
                       b"Connection: close\r\n\r\n")
        check(b"FROM:h1" in r and b"/b" in r, "Host h1:port hits pool h1")
        r = request(lp, b"POST /submit HTTP/1.1\r\nHost: h1\r\n"
                       b"Content-Length: 5\r\nConnection: close\r\n\r\n"
                       b"hello")
        check(b"FROM:h1" in r and b"/submit" in r, "POST proxied to h1")
        check(any(t == b"/submit" and bdy == b"hello" for t, bdy in seen1),
              "POST body arrived intact")
        r = request(lp, b"\x00\xffgarbage!!!")
        check(r.startswith(b"HTTP/1.1 400"), "garbage gets 400")
        r = request(lp, b"GET /bad\r\n\r\n")
        check(b"HTTP/1.1 400" in r, "bad request line gets 400")
        r = request(lp, b"GET /a HTTP/1.1\r\nHost: unknown.test\r\n"
                       b"Connection: close\r\n\r\n")
        check(b"HTTP/1.1 404" in r, "unknown host gets 404")
        assert lb.poll() is None, "server died on malformed input"
        r = request(lp, b"GET /a HTTP/1.1\r\nHost: h2\r\n"
                       b"Connection: close\r\n\r\n")
        check(b"FROM:h2" in r, "server stays up after 400/404")
        m = request(mp, b"GET /metrics HTTP/1.0\r\n\r\n")
        check(b"lb_requests" in m, "metrics has lb_requests")
        check(b"lb_errors" in m, "metrics has lb_errors")
        s = socket.create_connection(("127.0.0.1", lp), timeout=5)
        s.settimeout(5)
        s.sendall(b"GET /ka1 HTTP/1.1\r\nHost: h1\r\nConnection: keep-alive\r\n\r\n"
                  b"GET /ka2 HTTP/1.1\r\nHost: h1\r\nConnection: keep-alive\r\n\r\n")
        left = b""
        r1, left = read_one_response(s, left, timeout=5)
        r2, left = read_one_response(s, left, timeout=5)
        check(b"FROM:h1" in r1 and b"/ka1" in r1, "pipelined req1 answered")
        check(b"FROM:h1" in r2 and b"/ka2" in r2, "pipelined req2 answered")
        s.close()
        s = socket.create_connection(("127.0.0.1", lp), timeout=5)
        s.settimeout(5)
        s.sendall(b"GET /close1 HTTP/1.1\r\nHost: h1\r\nConnection: close\r\n\r\n")
        full, _rest = read_one_response(s, b"", timeout=5)
        check(b"FROM:h1" in full, "close req answered")
        s.settimeout(2)
        try:
            tail = s.recv(65536)
        except socket.timeout:
            tail = b"timeout"
        except OSError:
            tail = b""
        check(tail == b"", "Connection: close closes (recv b'')")
        s.close()
        s = socket.create_connection(("127.0.0.1", lp), timeout=5)
        s.settimeout(5)
        left = b""
        okc = 0
        for i in range(101):
            try:
                s.sendall(b"GET /cap%d HTTP/1.1\r\nHost: h1\r\nConnection: keep-alive\r\n\r\n" % i)
            except OSError:
                break
            try:
                full, left = read_one_response(s, left, timeout=5)
            except (ConnectionError, socket.timeout, OSError):
                break
            if b"FROM:h1" not in full:
                break
            okc += 1
        check(okc == 100, "100 reqs served on one conn (%d)" % okc)
        s.settimeout(2)
        try:
            probe = s.recv(65536)
        except socket.timeout:
            probe = b"timeout"
        except OSError:
            probe = b""
        check(probe == b"", "101st request closed-after-response")
        s.close()
    finally:
        lb.terminate()
        try:
            lb.wait(timeout=5)
        except subprocess.TimeoutExpired:
            lb.kill()
        stop1.set()
        stop2.set()
    routes, errors, total = 0, 0, 0
    with open(logpath, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            total += 1
            rec = json.loads(line)
            assert {"ts", "lvl", "msg", "trace_id"} <= set(rec), rec
            assert rec["trace_id"], rec
            if rec["msg"] in ("route", "done"):
                routes += 1
                assert {"up", "method", "target"} <= set(rec), rec
            if rec["lvl"] == "ERROR":
                errors += 1
    check(total >= 9, "log has all lines (%d)" % total)
    check(routes >= 10, "route/done lines logged (%d)" % routes)
    check(errors >= 3, "error lines for 400/404 (%d)" % errors)
    recs = []
    with open(logpath, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            recs.append(json.loads(line))
    check(all({"ts", "lvl", "msg", "trace_id"} <= set(r) for r in recs), "log still all-valid-JSON")
    conns = [r for r in recs if r["msg"] == "conn"]
    check(len(conns) >= 3, "conn lines logged (%d)" % len(conns))
    check(all("reqs" in r for r in conns), "conn lines carry reqs")
    route_tids = [r["trace_id"] for r in recs if r["msg"] == "route"]
    check(len(route_tids) >= 5, "route trace_ids present (%d)" % len(route_tids))
    check(len(set(route_tids)) == len(route_tids), "per-request trace_ids differ (%d unique)" % len(set(route_tids)))
    os.unlink(logpath)
    print("ALL GREEN (%d asserts)" % n)


if __name__ == "__main__":
    main()
