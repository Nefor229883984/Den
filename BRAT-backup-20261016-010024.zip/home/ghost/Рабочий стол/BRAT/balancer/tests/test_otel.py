import random
import time

import os as _o, sys as _s
_s.path.insert(0, _o.path.join(_o.path.dirname(_o.path.abspath(__file__)), '..', 'engine'))
from otel import Batcher, prom_extra, sample, to_otlp


def mkspan(i=0):
    return {
        "trace_id": "trace%06d" % i,
        "span_id": "span%06d" % i,
        "name": "route",
        "startUnixNano": 1700000000000000000 + i * 1000,
        "endUnixNano": 1700000000000000000 + i * 1000 + 500,
        "attributes": {"up": "127.0.0.1:900%d" % (i % 2), "route": "tcp"},
    }


def test_flush_by_count():
    got = []
    b = Batcher(max_size=100, flush_count=5, flush_interval=3600, sink=got.extend)
    for i in range(4):
        assert b.add(mkspan(i)) is True
        assert len(got) == 0, got
    assert b.add(mkspan(4)) is True
    assert len(got) == 5, len(got)
    assert len(b) == 0
    b.add(mkspan(5))
    rest = b.flush()
    assert len(rest) == 1
    assert len(got) == 6


def test_drop_counter():
    got = []
    b = Batcher(max_size=3, flush_count=100000, flush_interval=3600, sink=got.extend)
    assert b.add(mkspan(0)) is True
    assert b.add(mkspan(1)) is True
    assert b.add(mkspan(2)) is True
    assert b.dropped == 0
    assert b.add(mkspan(3)) is False
    assert b.add(mkspan(4)) is False
    assert b.dropped == 2, b.dropped
    assert len(b) == 3
    out = b.flush()
    assert len(out) == 3
    assert len(got) == 3


def test_sampler():
    random.seed(7)
    n = 2000
    kept = sum(1 for _ in range(n) if sample(0.5))
    assert 800 <= kept <= 1200, kept
    assert sample(1.0) is True
    assert sample(0.0) is False
    assert sum(1 for _ in range(50) if sample(1.0)) == 50
    assert sum(1 for _ in range(50) if sample(0.0)) == 0


def test_to_otlp_keys():
    d = to_otlp(mkspan(1))
    for k in ("traceId", "spanId", "name", "startUnixNano", "endUnixNano", "attributes"):
        assert k in d, d
    assert isinstance(d["attributes"], dict)
    assert d["startUnixNano"] <= d["endUnixNano"]


def test_never_raises_on_bad_input():
    bad = [None, 0, "", [], {}, {"name": None}, {"start": "xx"}, object()]
    for v in bad:
        to_otlp(v)
        sample(v) if not isinstance(v, dict) else sample("bad-rate")
        prom_extra(v)
    b = Batcher(max_size=4, flush_count=100000, flush_interval=3600, sink=None)
    for v in bad:
        b.add(v)
    b.flush()
    b.flush_if_due()
    assert prom_extra({"nope": 1}) == ""
    assert prom_extra({"lb_requests": 3}).strip() == "lb_requests 3"
    extra = prom_extra({"lb_up_ok": {"value": 1, "labels": {"up": "a", "user_id": "x"}}})
    assert 'up="a"' in extra
    assert "user_id" not in extra


def test_interval_flush():
    got = []
    b = Batcher(max_size=100, flush_count=100000, flush_interval=0.05, sink=got.extend)
    b.add(mkspan(0))
    assert len(got) == 0
    time.sleep(0.08)
    b.flush_if_due()
    assert len(got) == 1, len(got)


def main():
    test_flush_by_count()
    print("flush-by-count ok")
    test_drop_counter()
    print("drop-counter ok")
    test_sampler()
    print("sampler ok")
    test_to_otlp_keys()
    print("to-otlp ok")
    test_never_raises_on_bad_input()
    print("bad-input ok")
    test_interval_flush()
    print("interval ok")
    print("ALL GREEN")


if __name__ == "__main__":
    main()
