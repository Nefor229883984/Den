"""TLS frontend test: mkcert load, echo via TLS, SNI log, garbage resilience, JSONL."""
import json
import os
import socket
import ssl
import subprocess
import sys
import tempfile
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ENGINE = os.path.join(HERE, '..', 'engine')
MKCERT = os.path.join(ENGINE, "mkcert.py")
FRONT = os.path.join(ENGINE, "tls.py")
CACHE_DIR = os.path.join(tempfile.gettempdir(), "opencode")
CACHE_SUB = os.path.join(CACHE_DIR, "brat_tls_test")


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def start_echo():
    srv = socket.socket()
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("127.0.0.1", 0))
    srv.listen(32)
    srv.settimeout(0.5)
    port = srv.getsockname()[1]
    stop = threading.Event()

    def conn_loop(c):
        try:
            c.settimeout(5.0)
            while True:
                b = c.recv(65536)
                if not b:
                    return
                c.sendall(b)
        except OSError:
            return
        finally:
            try:
                c.close()
            except OSError:
                pass

    def accept_loop():
        while not stop.is_set():
            try:
                c, _ = srv.accept()
            except socket.timeout:
                continue
            except OSError:
                return
            threading.Thread(target=conn_loop, args=(c,), daemon=True).start()

    threading.Thread(target=accept_loop, daemon=True).start()
    return srv, stop, port


def ensure_certs():
    try:
        os.makedirs(CACHE_SUB, exist_ok=True)
        use_cache = CACHE_SUB
    except OSError:
        use_cache = tempfile.mkdtemp(prefix="brat_tls_")
        os.makedirs(use_cache, exist_ok=True)
    cp = os.path.join(use_cache, "cert.pem")
    kp = os.path.join(use_cache, "key.pem")
    fresh = False
    if os.path.exists(cp) and os.path.exists(kp):
        age = time.time() - min(os.path.getmtime(cp), os.path.getmtime(kp))
        if age < 3600 and os.path.getsize(cp) > 300 and os.path.getsize(kp) > 300:
            fresh = True
    if not fresh:
        r = subprocess.run(
            [sys.executable, MKCERT, "--cn", "localhost",
             "--san", "localhost,h1.test", "--out", use_cache],
            capture_output=True, text=True, timeout=170,
        )
        if r.returncode != 0:
            raise RuntimeError("mkcert failed: %s %s" % (r.stdout, r.stderr))
    return cp, kp


def tls_send(port, msg, sni):
    cctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    cctx.check_hostname = False
    cctx.verify_mode = ssl.CERT_NONE
    raw = socket.create_connection(("127.0.0.1", port), timeout=10)
    tls = cctx.wrap_socket(raw, server_hostname=sni)
    tls.settimeout(10)
    tls.sendall(msg)
    got = b""
    while len(got) < len(msg):
        chunk = tls.recv(65536)
        if not chunk:
            break
        got += chunk
    try:
        tls.close()
    except OSError:
        pass
    return got


def main():
    cp, kp = ensure_certs()
    sctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    sctx.load_cert_chain(cp, kp)
    cctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    cctx.check_hostname = False
    cctx.verify_mode = ssl.CERT_NONE
    cctx.load_verify_locations(cafile=cp)
    print("cert load ok")
    srv1, stop1, p1 = start_echo()
    srv2, stop2, p2 = start_echo()
    tmpd = tempfile.mkdtemp(prefix="brat_tls_log_")
    logf = os.path.join(tmpd, "tls.log")
    lport = free_port()
    mport = free_port()
    proc = subprocess.Popen(
        [sys.executable, FRONT, "--listen", "127.0.0.1:%d" % lport,
         "--cert", cp, "--key", kp,
         "--up", "127.0.0.1:%d,127.0.0.1:%d" % (p1, p2),
         "--log", logf, "--metrics-port", str(mport)],
        stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT,
    )
    try:
        ok = False
        for _ in range(150):
            if proc.poll() is not None:
                raise RuntimeError("tls exited early code=%s" % proc.poll())
            try:
                got = tls_send(lport, b"hello-tls", "localhost")
                if got == b"hello-tls":
                    ok = True
                    break
            except Exception:
                time.sleep(0.1)
        assert ok, "tls never became ready"
        print("echo ok")
        got = tls_send(lport, b"hello-sni", "h1.test")
        assert got == b"hello-sni", "sni echo mismatch: %r" % got
        print("sni echo ok")
        time.sleep(0.5)
        s = socket.create_connection(("127.0.0.1", lport), timeout=10)
        try:
            s.sendall(b"GET / HTTP/1.0\r\n\r\nplain-garbage-123")
        except OSError:
            pass
        time.sleep(0.3)
        try:
            s.close()
        except OSError:
            pass
        time.sleep(0.5)
        assert proc.poll() is None, "server died on plaintext garbage"
        got = tls_send(lport, b"after-garbage", "localhost")
        assert got == b"after-garbage", "post-garbage echo failed: %r" % got
        print("garbage resilience ok")
        time.sleep(0.5)
        assert os.path.exists(logf), "no log file"
        with open(logf, encoding="utf-8") as f:
            lines = [ln for ln in f.read().splitlines() if ln.strip()]
        assert lines, "empty log"
        recs = []
        for ln in lines:
            recs.append(json.loads(ln))
        for r in recs:
            assert "ts" in r and "lvl" in r and "msg" in r, "bad log shape: %r" % r
        found = [r for r in recs if r.get("sni") == "h1.test"]
        assert found, "no log line carries sni=h1.test"
        print("sni log ok (%d lines)" % len(recs))
        print("ALL GREEN")
    finally:
        try:
            proc.terminate()
        except Exception:
            pass
        try:
            proc.wait(timeout=10)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass
        stop1.set()
        stop2.set()
        try:
            srv1.close()
        except OSError:
            pass
        try:
            srv2.close()
        except OSError:
            pass


if __name__ == "__main__":
    main()
