import json
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ENGINE = os.path.join(HERE, '..', 'engine')
L7 = os.path.join(ENGINE, 'gateway.py')

_hits = [0]


def check(cond, msg):
    assert cond, msg
    _hits[0] += 1


def free_port():
    s = socket.socket()
    s.bind(('127.0.0.1', 0))
    p = s.getsockname()[1]
    s.close()
    return p


def start_echo(port, stop):
    srv = socket.socket()
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(('127.0.0.1', port))
    srv.listen(32)
    srv.settimeout(0.5)

    def handle(c):
        try:
            c.settimeout(3.0)
            data = c.recv(65536)
            if data:
                c.sendall(b'HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nok')
        except OSError:
            pass
        finally:
            try:
                c.close()
            except OSError:
                pass

    def loop():
        while not stop.is_set():
            try:
                c, _ = srv.accept()
            except socket.timeout:
                continue
            threading.Thread(target=handle, args=(c,), daemon=True).start()
        srv.close()

    threading.Thread(target=loop, daemon=True).start()


def raw_request(port, payload, host='h1'):
    s = socket.create_connection(('127.0.0.1', port), timeout=10)
    s.sendall(payload.replace(b'$HOST', host.encode()))
    out = b''
    while True:
        try:
            b = s.recv(65536)
        except socket.timeout:
            break
        if not b:
            break
        out += b
    s.close()
    return out


def main():
    b1, lp, mp = free_port(), free_port(), free_port()
    stop = threading.Event()
    start_echo(b1, stop)
    fd, logpath = tempfile.mkstemp(prefix='brat-l7waf-', suffix='.jsonl')
    os.close(fd)
    l7 = subprocess.Popen(
        [sys.executable, L7, '--listen', '127.0.0.1:%d' % lp,
         '--route', 'h1=127.0.0.1:%d' % b1,
         '--log', logpath, '--metrics-port', str(mp)],
        stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
    try:
        for _ in range(50):
            try:
                socket.create_connection(('127.0.0.1', lp), timeout=1).close()
                break
            except OSError:
                time.sleep(0.1)
        attack = (b"GET /?x=%27%20OR%20%271%27=%271 HTTP/1.1\r\nHost: $HOST\r\n"
                  b"Connection: close\r\n\r\n")
        r = raw_request(lp, attack)
        check(b'403' in r, 'sqli blocked 403: ' + repr(r[:60]))
        xss = (b"GET /<script>alert(1)</script> HTTP/1.1\r\nHost: $HOST\r\n"
               b"Connection: close\r\n\r\n")
        r = raw_request(lp, xss)
        check(b'403' in r, 'xss blocked 403')
        clean = b"GET /hi HTTP/1.1\r\nHost: $HOST\r\nConnection: close\r\n\r\n"
        r = raw_request(lp, clean)
        check(b'200 OK' in r, 'clean proxied: ' + repr(r[:60]))
    finally:
        l7.terminate()
        l7.wait(timeout=10)
        stop.set()
    denies = 0
    with open(logpath, encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rec = json.loads(line)
            assert {'ts', 'lvl', 'msg'} <= set(rec), rec
            if rec['msg'] == 'waf deny':
                denies += 1
                assert 'rule' in rec and 'trace_id' in rec, rec
    check(denies == 2, 'two waf denies logged, got %d' % denies)
    os.unlink(logpath)
    print('L7WAF ALL GREEN (%d asserts)' % _hits[0], flush=True)


if __name__ == '__main__':
    main()
