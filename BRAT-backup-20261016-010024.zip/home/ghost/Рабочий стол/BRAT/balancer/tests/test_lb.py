import json, os, socket, subprocess, sys, tempfile, threading, time

import os as _o
LB = _o.path.join(_o.path.dirname(_o.path.abspath(__file__)), '..', 'engine', 'lb.py')

def free_port():
    s = socket.socket()
    s.bind(('127.0.0.1', 0))
    p = s.getsockname()[1]
    s.close()
    return p

def start_echo(port, tag, stop):
    srv = socket.socket()
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(('127.0.0.1', port))
    srv.listen(32)
    srv.settimeout(0.5)
    def loop():
        while not stop.is_set():
            try:
                c, _ = srv.accept()
            except socket.timeout:
                continue
            t = threading.Thread(target=handle, args=(c,), daemon=True)
            t.start()
        srv.close()
    def handle(c):
        try:
            c.settimeout(2.0)
            data = c.recv(4096)
            if data:
                c.sendall(b'from:' + tag + b':' + data)
        except OSError:
            pass
        finally:
            try:
                c.close()
            except OSError:
                pass
    threading.Thread(target=loop, daemon=True).start()
    return srv

def hit(port, payload):
    s = socket.create_connection(('127.0.0.1', port), timeout=5)
    s.sendall(payload)
    s.shutdown(socket.SHUT_WR)
    out = b''
    while True:
        b = s.recv(4096)
        if not b:
            break
        out += b
    s.close()
    return out

def wait_for(port, tries=50):
    for _ in range(tries):
        try:
            s = socket.create_connection(('127.0.0.1', port), timeout=1)
            s.close()
            return
        except OSError:
            time.sleep(0.1)
    raise RuntimeError('port never opened %d' % port)

def main():
    b1, b2 = free_port(), free_port()
    lp, mp = free_port(), free_port()
    stop1, stop2 = threading.Event(), threading.Event()
    start_echo(b1, b'B1', stop1)
    start_echo(b2, b'B2', stop2)
    fd, logpath = tempfile.mkstemp(prefix='brat-lb-', suffix='.jsonl')
    os.close(fd)
    lb = subprocess.Popen(
        [sys.executable, LB, '--listen', '127.0.0.1:%d' % lp,
         '--up', '127.0.0.1:%d,127.0.0.1:%d' % (b1, b2),
         '--log', logpath, '--metrics-port', str(mp)],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    try:
        wait_for(lp)
        seen = set()
        for i in range(6):
            r = hit(lp, ('ping-%d' % i).encode())
            assert r.startswith(b'from:'), r
            seen.add(r.split(b':')[1])
            time.sleep(0.05)
        assert seen == {b'B1', b'B2'}, seen
        print('round-robin ok:', seen)
        stop2.set()
        time.sleep(3.5)
        for i in range(3):
            r = hit(lp, b'after-kill')
            assert b'B1' in r, r
        print('failover ok: B1 serves alone')
        s = socket.create_connection(('127.0.0.1', mp), timeout=5)
        s.sendall(b'GET /metrics HTTP/1.0\r\n\r\n')
        body = b''
        while True:
            b = s.recv(4096)
            if not b:
                break
            body += b
        s.close()
        assert b'lb_requests' in body, body[:200]
        print('metrics ok')
    finally:
        lb.terminate()
        try:
            lb.wait(timeout=5)
        except subprocess.TimeoutExpired:
            lb.kill()
        stop1.set()
    bad = 0
    routes = 0
    with open(logpath, encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rec = json.loads(line)
            assert {'ts', 'lvl', 'msg'} <= set(rec), rec
            if rec['msg'] == 'route':
                routes += 1
                assert 'trace_id' in rec and 'up' in rec, rec
    assert routes >= 9, routes
    print('logs ok: %d routed, all JSON' % routes)
    os.unlink(logpath)
    print('ALL GREEN')

if __name__ == '__main__':
    main()
