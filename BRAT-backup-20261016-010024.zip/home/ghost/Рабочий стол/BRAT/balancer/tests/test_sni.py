import os
import random
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'engine'))

from sni import peek_sni, pick_by_sni


def u16(n):
    return bytes([(n >> 8) & 0xFF, n & 0xFF])


def u24(n):
    return bytes([(n >> 16) & 0xFF, (n >> 8) & 0xFF, n & 0xFF])


def build_hello(sni=None, extra_ext=True):
    rnd = bytes(range(32))
    exts = b""
    if sni is not None:
        host = sni.encode("ascii")
        entry = b"\x00" + u16(len(host)) + host
        data = u16(len(entry)) + entry
        exts += u16(0x0000) + u16(len(data)) + data
    elif extra_ext:
        dummy = b"\x01"
        exts += u16(0x000B) + u16(len(dummy)) + dummy
    body = b"\x03\x03" + rnd + b"\x00" + u16(2) + u16(0x1301) + b"\x01\x00" + u16(len(exts)) + exts
    hs = b"\x01" + u24(len(body)) + body
    rec = b"\x16\x03\x03" + u16(len(hs)) + hs
    return rec


def check(cond, msg):
    if not cond:
        raise AssertionError(msg)
    print("ok - " + msg)


def main():
    full = build_hello("app.example.com")
    check(peek_sni(full) == "app.example.com", "sni app.example.com parsed")

    no_sni = build_hello(None)
    check(peek_sni(no_sni) is None, "no-sni -> None")

    no_ext_at_all = build_hello(None, extra_ext=False)
    check(peek_sni(no_ext_at_all) is None, "empty-extensions -> None")

    check(peek_sni(b"") is None, "empty -> None")
    check(peek_sni(b"GET / HTTP/1.1\r\nHost: x\r\n\r\n") is None, "http garbage -> None")
    check(peek_sni(b"\x00\xff\x00\x01\x02\x03hello") is None, "binary garbage -> None")
    check(peek_sni(b"\x16\x03\x01\x00\x00") is None, "zero-len record -> None")
    check(peek_sni(b"\x15\x03\x01\x00\x04abcd") is None, "non-handshake record -> None")
    check(peek_sni(b"\x16\x02\x01\x00\x04abcd") is None, "bad version -> None")

    half = full[: len(full) // 2]
    check(peek_sni(half) is None, "half-ClientHello -> None")
    for cut in (1, 5, 6, 10, len(full) - 1):
        check(peek_sni(full[:cut]) is None, "truncated@%d -> None" % cut)

    t = {"*.example.com": "WILD", "def": "X"}
    check(pick_by_sni("x.example.com", t, "DEF") == "WILD", "wildcard matches subdomain")
    check(pick_by_sni("example.com.evil", t, "DEF") == "DEF", "wildcard rejects evil suffix")
    check(pick_by_sni("example.com", t, "DEF") == "DEF", "wildcard rejects bare domain")
    check(pick_by_sni("a.b.example.com", t, "DEF") == "DEF", "wildcard rejects multi-label")
    check(pick_by_sni("other.com", t, "DEF") == "DEF", "default on miss")
    check(pick_by_sni(None, t, "DEF") == "DEF", "None sni -> default")

    t2 = {"a.example.com": "EXACT", "*.example.com": "WILD"}
    check(pick_by_sni("a.example.com", t2, "DEF") == "EXACT", "exact beats wildcard")
    check(pick_by_sni("b.example.com", t2, "DEF") == "WILD", "wildcard fallback ok")

    rng = random.Random(1337)
    for i in range(200):
        ln = rng.randint(0, 120)
        buf = bytes(rng.getrandbits(8) for _ in range(ln))
        r = peek_sni(buf)
        assert r is None or isinstance(r, str), "fuzz type violation"
        mut = bytearray(full)
        for _ in range(rng.randint(1, 4)):
            if len(mut) == 0:
                break
            mut[rng.randrange(len(mut))] = rng.getrandbits(8)
        cut = rng.randint(0, len(mut))
        r2 = peek_sni(bytes(mut[:cut]))
        assert r2 is None or isinstance(r2, str), "fuzz-mut type violation"
    print("ok - fuzz 200 random+mutated buffers no-raise")

    print("ALL GREEN")


if __name__ == "__main__":
    main()
