"""Asserts for brat-lb HTTP/1.1 parser. Stdlib only."""
import os as _o, sys as _s
_s.path.insert(0, _o.path.join(_o.path.dirname(_o.path.abspath(__file__)), '..', 'engine'))
from http_parse import is_keep_alive, parse_many, parse_one, parse_request, route_key

n = 0


def check(cond, msg):
    global n
    assert cond, msg
    n += 1


m, t, v, h, b = parse_request(
    b"GET /hello HTTP/1.1\r\nHost: example.com\r\nConnection: keep-alive\r\n\r\n"
)
check(m == "GET", "GET method")
check(t == "/hello", "GET target")
check(v == "HTTP/1.1", "GET version")
check(h.get("host") == "example.com", "GET host lowercase")
check(b == b"", "GET empty body")
check(all(k == k.lower() for k in h), "headers lowercase")

m, t, v, h, b = parse_request(
    b"POST /submit HTTP/1.1\r\nHost: example.com\r\nContent-Length: 11\r\n\r\nhello world"
)
check(m == "POST", "POST method")
check(t == "/submit", "POST target")
check(b == b"hello world", "POST body framed")

check(is_keep_alive("HTTP/1.1", {"connection": "keep-alive"}) is True, "ka explicit")
check(is_keep_alive("HTTP/1.1", {}) is True, "1.1 default keep-alive")
check(is_keep_alive("HTTP/1.1", {"connection": "close"}) is False, "close wins")
check(is_keep_alive("HTTP/1.0", {}) is False, "1.0 default close")
check(is_keep_alive("HTTP/1.0", {"connection": "keep-alive"}) is True, "1.0 ka opt-in")

m, t, v, h, b = parse_request(b"BADLINE\r\n\r\n")
check(m is None, "malformed request line -> error")
m, t, v, h, b = parse_request(b"GET / HTTP/1.1\r\nNoColon\r\n\r\n")
check(m is None, "malformed header -> error")
m, t, v, h, b = parse_request(
    b"GET / HTTP/1.1\r\nHost: a\r\nContent-Length: xyz\r\n\r\n"
)
check(m is None, "bad content-length -> error")

m, t, v, h, b = parse_request(
    b"POST /up HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\nabc"
)
check(b == b"chunked-unsupported", "chunked marker")

pip = (
    b"GET /one HTTP/1.1\r\nHost: a\r\n\r\n"
    b"GET /two HTTP/1.1\r\nHost: a\r\n\r\n"
)
reqs = parse_many(pip)
check(len(reqs) == 2, "pipelined count")
check(reqs[0][1] == "/one" and reqs[1][1] == "/two", "pipelined targets")
m, t, v, h, b, rest = parse_one(pip)
check(m == "GET" and t == "/one", "parse_one first")
check(rest.startswith(b"GET /two"), "parse_one rest")

check(route_key({"host": "Example.COM"}, "/x") == "example.com", "route host")
check(route_key({}, "/path?q=1") == "/path", "route path")

print("ALL GREEN (%d asserts)" % n)
