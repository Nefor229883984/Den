"""Asserts for brat-lb WAF rule pack. Stdlib only."""
import os as _o, random as _r, sys as _s
from urllib.parse import unquote_to_bytes as _unq
_s.path.insert(0, _o.path.join(_o.path.dirname(_o.path.abspath(__file__)), '..', 'engine'))
from waf import inspect

n = 0


def check(cond, msg):
    global n
    assert cond, msg
    n += 1


def denied(v, rid, want):
    return v == "deny" and rid == want


v, rid = inspect("GET", "/search?q=' OR '1'='1", {}, b"")
check(denied(v, rid, "sqli-tautology"), "sqli tautology quote-or in target denied as sqli-tautology")

v, rid = inspect("POST", "/login", {"content-type": "application/x-www-form-urlencoded"}, b'user=" OR "1"="1')
check(denied(v, rid, "sqli-tautology"), "sqli tautology double-quote in body denied as sqli-tautology")

v, rid = inspect("GET", "/id=1 UNION+SELECT password FROM users", {}, b"")
check(denied(v, rid, "sqli-union-select"), "sqli union-plus-select in target denied as sqli-union-select")

v, rid = inspect("POST", "/q", {}, b"1 UNION SELECT 1,2,3")
check(denied(v, rid, "sqli-union-select"), "sqli union-space-select in body denied as sqli-union-select")

v, rid = inspect("POST", "/q", {}, b"id=1;--")
check(denied(v, rid, "sqli-stacked"), "sqli stacked semicolon-dashdash in body denied as sqli-stacked")

v, rid = inspect("GET", "/x?id=1;--", {}, b"")
check(denied(v, rid, "sqli-stacked"), "sqli stacked semicolon-dashdash in target denied as sqli-stacked")

v, rid = inspect("GET", "/x?id=1 AND SLEEP(5)", {}, b"")
check(denied(v, rid, "sqli-sleep"), "sqli sleep-paren in target denied as sqli-sleep")

v, rid = inspect("POST", "/q", {}, b"q=1 sleep(10)")
check(denied(v, rid, "sqli-sleep"), "sqli sleep-paren in body denied as sqli-sleep")

v, rid = inspect("GET", "/", {"x-forwarded-for": "1 AND BENCHMARK(1000000,MD5(1))"}, b"")
check(denied(v, rid, "sqli-benchmark"), "sqli benchmark-paren in header denied as sqli-benchmark")

v, rid = inspect("GET", "/s?q=<script>alert(1)</script>", {}, b"")
check(denied(v, rid, "xss-script"), "xss script-tag in target denied as xss-script")

v, rid = inspect("GET<script>", "/", {}, b"")
check(denied(v, rid, "xss-script"), "xss script-tag in method denied as xss-script")

v, rid = inspect("GET", "/", {"user-agent": "<ScRiPt src=x>"}, b"")
check(denied(v, rid, "xss-script"), "xss mixed-case script-tag in header denied as xss-script")

v, rid = inspect("POST", "/c", {}, b"<img src=x onerror=alert(1)>")
check(denied(v, rid, "xss-onerror"), "xss onerror-equals in body denied as xss-onerror")

v, rid = inspect("GET", "/x?m=<svg ONERROR=alert(1)>", {}, b"")
check(denied(v, rid, "xss-onerror"), "xss uppercase onerror in target denied as xss-onerror")

v, rid = inspect("GET", "/", {"referer": "javascript:alert(1)"}, b"")
check(denied(v, rid, "xss-javascript"), "xss javascript-colon in header denied as xss-javascript")

v, rid = inspect("GET", "/../../etc/passwd", {}, b"")
check(denied(v, rid, "traversal-dotdot"), "traversal dotdot-slash in target denied as traversal-dotdot")

v, rid = inspect("GET", "/", {"x-file": "..%2f..%2fetc%2fpasswd"}, b"")
check(denied(v, rid, "traversal-dotdot"), "traversal single-encoded dotdot in header decoded once to traversal-dotdot")

v, rid = inspect("POST", "/up", {}, b"a%00b")
check(denied(v, rid, "traversal-nullbyte"), "traversal pct00 in body denied as traversal-nullbyte")

v, rid = inspect("GET", "/a\x00b", {}, b"")
check(denied(v, rid, "traversal-nullbyte"), "traversal raw null byte in target denied as traversal-nullbyte")

v, rid = inspect("GET", "/ping?ip=127.0.0.1;cat /etc/passwd", {}, b"")
check(denied(v, rid, "rce-cat"), "rce semicolon-cat in target denied as rce-cat")

v, rid = inspect("POST", "/run", {}, b"out=`id`")
check(denied(v, rid, "rce-backtick"), "rce backticks in body denied as rce-backtick")

v, rid = inspect("GET", "/", {"x-cmd": "${PATH}"}, b"")
check(denied(v, rid, "rce-subst"), "rce dollar-brace in header denied as rce-subst")

v, rid = inspect("GET", "/x?c=${IFS}", {}, b"")
check(denied(v, rid, "rce-subst"), "rce dollar-brace-ifs in target denied as rce-subst")

v, rid = inspect("GET", "/hi", {"host": "a"}, b"")
check(v == "allow" and rid is None, "clean GET /hi allowed with no rule")

v, rid = inspect("GET", "/search?q=hello+world&page=2", {"host": "a"}, b"")
check(v == "allow" and rid is None, "clean normal query string allowed with no rule")

v, rid = inspect("POST", "/api/data", {"host": "a", "content-type": "application/json"}, b'{"name":"alice","age":30}')
check(v == "allow" and rid is None, "clean JSON post allowed with no rule")

raw = "/%252e%252e/%252e%252e/etc/passwd"
once = _unq(raw).decode("latin-1")
check("%2e" in once.lower() and ".." not in once.replace("%2e", ""), "double-encoded pct25xx decodes once to still-encoded pct2e")
v, rid = inspect("GET", raw, {"host": "a"}, b"")
check(denied(v, rid, "traversal-encoded"), "double-encoded pct25xx traversal denied as traversal-encoded")

for args in [(None, None, None, None), ("", "", {}, ""), ("", "", {}, b""),
              (b"", b"", {}, b""), ("GET", "/", {}, None), ("GET", "/", None, b"")]:
    v, rid = inspect(*args)
    check(v == "allow" and rid is None, "empty/None inputs allow without raising")

for args in [(123, 456, "x", 7), ("GET", "/", [("a", "b")], b"\xff\xfe"),
              ("GET", "/", {"h": None}, b"%"), ("GET", "/100%", {}, b"%zz%2")]:
    v, rid = inspect(*args)
    check(v in ("allow", "deny", "log"), "weird input types never raise and return a valid verdict")

_attacks = [
    "' OR '1'='1", '" OR "1"="1', "1 UNION+SELECT password FROM users",
    "id=1;--", "1 AND SLEEP(5)", "BENCHMARK(1000000,MD5(1))",
    "<script>alert(1)</script>", "<img src=x onerror=alert(1)>",
    "javascript:alert(1)", "/../../etc/passwd", "..%2f..%2fetc%2fpasswd",
    "/%252e%252e/%252e%252e/etc/passwd", "a%00b", "a\x00b",
    ";cat /etc/passwd", "`id`", "${PATH}", "${IFS}",
]
_rng = _r.Random(20261003)
_locs = ["method", "target", "header", "body"]
for i in range(500):
    src = _rng.choice(_attacks)
    a = _rng.randint(0, len(src))
    b = _rng.randint(a, len(src))
    frag = src[a:b]
    if _rng.random() < 0.5:
        frag = frag.encode("latin-1", "ignore")
    loc = _locs[i % 4]
    kw = {"method": "GET", "target": "/", "headers": {}, "body": b""}
    if loc == "method":
        kw["method"] = frag
    elif loc == "target":
        kw["target"] = frag
    elif loc == "header":
        kw["headers"] = {"x-t": frag}
    else:
        kw["body"] = frag
    v, rid = inspect(kw["method"], kw["target"], kw["headers"], kw["body"])
    assert v in ("allow", "deny", "log"), "random slice verdict valid"
    assert (v == "allow" and rid is None) or (v in ("deny", "log") and isinstance(rid, str)), "random slice verdict-rule shape"
n += 1

print("waf checks passed: %d" % n)
print("ALL GREEN")
