"""WAF for brat-lb. Plain functions, stdlib only.

inspect(method, target, headers, body) -> (verdict, rule_id).
verdict is allow, deny or log. rule_id is None on allow.
Matching is case-insensitive substring on raw and URL-decoded-once inputs.
"""
from urllib.parse import unquote_to_bytes as _unq

RULE_SqliUnion = "sqli-union-select"
RULE_SqliTaut = "sqli-tautology"
RULE_SqliStack = "sqli-stacked"
RULE_SqliSleep = "sqli-sleep"
RULE_SqliBench = "sqli-benchmark"
RULE_XssScript = "xss-script"
RULE_XssOnerror = "xss-onerror"
RULE_XssJs = "xss-javascript"
RULE_TravDot = "traversal-dotdot"
RULE_TravEnc = "traversal-encoded"
RULE_TravNull = "traversal-nullbyte"
RULE_RceCat = "rce-cat"
RULE_RceTick = "rce-backtick"
RULE_RceSubst = "rce-subst"
RULE_SstiMustache = "ssti-mustache"
RULE_SstiHash = "ssti-hash"
RULE_SstiStar = "ssti-star"
RULE_XxeEntity = "xxe-entity"
RULE_Log4Shell = "log4shell-jndi"
RULE_PhpWrapper = "php-wrapper"
RULE_HeaderCrlf = "header-crlf"

_ALLOW = ("allow", None)


def _to_str(v):
    if v is None:
        return ""
    if isinstance(v, (bytes, bytearray)):
        try:
            return bytes(v).decode("latin-1")
        except Exception:
            return ""
    if isinstance(v, str):
        return v
    try:
        return str(v)
    except Exception:
        return ""


def _decode_once(s):
    try:
        return _unq(s).decode("latin-1")
    except Exception:
        pass
    try:
        return _unq(_to_str(s).encode("latin-1", "ignore")).decode("latin-1")
    except Exception:
        return _to_str(s)


def _views(s):
    low = s.lower()
    dec = _decode_once(s).lower()
    comp = " ".join(dec.replace("+", " ").split())
    return low, dec, comp


def _hit(low, dec, comp, sig):
    return sig in low or sig in dec or sig in comp


def _scan(s):
    low, dec, comp = _views(s)
    if _hit(low, dec, comp, "union select"):
        return RULE_SqliUnion
    flat = comp.replace(" ", "")
    if "or'1'='1" in flat or 'or"1"="1' in flat or "or1=1" in flat:
        return RULE_SqliTaut
    if _hit(low, dec, comp, ";--"):
        return RULE_SqliStack
    if _hit(low, dec, comp, "sleep("):
        return RULE_SqliSleep
    if _hit(low, dec, comp, "benchmark("):
        return RULE_SqliBench
    if _hit(low, dec, comp, "<script"):
        return RULE_XssScript
    if _hit(low, dec, comp, "onerror="):
        return RULE_XssOnerror
    if _hit(low, dec, comp, "javascript:"):
        return RULE_XssJs
    if "../" in dec or "..\\" in dec:
        return RULE_TravDot
    if "..%2f" in dec or "..%5c" in dec or "%2e" in dec or "%c0%af" in dec:
        return RULE_TravEnc
    if "%00" in dec or "\x00" in dec:
        return RULE_TravNull
    if _hit(low, dec, comp, ";cat "):
        return RULE_RceCat
    if "`" in low or "`" in dec:
        return RULE_RceTick
    if "${jndi" in dec:
        return RULE_Log4Shell
    if "{{" in dec or "}}" in dec:
        return RULE_SstiMustache
    if "#{" in dec or "[#" in dec:
        return RULE_SstiHash
    if "*{" in dec:
        return RULE_SstiStar
    if "<!entity" in dec:
        return RULE_XxeEntity
    for w in ("php://", "expect://", "data:text/html", "zip://", "phar://"):
        if w in dec:
            return RULE_PhpWrapper
    if _hit(low, dec, comp, "${"):
        return RULE_RceSubst
    return None


def inspect(method, target, headers, body):
    """Return (verdict, rule_id) for one request. Never raises."""
    try:
        parts = [_to_str(method), _to_str(target)]
        try:
            if isinstance(headers, dict):
                items = headers.items()
            elif headers is None:
                items = []
            else:
                items = [(headers, "")]
            for k, v in items:
                ks, vs = _to_str(k), _to_str(v)
                if "\r" in ks or "\n" in ks or "\r" in vs or "\n" in vs:
                    return ("deny", RULE_HeaderCrlf)
                parts.append(ks + ": " + vs)
        except Exception:
            parts.append(_to_str(headers))
        parts.append(_to_str(body))
        for p in parts:
            if not p:
                continue
            rid = _scan(p)
            if rid is not None:
                return ("deny", rid)
        return _ALLOW
    except Exception:
        return _ALLOW
