import argparse, itertools, json, signal, socket, threading, time, uuid

def parse_host(s):
    h, p = s.rsplit(':', 1)
    return h, int(p)

class Log:
    def __init__(self, path=None):
        self.path = path
        self.lock = threading.Lock()
        self.fh = open(path, 'a', encoding='utf-8') if path else None

    def line(self, lvl, msg, **attrs):
        rec = {'ts': time.time(), 'lvl': lvl, 'msg': msg}
        rec.update(attrs)
        s = json.dumps(rec, ensure_ascii=False)
        with self.lock:
            print(s, flush=True)
            if self.fh:
                self.fh.write(s + '\n')
                self.fh.flush()

    def info(self, msg, **a):
        self.line('INFO', msg, **a)

    def warn(self, msg, **a):
        self.line('WARN', msg, **a)

    def error(self, msg, **a):
        self.line('ERROR', msg, **a)

class Metrics:
    def __init__(self):
        self.lock = threading.Lock()
        self.requests = 0
        self.errors = 0
        self.lat = []
        self.up_ok = {}
        self.inflight = 0

    def enter(self):
        with self.lock:
            self.inflight += 1

    def leave(self):
        with self.lock:
            self.inflight -= 1

    def hit(self, ms, ok):
        with self.lock:
            self.requests += 1
            if not ok:
                self.errors += 1
            self.lat.append(ms)
            if len(self.lat) > 2048:
                del self.lat[:1024]

    def mark(self, up, ok):
        with self.lock:
            self.up_ok[up] = 1 if ok else 0

    def render(self):
        with self.lock:
            lat = sorted(self.lat)
            p50 = lat[len(lat) // 2] if lat else 0
            p99 = lat[int(len(lat) * 0.99)] if lat else 0
            out = [
                '# TYPE lb_requests counter',
                'lb_requests %d' % self.requests,
                '# TYPE lb_errors counter',
                'lb_errors %d' % self.errors,
                '# TYPE lb_latency_ms histogram-ish',
                'lb_latency_p50_ms %.2f' % p50,
                'lb_latency_p99_ms %.2f' % p99,
            ]
            for up, ok in self.up_ok.items():
                out.append('lb_up_ok{up="%s"} %d' % (up, ok))
            out.append('lb_inflight %d' % self.inflight)
            return '\n'.join(out) + '\n'

class Pool:
    def __init__(self, ups, log, metrics):
        self.ups = list(ups)
        self.log = log
        self.metrics = metrics
        self.lock = threading.Lock()
        self.alive = {u: True for u in self.ups}
        self.cycle = itertools.cycle(self.ups)
        for u in self.ups:
            metrics.mark(u, True)

    def pick_round_robin(self):
        with self.lock:
            for _ in self.ups:
                u = next(self.cycle)
                if self.alive.get(u):
                    return u
            return None

    def mark_down(self, up):
        with self.lock:
            if self.alive.get(up):
                self.alive[up] = False
                self.metrics.mark(up, False)
                self.log.warn('down', up=up)

    def mark_up(self, up):
        with self.lock:
            if not self.alive.get(up):
                self.alive[up] = True
                self.metrics.mark(up, True)
                self.log.info('back', up=up)

    def healthy(self, up):
        h, p = parse_host(up)
        s = socket.socket()
        s.settimeout(1.0)
        try:
            s.connect((h, p))
            return True
        except OSError:
            return False
        finally:
            s.close()

    def watch(self, every=2.0):
        while True:
            for u in self.ups:
                if self.healthy(u):
                    self.mark_up(u)
                else:
                    self.mark_down(u)
            time.sleep(every)

def pump(src, dst):
    try:
        while True:
            b = src.recv(65536)
            if not b:
                try:
                    dst.shutdown(socket.SHUT_WR)
                except OSError:
                    pass
                return
            dst.sendall(b)
    except OSError:
        return

def serve_client(client, pool, log, metrics, slots):
    tid = uuid.uuid4().hex[:8]
    t0 = time.time()
    metrics.enter()
    try:
        up = pool.pick_round_robin()
        if not up:
            log.error('no healthy upstream', trace_id=tid)
            metrics.hit(0, False)
            client.close()
            return
        h, p = parse_host(up)
        back = socket.socket()
        back.settimeout(5.0)
        try:
            back.connect((h, p))
        except OSError:
            pool.mark_down(up)
            log.warn('connect fail', trace_id=tid, up=up)
            metrics.hit((time.time() - t0) * 1000, False)
            client.close()
            return
        log.info('route', trace_id=tid, up=up)
        back.settimeout(None)
        t1 = threading.Thread(target=pump, args=(client, back), daemon=True)
        t2 = threading.Thread(target=pump, args=(back, client), daemon=True)
        t1.start()
        t2.start()
        t1.join()
        t2.join()
        ms = (time.time() - t0) * 1000
        metrics.hit(ms, True)
        log.info('done', trace_id=tid, up=up, ms=round(ms, 2))
        try:
            client.close()
        except OSError:
            pass
        try:
            back.close()
        except OSError:
            pass
    finally:
        metrics.leave()
        slots.release()

def serve_metrics(port, metrics, log):
    srv = socket.socket()
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(('127.0.0.1', port))
    srv.listen(32)
    log.info('metrics listen', port=port)
    while True:
        c, _ = srv.accept()
        try:
            c.recv(4096)
            body = metrics.render()
            resp = 'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: %d\r\nConnection: close\r\n\r\n%s' % (len(body), body)
            c.sendall(resp.encode())
        except OSError:
            pass
        finally:
            c.close()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--listen', default='127.0.0.1:8080')
    ap.add_argument('--up', default='')
    ap.add_argument('--log', default=None)
    ap.add_argument('--metrics-port', type=int, default=0)
    ap.add_argument('--max-conns', type=int, default=512)
    ap.add_argument('--config', default=None)
    a = ap.parse_args()
    cfg = {}
    if a.config:
        cfg = json.load(open(a.config, encoding='utf-8'))
    listen = a.listen if a.listen != '127.0.0.1:8080' or 'listen' not in cfg else cfg.get('listen', a.listen)
    up = a.up or cfg.get('up', '')
    logpath = a.log or cfg.get('log')
    mport = a.metrics_port or cfg.get('metrics_port', 0)
    maxconns = cfg.get('max_conns', a.max_conns) if a.max_conns == 512 else a.max_conns
    ups = [u.strip() for u in up.split(',') if u.strip()]
    if not ups:
        raise SystemExit('no upstreams: --up or config up')
    log = Log(logpath)
    metrics = Metrics()
    pool = Pool(ups, log, metrics)
    stop = threading.Event()
    for sig in ('SIGINT', 'SIGTERM'):
        try:
            signal.signal(getattr(signal, sig), lambda *_: stop.set())
        except (AttributeError, OSError, ValueError):
            pass
    threading.Thread(target=pool.watch, daemon=True).start()
    if mport:
        threading.Thread(target=serve_metrics, args=(mport, metrics, log), daemon=True).start()
    slots = threading.Semaphore(maxconns)
    lh, lp = parse_host(listen)
    srv = socket.socket()
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind((lh, lp))
    srv.listen(128)
    srv.settimeout(0.5)
    log.info('brat-lb listen', listen=listen, ups=ups, max_conns=maxconns)
    while not stop.is_set():
        try:
            c, _ = srv.accept()
        except socket.timeout:
            continue
        slots.acquire()
        threading.Thread(target=serve_client, args=(c, pool, log, metrics, slots), daemon=True).start()
    log.info('draining', inflight=metrics.inflight)
    for _ in range(50):
        if metrics.inflight <= 0:
            break
        time.sleep(0.1)
    srv.close()
    log.info('brat-lb stop')

if __name__ == '__main__':
    main()
