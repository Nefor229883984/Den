"""Pure-stdlib self-signed cert generator for TESTS ONLY."""
import argparse
import base64
import hashlib
import math
import os
import secrets
import ssl
import time

def _der_len(n):
    if n < 0x80:
        return bytes([n])
    b = n.to_bytes((n.bit_length() + 7) // 8, "big")
    return bytes([0x80 | len(b)]) + b


def _tlv(tag, content):
    return bytes([tag]) + _der_len(len(content)) + content


def _der_seq(*parts):
    return _tlv(0x30, b"".join(parts))


def _der_set(*parts):
    return _tlv(0x31, b"".join(parts))


def _der_int(x):
    if x == 0:
        return b"\x02\x01\x00"
    b = x.to_bytes((x.bit_length() + 7) // 8, "big")
    if b[0] & 0x80:
        b = b"\x00" + b
    return _tlv(0x02, b)


def _der_null():
    return b"\x05\x00"


def _der_oid(oid):
    arcs = [int(a) for a in oid.split(".")]
    out = bytes([40 * arcs[0] + arcs[1]])
    for a in arcs[2:]:
        tmp = []
        tmp.append(a & 0x7F)
        a >>= 7
        while a:
            tmp.append((a & 0x7F) | 0x80)
            a >>= 7
        out += bytes(reversed(tmp)) if len(tmp) > 1 else bytes(tmp)
    return _tlv(0x06, out)


def _der_utf8(s):
    return _tlv(0x0C, s.encode("utf-8"))


def _der_utctime(s):
    return _tlv(0x17, s.encode("ascii"))


def _der_octet(b):
    return _tlv(0x04, b)


def _der_bitstring(b):
    return _tlv(0x03, b"\x00" + b)


def _der_explicit(n, inner):
    return _tlv(0xA0 + n, inner)


def _der_dnsname(s):
    return _tlv(0x82, s.encode("ascii"))


def _pem(der, header):
    b64 = base64.encodebytes(der).decode("ascii")
    return "-----BEGIN %s-----\n%s-----END %s-----\n" % (header, b64, header)


def _small_primes(limit=2000):
    sieve = bytearray(b"\x01") * (limit + 1)
    sieve[0:2] = b"\x00\x00"
    for i in range(2, int(limit ** 0.5) + 1):
        if sieve[i]:
            sieve[i * i:limit + 1:i] = b"\x00" * ((limit - i * i) // i + 1)
    return [i for i, v in enumerate(sieve) if v]


_SMALL = _small_primes()


def _is_probable_prime(n, rounds=12):
    if n < 2:
        return False
    for p in _SMALL:
        if n % p == 0:
            return n == p
    r = 0
    d = n - 1
    while d % 2 == 0:
        r += 1
        d //= 2
    for _ in range(rounds):
        a = secrets.randbelow(n - 3) + 2
        x = pow(a, d, n)
        if x == 1 or x == n - 1:
            continue
        for _ in range(r - 1):
            x = (x * x) % n
            if x == n - 1:
                break
        else:
            return False
    return True


def _gen_prime(bits):
    while True:
        c = secrets.randbits(bits) | (1 << (bits - 1)) | 1
        skip = False
        for p in _SMALL:
            if c % p == 0:
                skip = True
                break
        if skip:
            continue
        if _is_probable_prime(c):
            return c


def gen_rsa(bits=2048, e=65537):
    half = bits // 2
    while True:
        p = _gen_prime(half)
        q = _gen_prime(half)
        if p == q:
            continue
        n = p * q
        if n.bit_length() != bits:
            continue
        phi = (p - 1) * (q - 1)
        if math.gcd(e, phi) != 1:
            continue
        d = pow(e, -1, phi)
        return (n, e, d, p, q)


def _name(cn):
    return _der_seq(_der_set(_der_seq(_der_oid("2.5.4.3"), _der_utf8(cn))))


def _spki(n, e):
    pub = _der_seq(_der_int(n), _der_int(e))
    alg = _der_seq(_der_oid("1.2.840.113549.1.1.1"), _der_null())
    return _der_seq(alg, _der_bitstring(pub))


def _pkcs1_sign(tbs, d, n):
    h = hashlib.sha256(tbs).digest()
    prefix = bytes.fromhex("3031300d060960864801650304020105000420") + h
    k = (n.bit_length() + 7) // 8
    if k < len(prefix) + 11:
        raise ValueError("key too short")
    ps = b"\xff" * (k - len(prefix) - 3)
    em = b"\x00\x01" + ps + b"\x00" + prefix
    m = int.from_bytes(em, "big")
    s = pow(m, d, n)
    return s.to_bytes(k, "big")


def self_signed(cn, sans):
    if isinstance(sans, str):
        sans = [s for s in sans.split(",") if s.strip()]
    sans = list(sans or [])
    n, e, d, p, q = gen_rsa()
    dp = d % (p - 1)
    dq = d % (q - 1)
    qinv = pow(q, -1, p)
    key_der = _der_seq(
        _der_int(0), _der_int(n), _der_int(e), _der_int(d),
        _der_int(p), _der_int(q), _der_int(dp), _der_int(dq), _der_int(qinv),
    )
    key_pem = _pem(key_der, "RSA PRIVATE KEY")
    serial = secrets.randbits(63) + 1
    now = time.time()
    nb = time.strftime("%y%m%d%H%M%SZ", time.gmtime(now - 86400))
    na = time.strftime("%y%m%d%H%M%SZ", time.gmtime(now + 365 * 86400))
    sigalg = _der_seq(_der_oid("1.2.840.113549.1.1.11"), _der_null())
    issuer = _name(cn)
    subject = _name(cn)
    validity = _der_seq(_der_utctime(nb), _der_utctime(na))
    spki = _spki(n, e)
    exts = []
    bc = _der_seq(_der_oid("2.5.29.19"), _der_octet(_der_seq()))
    exts.append(bc)
    if sans:
        gns = b"".join(_der_dnsname(s) for s in sans)
        san_seq = _tlv(0x30, gns)
        san = _der_seq(_der_oid("2.5.29.17"), _der_octet(san_seq))
        exts.append(san)
    ext_block = _der_explicit(3, _der_seq(*exts))
    tbs = _der_seq(
        _der_explicit(0, _der_int(2)),
        _der_int(serial),
        sigalg,
        issuer,
        validity,
        subject,
        spki,
        ext_block,
    )
    sig = _pkcs1_sign(tbs, d, n)
    cert_der = _der_seq(tbs, sigalg, _der_bitstring(sig))
    cert_pem = _pem(cert_der, "CERTIFICATE")
    return (cert_pem, key_pem)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cn", default="localhost")
    ap.add_argument("--san", default="")
    ap.add_argument("--out", default=".")
    a = ap.parse_args()
    sans = [s.strip() for s in a.san.split(",") if s.strip()] if a.san else []
    cert_pem, key_pem = self_signed(a.cn, sans)
    os.makedirs(a.out, exist_ok=True)
    cp = os.path.join(a.out, "cert.pem")
    kp = os.path.join(a.out, "key.pem")
    with open(cp, "w", encoding="utf-8") as f:
        f.write(cert_pem)
    with open(kp, "w", encoding="utf-8") as f:
        f.write(key_pem)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain(cp, kp)
    print("wrote %s %s" % (cp, kp))


if __name__ == "__main__":
    main()
