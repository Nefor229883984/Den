"""TLS-terminating demo frontend reusing lb.py via importlib."""
import argparse
import importlib.util
import os
import signal
import socket
import ssl
import threading
import time
import uuid

_HERE = os.path.dirname(os.path.abspath(__file__))
_spec = importlib.util.spec_from_file_location("brat_lb", os.path.join(_HERE, "lb.py"))
_lb = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_lb)

_state = threading.local()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--listen", default="127.0.0.1:8443")
    ap.add_argument("--cert", default="")
    ap.add_argument("--key", default="")
    ap.add_argument("--up", default="")
    ap.add_argument("--log", default=None)
    ap.add_argument("--metrics-port", type=int, default=0)
    ap.add_argument("--max-conns", type=int, default=512)
    a = ap.parse_args()
    if not a.cert or not a.key:
        raise SystemExit("need --cert and --key")
    ups = [u.strip() for u in a.up.split(",") if u.strip()]
    if not ups:
        raise SystemExit("no upstreams: --up")
    log = _lb.Log(a.log)
    metrics = _lb.Metrics()
    pool = _lb.Pool(ups, log, metrics)

    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain(a.cert, a.key)

    def _sni_cb(sslobj, server_name, ictx):
        try:
            _state.sni = server_name
        except Exception:
            pass
        try:
            tid = getattr(_state, "tid", "")
            log.info("sni", trace_id=tid, sni=server_name or "")
        except Exception:
            pass

    try:
        ctx.sni_callback = _sni_cb
    except Exception:
        pass

    def serve_tls_client(raw, tls):
        tid = getattr(_state, "tid", "") or uuid.uuid4().hex[:8]
        sni = getattr(_state, "sni", None) or ""
        t0 = time.time()
        metrics.enter()
        try:
            up = pool.pick_round_robin()
            if not up:
                log.error("no healthy upstream", trace_id=tid, sni=sni)
                metrics.hit(0, False)
                try:
                    tls.close()
                except OSError:
                    pass
                return
            h, p = _lb.parse_host(up)
            back = socket.socket()
            back.settimeout(5.0)
            try:
                back.connect((h, p))
            except OSError:
                pool.mark_down(up)
                log.warn("connect fail", trace_id=tid, up=up, sni=sni)
                metrics.hit((time.time() - t0) * 1000, False)
                try:
                    tls.close()
                except OSError:
                    pass
                return
            log.info("route", trace_id=tid, up=up, sni=sni)
            back.settimeout(None)
            t1 = threading.Thread(target=_lb.pump, args=(tls, back), daemon=True)
            t2 = threading.Thread(target=_lb.pump, args=(back, tls), daemon=True)
            t1.start()
            t2.start()
            t1.join()
            t2.join()
            ms = (time.time() - t0) * 1000
            metrics.hit(ms, True)
            log.info("done", trace_id=tid, up=up, ms=round(ms, 2), sni=sni)
            try:
                tls.close()
            except OSError:
                pass
            try:
                back.close()
            except OSError:
                pass
        finally:
            metrics.leave()
            slots.release()

    def handle(raw):
        _state.tid = uuid.uuid4().hex[:8]
        _state.sni = ""
        tid = _state.tid
        try:
            tls = ctx.wrap_socket(raw, server_side=True)
        except (ssl.SSLError, OSError, ValueError) as e:
            log.error("tls handshake fail", trace_id=tid, err=str(e)[:200])
            try:
                raw.close()
            except OSError:
                pass
            slots.release()
            return
        except Exception as e:
            log.error("tls handshake fail", trace_id=tid, err=str(e)[:200])
            try:
                raw.close()
            except OSError:
                pass
            slots.release()
            return
        serve_tls_client(raw, tls)

    stop = threading.Event()

    def _stop(*_):
        stop.set()

    for sig in ("SIGINT", "SIGTERM"):
        try:
            signal.signal(getattr(signal, sig), lambda *_: stop.set())
        except (AttributeError, OSError, ValueError):
            pass
    threading.Thread(target=pool.watch, daemon=True).start()
    if a.metrics_port:
        threading.Thread(target=_lb.serve_metrics, args=(a.metrics_port, metrics, log), daemon=True).start()
    slots = threading.Semaphore(a.max_conns)
    lh, lp = _lb.parse_host(a.listen)
    srv = socket.socket()
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind((lh, lp))
    srv.listen(128)
    srv.settimeout(0.5)
    log.info("tls-front listen", listen=a.listen, ups=ups)
    while not stop.is_set():
        try:
            c, _ = srv.accept()
        except socket.timeout:
            continue
        slots.acquire()
        threading.Thread(target=handle, args=(c,), daemon=True).start()
    log.info("draining", inflight=metrics.inflight)
    for _ in range(50):
        if metrics.inflight <= 0:
            break
        time.sleep(0.1)
    srv.close()
    log.info("tls-front stop")


if __name__ == "__main__":
    main()
