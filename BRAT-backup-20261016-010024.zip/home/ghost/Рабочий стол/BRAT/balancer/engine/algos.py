import hashlib
import threading


class RoundRobin:
    def __init__(self):
        self._lock = threading.Lock()
        self._idx = 0

    def pick(self, healthy: list[str]) -> str:
        if not healthy:
            raise ValueError("empty healthy")
        with self._lock:
            up = healthy[self._idx % len(healthy)]
            self._idx += 1
            return up


class LeastConn:
    def __init__(self):
        self._lock = threading.Lock()
        self._active: dict[str, int] = {}

    def acquire(self, up: str) -> None:
        with self._lock:
            self._active[up] = self._active.get(up, 0) + 1

    def release(self, up: str) -> None:
        with self._lock:
            n = self._active.get(up, 0) - 1
            self._active[up] = n if n > 0 else 0

    def pick(self, healthy: list[str]) -> str:
        if not healthy:
            raise ValueError("empty healthy")
        with self._lock:
            return min(healthy, key=lambda u: self._active.get(u, 0))


class IpHash:
    def __init__(self):
        self._lock = threading.Lock()

    def pick(self, healthy: list[str], ip: str = "") -> str:
        if not healthy:
            raise ValueError("empty healthy")
        with self._lock:
            h = int.from_bytes(hashlib.md5(ip.encode("utf-8")).digest(), "big")
            return healthy[h % len(healthy)]


class EwmaPicker:
    def __init__(self, alpha: float = 0.3):
        self._alpha = alpha
        self._lock = threading.Lock()
        self._ewma: dict[str, float] = {}

    def observe(self, up: str, ms: float) -> None:
        with self._lock:
            prev = self._ewma.get(up)
            if prev is None:
                self._ewma[up] = float(ms)
            else:
                self._ewma[up] = self._alpha * float(ms) + (1.0 - self._alpha) * prev

    def pick(self, healthy: list[str]) -> str:
        if not healthy:
            raise ValueError("empty healthy")
        with self._lock:
            snap = dict(self._ewma)
        return min(healthy, key=lambda u: snap.get(u, float("inf")))
