import json
import random
import threading
import time
import urllib.request


_ALLOWED_LABELS = frozenset({"host", "code", "route", "up", "name"})


def sample(head_rate):
    try:
        r = float(head_rate)
    except (TypeError, ValueError):
        return True
    if r != r:
        return True
    if r >= 1.0:
        return True
    if r <= 0.0:
        return False
    try:
        return random.random() < r
    except Exception:
        return True


def _hex(nbits):
    try:
        return "%0*x" % (nbits // 4, random.getrandbits(nbits))
    except Exception:
        return "0" * (nbits // 4)


def _to_nano(v, fallback):
    try:
        if v is None:
            return fallback
        if isinstance(v, bool):
            return fallback
        f = float(v)
        if f > 1e12:
            return int(f)
        if f > 1e9:
            return int(f * 1e9) if f < 1e11 else int(f)
        return int(f * 1e9)
    except Exception:
        return fallback


def to_otlp(span):
    try:
        now = time.time_ns()
    except Exception:
        now = 0
    try:
        if not isinstance(span, dict):
            try:
                name = str(span)
            except Exception:
                name = "unknown"
            return {
                "traceId": _hex(128),
                "spanId": _hex(64),
                "name": name if name else "unknown",
                "startUnixNano": now,
                "endUnixNano": now,
                "attributes": {},
            }
        trace_id = span.get("traceId", span.get("trace_id", span.get("traceid", "")))
        span_id = span.get("spanId", span.get("span_id", span.get("spanid", "")))
        try:
            trace_id = str(trace_id) if trace_id else _hex(128)
        except Exception:
            trace_id = _hex(128)
        try:
            span_id = str(span_id) if span_id else _hex(64)
        except Exception:
            span_id = _hex(64)
        name = span.get("name", span.get("msg", "unknown"))
        try:
            name = str(name) if name not in (None, "") else "unknown"
        except Exception:
            name = "unknown"
        start = span.get("startUnixNano", span.get("start", span.get("ts")))
        end = span.get("endUnixNano", span.get("end"))
        start_n = _to_nano(start, now)
        end_n = _to_nano(end, start_n)
        if end_n < start_n:
            end_n = start_n
        raw_attrs = span.get("attributes", span.get("attrs", span.get("labels", {})))
        attrs = {}
        try:
            if isinstance(raw_attrs, dict):
                for k, v in raw_attrs.items():
                    try:
                        ks = str(k)
                    except Exception:
                        continue
                    if ks in ("trace_id", "traceId", "span_id", "spanId"):
                        continue
                    try:
                        if isinstance(v, bool):
                            attrs[ks] = v
                        elif isinstance(v, (int, float)):
                            attrs[ks] = v
                        else:
                            attrs[ks] = str(v)
                    except Exception:
                        continue
            for k in ("up", "route", "host", "code"):
                try:
                    if k in span and k not in attrs:
                        v = span[k]
                        if isinstance(v, bool):
                            attrs[k] = v
                        elif isinstance(v, (int, float)):
                            attrs[k] = v
                        else:
                            attrs[k] = str(v)
                except Exception:
                    continue
        except Exception:
            attrs = {}
        return {
            "traceId": trace_id,
            "spanId": span_id,
            "name": name,
            "startUnixNano": int(start_n),
            "endUnixNano": int(end_n),
            "attributes": attrs,
        }
    except Exception:
        try:
            return {
                "traceId": _hex(128),
                "spanId": _hex(64),
                "name": "unknown",
                "startUnixNano": now,
                "endUnixNano": now,
                "attributes": {},
            }
        except Exception:
            return {"traceId": "0" * 32, "spanId": "0" * 16, "name": "unknown",
                    "startUnixNano": 0, "endUnixNano": 0, "attributes": {}}


def _sanitize_name(name):
    try:
        s = str(name).strip()
    except Exception:
        return ""
    if not s.startswith("lb_"):
        return ""
    out = []
    for ch in s:
        if ch.isascii() and (ch.isalnum() or ch in ("_", ":")):
            out.append(ch)
        elif ch == "_":
            out.append(ch)
    cleaned = "".join(out)
    if not cleaned or cleaned.strip("_:") == "":
        return ""
    return cleaned


def prom_extra(metrics_dict):
    try:
        if not isinstance(metrics_dict, dict):
            return ""
        lines = []
        for raw_name, raw_val in metrics_dict.items():
            try:
                name = _sanitize_name(raw_name)
                if not name:
                    continue
                labels = None
                val = raw_val
                if isinstance(raw_val, dict):
                    if "value" in raw_val:
                        val = raw_val["value"]
                        labels = raw_val.get("labels", {})
                    else:
                        continue
                elif isinstance(raw_val, (list, tuple)) and len(raw_val) == 2:
                    val, labels = raw_val[0], raw_val[1]
                try:
                    if isinstance(val, bool):
                        continue
                    num = float(val)
                except Exception:
                    continue
                if num != num:
                    continue
                if isinstance(num, float) and num.is_integer():
                    vstr = str(int(num))
                else:
                    vstr = repr(num)
                if isinstance(labels, dict):
                    parts = []
                    for lk, lv in labels.items():
                        try:
                            lks = str(lk)
                        except Exception:
                            continue
                        if lks not in _ALLOWED_LABELS:
                            continue
                        try:
                            lvs = str(lv).replace("\\", "\\\\").replace('"', '\\"').replace("\n", "_")
                        except Exception:
                            continue
                        parts.append('%s="%s"' % (lks, lvs))
                    if parts:
                        lines.append("%s{%s} %s" % (name, ",".join(parts), vstr))
                    else:
                        lines.append("%s %s" % (name, vstr))
                else:
                    lines.append("%s %s" % (name, vstr))
            except Exception:
                continue
        if not lines:
            return ""
        return "\n".join(lines) + "\n"
    except Exception:
        return ""


def _post(endpoint, payload, timeout=2.0):
    try:
        data = json.dumps(payload).encode("utf-8")
    except Exception:
        return False
    try:
        req = urllib.request.Request(endpoint, data=data, headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            try:
                r.read()
            except Exception:
                pass
        return True
    except Exception:
        return False


class Batcher:
    def __init__(self, max_size=512, flush_count=100, flush_interval=5.0, sink=None, endpoint=None):
        try:
            max_size = int(max_size)
        except Exception:
            max_size = 512
        try:
            flush_count = int(flush_count)
        except Exception:
            flush_count = 100
        try:
            flush_interval = float(flush_interval)
        except Exception:
            flush_interval = 5.0
        if max_size < 1:
            max_size = 1
        if flush_count < 1:
            flush_count = 1
        if flush_interval < 0:
            flush_interval = 0
        self.max_size = max_size
        self.flush_count = flush_count
        self.flush_interval = flush_interval
        self.sink = sink
        self.endpoint = endpoint
        self.buf = []
        self.dropped = 0
        self.lock = threading.Lock()
        self.last_flush = time.monotonic()
        self._stop = threading.Event()
        self._thread = None

    def __len__(self):
        try:
            with self.lock:
                return len(self.buf)
        except Exception:
            return 0

    def add(self, span):
        try:
            due = False
            with self.lock:
                if len(self.buf) >= self.max_size:
                    try:
                        self.dropped += 1
                    except Exception:
                        pass
                    return False
                try:
                    self.buf.append(span)
                except Exception:
                    try:
                        self.dropped += 1
                    except Exception:
                        pass
                    return False
                try:
                    now = time.monotonic()
                except Exception:
                    now = self.last_flush
                if len(self.buf) >= self.flush_count:
                    due = True
                elif self.flush_interval > 0 and (now - self.last_flush) >= self.flush_interval:
                    due = True
            if due:
                self.flush()
            return True
        except Exception:
            return False

    def flush(self):
        try:
            with self.lock:
                batch = self.buf
                self.buf = []
                try:
                    self.last_flush = time.monotonic()
                except Exception:
                    pass
            if not batch:
                return []
            try:
                otlp = [to_otlp(s) for s in batch]
            except Exception:
                otlp = []
            if self.sink is not None:
                try:
                    self.sink(otlp)
                except Exception:
                    pass
            elif self.endpoint:
                try:
                    _post(self.endpoint, otlp)
                except Exception:
                    pass
            return otlp
        except Exception:
            return []

    def flush_if_due(self):
        try:
            if self.flush_interval <= 0:
                return []
            try:
                now = time.monotonic()
            except Exception:
                return []
            with self.lock:
                empty = len(self.buf) == 0
                due = (now - self.last_flush) >= self.flush_interval
            if due and not empty:
                return self.flush()
            return []
        except Exception:
            return []

    def start(self):
        try:
            if self._thread is not None and self._thread.is_alive():
                return self._thread
            self._stop.clear()
            interval = self.flush_interval if self.flush_interval > 0 else 1.0

            def loop():
                while not self._stop.wait(interval):
                    try:
                        self.flush_if_due()
                    except Exception:
                        continue

            t = threading.Thread(target=loop, daemon=True)
            self._thread = t
            t.start()
            return t
        except Exception:
            return None

    def stop(self):
        try:
            self._stop.set()
        except Exception:
            pass
        try:
            self.flush()
        except Exception:
            pass
