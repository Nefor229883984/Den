"""BRAT L7 demo server: Host-header routing over TCP. Stdlib only.

Accepts TCP, reads the HTTP request head (up to 64KB, 5s timeout),
parses it with http_parse.parse_request, picks a Pool by Host header
from a --route map (``host=up1,up2;host2=up3``), forwards raw bytes
both ways. Logs {ts,lvl,msg,trace_id,up,method,target,ms} JSONL,
counts lb_requests/lb_errors via Metrics.

Reuses Pool/Log/Metrics/pump from lb.py via importlib (no copies).
Malformed input -> 400 + error log, server keeps serving.
"""

import argparse
import importlib.util
import json
import os
import socket
import sys
import threading
import time
import uuid

_HERE = os.path.dirname(os.path.abspath(__file__))
MAX_BUF = 65536
HEAD_TIMEOUT = 5.0


def _load(name, filename):
    path = os.path.join(_HERE, filename)
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


_lb = _load("brat_lb_oracle", "lb.py")
_hp = _load("brat_http_parse", "http_parse.py")
_waf = _load("brat_waf", "waf.py")

Pool = _lb.Pool
BaseLog = _lb.Log
Metrics = _lb.Metrics
pump = _lb.pump
parse_host = _lb.parse_host
serve_metrics = _lb.serve_metrics
parse_request = _hp.parse_request
route_key = _hp.route_key
is_keep_alive = _hp.is_keep_alive
parse_one = _hp.parse_one
MAX_REQS = 100


class Log(BaseLog):
    def line(self, lvl, msg, **attrs):
        attrs.setdefault("trace_id", "-")
        rec = {"ts": time.time(), "lvl": lvl, "msg": msg}
        rec.update(attrs)
        s = json.dumps(rec, ensure_ascii=False)
        with self.lock:
            if self.fh:
                self.fh.write(s + "\n")
                self.fh.flush()
            else:
                print(s, flush=True)


def parse_route(spec):
    """Parse ``host=up1,up2;host2=up3`` into {host: [up, ...]}."""
    out = {}
    for chunk in spec.split(";"):
        chunk = chunk.strip()
        if not chunk:
            continue
        if "=" not in chunk:
            raise ValueError("bad route chunk %r, want host=up1,up2" % chunk)
        host, ups = chunk.split("=", 1)
        host = host.strip().lower()
        ups = [u.strip() for u in ups.split(",") if u.strip()]
        if not host or not ups:
            raise ValueError("bad route chunk %r" % chunk)
        for u in ups:
            parse_host(u)
        out[host] = ups
    if not out:
        raise ValueError("empty --route")
    return out


def _send_simple(client, code, reason, text):
    body = text.encode("utf-8")
    head = ("HTTP/1.1 %d %s\r\nContent-Type: text/plain\r\n"
            "Content-Length: %d\r\nConnection: close\r\n\r\n"
            % (code, reason, len(body))).encode("latin-1")
    try:
        client.sendall(head + body)
    except OSError:
        pass


def _close_quietly(sock):
    try:
        sock.close()
    except OSError:
        pass


def _set_conn(head, keep_open):
    try:
        s = head.decode("latin-1")
    except Exception:
        return head
    parts = s.split("\r\n")
    status = parts[0]
    hdrs = parts[1:-2] if len(parts) >= 3 else []
    want = "keep-alive" if keep_open else "close"
    out = []
    found = False
    for h in hdrs:
        if ":" in h:
            k, _v = h.split(":", 1)
            if k.strip().lower() == "connection":
                out.append("Connection: %s" % want)
                found = True
            else:
                out.append(h)
        else:
            out.append(h)
    if not found:
        out.append("Connection: %s" % want)
    return ("\r\n".join([status] + out) + "\r\n\r\n").encode("latin-1")


def _read_backend_response(back):
    back.settimeout(HEAD_TIMEOUT)
    resp = b""
    while b"\r\n\r\n" not in resp:
        try:
            chunk = back.recv(65536)
        except socket.timeout:
            break
        except OSError:
            break
        if not chunk:
            break
        resp += chunk
        if len(resp) > MAX_BUF and b"\r\n\r\n" not in resp:
            break
        if len(resp) > 10 * 1024 * 1024:
            break
    sep = resp.find(b"\r\n\r\n")
    if sep < 0:
        return None if not resp else resp
    head = resp[:sep + 4]
    rest = resp[sep + 4:]
    try:
        hs = head.decode("latin-1")
    except Exception:
        return resp
    clen = None
    chunked = False
    for line in hs.split("\r\n")[1:]:
        if ":" not in line:
            continue
        k, v = line.split(":", 1)
        kl = k.strip().lower()
        if kl == "content-length":
            try:
                clen = int(v.strip())
            except ValueError:
                clen = None
        if kl == "transfer-encoding" and "chunked" in v.lower():
            chunked = True
    if chunked or clen is None:
        back.settimeout(2.0)
        while True:
            try:
                chunk = back.recv(65536)
            except socket.timeout:
                break
            except OSError:
                break
            if not chunk:
                break
            resp += chunk
            if len(resp) > 10 * 1024 * 1024:
                break
            if not chunked and clen is None:
                break
        return resp
    need = clen - len(rest)
    while need > 0:
        try:
            chunk = back.recv(min(65536, need))
        except socket.timeout:
            break
        except OSError:
            break
        if not chunk:
            break
        resp += chunk
        need -= len(chunk)
    return resp


def handle_client(client, pools, log, metrics):
    conn_id = uuid.uuid4().hex[:8]
    t_conn = time.time()
    buf = b""
    eof = False
    reqs = 0
    try:
        while reqs < MAX_REQS:
            deadline = time.time() + HEAD_TIMEOUT
            method = target = version = None
            headers = {}
            body = b""
            rest = b""
            req_bytes = b""
            complete = False
            bad = None
            chunked_req = False
            timed_out = False
            while True:
                if buf:
                    try:
                        m, t, v, h, bdy, r = parse_one(buf)
                    except Exception:
                        m, t, v, h, bdy, r = (None, None, None, {}, b"malformed", b"")
                    if bdy == b"chunked-unsupported" or (m is not None and bdy == b"chunked-unsupported"):
                        chunked_req = True
                        if m is not None:
                            method, target, version, headers = m, t, v, h
                        break
                    if m is not None:
                        method, target, version, headers, body, rest = m, t, v, h, bdy, r
                        req_bytes = buf[:len(buf) - len(r)]
                        complete = True
                        break
                    if bdy == b"malformed":
                        bad = "bad request"
                        break
                    if len(buf) > MAX_BUF:
                        bad = "head too large"
                        break
                else:
                    if eof:
                        break
                if len(buf) > MAX_BUF:
                    bad = "head too large"
                    break
                now = time.time()
                if now >= deadline:
                    timed_out = True
                    break
                try:
                    client.settimeout(max(deadline - now, 0.1))
                    chunk = client.recv(65536)
                except socket.timeout:
                    timed_out = True
                    break
                except OSError:
                    eof = True
                    break
                if not chunk:
                    eof = True
                    break
                buf += chunk
                if len(buf) > MAX_BUF:
                    continue
            if chunked_req:
                tid = uuid.uuid4().hex[:8]
                t0 = time.time()
                ms = (time.time() - t0) * 1000
                _send_simple(client, 400, "Bad Request", "Bad Request")
                log.error("bad request", trace_id=tid, up="", method=method or "",
                          target=target or "", ms=round(ms, 2))
                metrics.hit(ms, False)
                reqs += 1
                break
            if bad is not None:
                tid = uuid.uuid4().hex[:8]
                t0 = time.time()
                ms = (time.time() - t0) * 1000
                _send_simple(client, 400, "Bad Request", "Bad Request")
                log.error(bad, trace_id=tid, up="", method="", target="",
                          ms=round(ms, 2))
                metrics.hit(ms, False)
                reqs += 1
                break
            if not complete:
                if not buf and eof and reqs == 0:
                    tid = uuid.uuid4().hex[:8]
                    ms = (time.time() - t_conn) * 1000
                    log.error("client closed", trace_id=tid, up="", method="",
                              target="", ms=round(ms, 2))
                    metrics.hit(ms, False)
                    break
                if not buf and (eof or timed_out) and reqs > 0:
                    break
                if not buf and timed_out and reqs == 0:
                    tid = uuid.uuid4().hex[:8]
                    ms = (time.time() - t_conn) * 1000
                    _send_simple(client, 400, "Bad Request", "Bad Request")
                    log.error("incomplete request", trace_id=tid, up="", method="",
                              target="", ms=round(ms, 2))
                    metrics.hit(ms, False)
                    reqs += 1
                    break
                tid = uuid.uuid4().hex[:8]
                ms = (time.time() - t_conn) * 1000
                _send_simple(client, 400, "Bad Request", "Bad Request")
                log.error("incomplete request", trace_id=tid, up="", method="",
                          target="", ms=round(ms, 2))
                metrics.hit(ms, False)
                reqs += 1
                break
            tid = uuid.uuid4().hex[:8]
            t0 = time.time()
            verdict, rule = _waf.inspect(method or "", target or "", headers, body)
            if verdict == "deny":
                ms = (time.time() - t0) * 1000
                _send_simple(client, 403, "Forbidden", "Blocked")
                log.error("waf deny", trace_id=tid, up="", method=method,
                          target=target, ms=round(ms, 2), rule=rule)
                metrics.hit(ms, False)
                reqs += 1
                break
            key = route_key(headers, target) or ""
            pool = pools.get(key.lower())
            if pool is None:
                ms = (time.time() - t0) * 1000
                _send_simple(client, 404, "Not Found", "No Route")
                log.error("no route", trace_id=tid, up="", method=method,
                          target=target, ms=round(ms, 2), host=key)
                metrics.hit(ms, False)
                reqs += 1
                break
            up = pool.pick_round_robin()
            if not up:
                ms = (time.time() - t0) * 1000
                _send_simple(client, 503, "Service Unavailable", "No Healthy Upstream")
                log.error("no healthy upstream", trace_id=tid, up="", method=method,
                          target=target, ms=round(ms, 2))
                metrics.hit(ms, False)
                reqs += 1
                break
            back = socket.socket()
            back.settimeout(HEAD_TIMEOUT)
            try:
                h, p = parse_host(up)
                back.connect((h, p))
            except OSError:
                pool.mark_down(up)
                _close_quietly(back)
                ms = (time.time() - t0) * 1000
                _send_simple(client, 502, "Bad Gateway", "Bad Gateway")
                log.error("connect fail", trace_id=tid, up=up, method=method,
                          target=target, ms=round(ms, 2))
                metrics.hit(ms, False)
                reqs += 1
                break
            log.info("route", trace_id=tid, up=up, method=method, target=target)
            try:
                back.sendall(req_bytes)
            except OSError:
                pool.mark_down(up)
                ms = (time.time() - t0) * 1000
                log.error("upstream send fail", trace_id=tid, up=up, method=method,
                          target=target, ms=round(ms, 2))
                metrics.hit(ms, False)
                _close_quietly(back)
                reqs += 1
                break
            resp = _read_backend_response(back)
            _close_quietly(back)
            if resp is None:
                pool.mark_down(up)
                ms = (time.time() - t0) * 1000
                _send_simple(client, 502, "Bad Gateway", "Bad Gateway")
                log.error("bad gateway", trace_id=tid, up=up, method=method,
                          target=target, ms=round(ms, 2))
                metrics.hit(ms, False)
                reqs += 1
                break
            client_keep = is_keep_alive(version, headers)
            reqs += 1
            will_close = (not client_keep) or (reqs >= MAX_REQS)
            sep = resp.find(b"\r\n\r\n")
            if sep >= 0:
                head = resp[:sep + 4]
                rbody = resp[sep + 4:]
                resp = _set_conn(head, not will_close) + rbody
            try:
                try:
                    client.settimeout(None)
                except OSError:
                    pass
                client.sendall(resp)
            except OSError:
                ms = (time.time() - t0) * 1000
                log.error("client send fail", trace_id=tid, up=up, method=method,
                          target=target, ms=round(ms, 2))
                metrics.hit(ms, False)
                break
            ms = (time.time() - t0) * 1000
            metrics.hit(ms, True)
            log.info("done", trace_id=tid, up=up, method=method,
                     target=target, ms=round(ms, 2))
            buf = rest
            if will_close:
                break
            if eof and not buf:
                break
            continue
    except Exception as exc:
        try:
            ms = (time.time() - t_conn) * 1000
            log.error("internal error", trace_id=conn_id, up="", method="",
                      target="", ms=round(ms, 2), err=repr(exc))
            metrics.hit(ms, False)
        finally:
            pass
    finally:
        ms = (time.time() - t_conn) * 1000
        try:
            log.info("conn", trace_id=conn_id, reqs=reqs, ms=round(ms, 2))
        except Exception:
            pass
        _close_quietly(client)


def main(argv=None):
    ap = argparse.ArgumentParser(
        description="BRAT L7 demo: route HTTP by Host header")
    ap.add_argument("--listen", default="127.0.0.1:8080")
    ap.add_argument("--route", required=True,
                    help="host=up1,up2;host2=up3")
    ap.add_argument("--log", default=None)
    ap.add_argument("--metrics-port", type=int, default=0)
    a = ap.parse_args(argv)
    try:
        spec = parse_route(a.route)
    except ValueError as exc:
        ap.error(str(exc))
    log = Log(a.log)
    metrics = Metrics()
    pools = {host: Pool(ups, log, metrics)
             for host, ups in spec.items()}
    for pool in pools.values():
        threading.Thread(target=pool.watch, daemon=True).start()
    if a.metrics_port:
        threading.Thread(target=serve_metrics,
                         args=(a.metrics_port, metrics, log),
                         daemon=True).start()
    lh, lp = parse_host(a.listen)
    srv = socket.socket()
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind((lh, lp))
    srv.listen(128)
    log.info("l7 listen", trace_id="boot", listen=a.listen,
             routes=sorted(pools))
    while True:
        try:
            c, _ = srv.accept()
        except OSError:
            continue
        threading.Thread(target=handle_client,
                         args=(c, pools, log, metrics),
                         daemon=True).start()


if __name__ == "__main__":
    main()
