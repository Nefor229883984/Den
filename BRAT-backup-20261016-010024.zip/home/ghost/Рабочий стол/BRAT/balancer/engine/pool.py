"""PoolV2: upstream pool with pluggable picker from algos.py.

Wraps RoundRobin / LeastConn / IpHash / EwmaPicker selected by name,
with lb.py-style liveness tracking: 2s TCP-dial watch, mark_down/mark_up
JSON logs, lb_up_ok metrics. Thread-safe. stdlib only.
"""
import socket
import threading
import time

from algos import RoundRobin, LeastConn, IpHash, EwmaPicker


def _parse_host(s):
    h, p = s.rsplit(":", 1)
    return h, int(p)


def _normalize(algo):
    return str(algo).strip().lower().replace("_", "-").replace(" ", "-")


_FACTORIES = {
    "round-robin": RoundRobin,
    "roundrobin": RoundRobin,
    "rr": RoundRobin,
    "least-conn": LeastConn,
    "leastconn": LeastConn,
    "least-connections": LeastConn,
    "ip-hash": IpHash,
    "iphash": IpHash,
    "ewma": EwmaPicker,
    "ewma-latency": EwmaPicker,
}

_CANON = ("round-robin", "least-conn", "ip-hash", "ewma")


class PoolV2:
    def __init__(self, upstreams, log, metrics, algo="round-robin"):
        factory = _FACTORIES.get(_normalize(algo))
        if factory is None:
            raise ValueError(
                "unknown algo %r (want one of: %s)" % (algo, ", ".join(_CANON))
            )
        self.ups = list(upstreams)
        self.log = log
        self.metrics = metrics
        self.algo = _normalize(algo)
        self.picker = factory()
        self._lock = threading.RLock()
        self.alive = {u: True for u in self.ups}
        for u in self.ups:
            metrics.mark(u, True)

    def _healthy(self):
        with self._lock:
            return [u for u in self.ups if self.alive.get(u)]

    def healthy(self, up):
        try:
            h, p = _parse_host(up)
        except ValueError:
            with self._lock:
                return bool(self.alive.get(up, False))
        s = socket.socket()
        s.settimeout(1.0)
        try:
            s.connect((h, p))
            return True
        except OSError:
            return False
        finally:
            s.close()

    def mark_down(self, up):
        with self._lock:
            if self.alive.get(up):
                self.alive[up] = False
                self.metrics.mark(up, False)
                self.log.warn("down", up=up)

    def mark_up(self, up):
        with self._lock:
            if not self.alive.get(up):
                self.alive[up] = True
                self.metrics.mark(up, True)
                self.log.info("back", up=up)

    def pick(self, client_ip=None):
        healthy = self._healthy()
        if not healthy:
            return None
        if isinstance(self.picker, IpHash):
            return self.picker.pick(healthy, client_ip or "")
        up = self.picker.pick(healthy)
        if isinstance(self.picker, LeastConn):
            self.picker.acquire(up)
        return up

    def release(self, up):
        if up is None:
            return
        if isinstance(self.picker, LeastConn):
            self.picker.release(up)

    def note(self, up, ms, ok):
        self.metrics.hit(float(ms), bool(ok))
        if ok and isinstance(self.picker, EwmaPicker):
            self.picker.observe(up, float(ms))

    def watch(self, every=2.0):
        while True:
            for u in self.ups:
                if self.healthy(u):
                    self.mark_up(u)
                else:
                    self.mark_down(u)
            time.sleep(every)
