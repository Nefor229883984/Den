"""HTTP/1.1 request parser for brat-lb. Stdlib only, works on raw bytes."""

_METHODS = (
    b"GET", b"HEAD", b"POST", b"PUT", b"DELETE",
    b"CONNECT", b"OPTIONS", b"TRACE", b"PATCH",
)

_INCOMPLETE = (None, None, None, {}, b"incomplete")


def _is_partial_prefix(buf: bytes) -> bool:
    for m in _METHODS:
        if m.startswith(buf) or buf.startswith(m[: len(buf)]):
            return True
    token = buf.split(b" ", 1)[0] if b" " in buf else buf
    if token and all(
        (48 <= c <= 57) or (65 <= c <= 90) or (97 <= c <= 122) or c in b"!#$%&'*+-.^_`|~"
        for c in token
    ):
        return True
    return False


def parse_request(buf: bytes):
    """Parse first HTTP/1.1 request in buf.

    Returns (method, target, version, headers, body):
      headers: dict with lowercase str keys, str values.
      body: bytes framed by Content-Length (b"" if none).
    Chunked: body is b"chunked-unsupported".
    Malformed/incomplete: (None, None, None, {}, b"malformed"|b"incomplete").
    Trailing pipelined bytes are ignored; use parse_one/parse_many for them.
    """
    if not isinstance(buf, (bytes, bytearray)):
        return (None, None, None, {}, b"malformed")
    buf = bytes(buf)
    if not buf:
        return _INCOMPLETE
    sep = buf.find(b"\r\n\r\n")
    if sep < 0:
        if _is_partial_prefix(buf.split(b"\r\n", 1)[0]):
            return _INCOMPLETE
        return (None, None, None, {}, b"malformed")
    head = buf[:sep]
    rest = buf[sep + 4 :]
    lines = head.split(b"\r\n")
    if not lines or not lines[0]:
        return (None, None, None, {}, b"malformed")
    request_line = lines[0].decode("latin-1")
    parts = request_line.split(" ")
    if len(parts) != 3:
        return (None, None, None, {}, b"malformed")
    method, target, version = parts
    if not method or not target or version not in ("HTTP/1.0", "HTTP/1.1"):
        return (None, None, None, {}, b"malformed")
    if any(c in method for c in ("\r", "\n", " ", "\t")) or any(
        c in target for c in ("\r", "\n", " ", "\t")
    ):
        return (None, None, None, {}, b"malformed")
    headers = {}
    lengths = []
    for raw in lines[1:]:
        if not raw:
            return (None, None, None, {}, b"malformed")
        if b":" not in raw:
            return (None, None, None, {}, b"malformed")
        k, v = raw.decode("latin-1").split(":", 1)
        k = k.strip().lower()
        v = v.strip()
        if not k or any(c in k for c in (" ", "\t", "\r", "\n")):
            return (None, None, None, {}, b"malformed")
        headers[k] = v
        if k == "content-length":
            lengths.append(v)
    if lengths:
        if len(set(lengths)) > 1:
            return (None, None, None, {}, b"malformed")
        cl = lengths[0]
        if not cl.isdigit():
            return (None, None, None, {}, b"malformed")
        try:
            n = int(cl)
        except ValueError:
            return (None, None, None, {}, b"malformed")
    else:
        n = 0
    te = headers.get("transfer-encoding", "")
    if any(t.strip().lower() == "chunked" for t in te.split(",")) if te else False:
        return (method, target, version, headers, b"chunked-unsupported")
    if len(rest) < n:
        return _INCOMPLETE
    body = rest[:n]
    return (method, target, version, headers, body)


def parse_one(buf: bytes):
    """Parse first request, return (method, target, version, headers, body, rest).

    rest holds trailing pipelined bytes (b"" if none). Error rows carry
    b"" rest except incomplete, which keeps the input for buffering.
    """
    res = parse_request(buf)
    if res[0] is None:
        if res[4] == b"incomplete":
            return (None, None, None, {}, b"incomplete", bytes(buf))
        if res[4] == b"chunked-unsupported":
            b = bytes(buf)
            sep = b.find(b"\r\n\r\n")
            rest = b[sep + 4 :] if sep >= 0 else b""
            return (res[0], res[1], res[2], res[3], res[4], rest)
        return (None, None, None, {}, res[4], b"")
    method, target, version, headers, body = res
    b = bytes(buf)
    sep = b.find(b"\r\n\r\n")
    end = sep + 4 + len(body)
    return (method, target, version, headers, body, b[end:])


def parse_many(buf: bytes):
    """Parse all pipelined requests in buf. Returns list of 5-tuples."""
    out = []
    rest = bytes(buf)
    while rest:
        m, t, v, h, body, rest2 = parse_one(rest)
        if m is None:
            break
        out.append((m, t, v, h, body))
        if not rest2:
            break
        rest = rest2
    return out


def is_keep_alive(version: str, headers: dict) -> bool:
    """True if connection persists per HTTP/1.0+1.1 rules."""
    low = {}
    for k, v in (headers or {}).items():
        low[str(k).lower()] = str(v).lower()
    conn = low.get("connection", "")
    tokens = [t.strip() for t in conn.split(",")]
    if "close" in tokens:
        return False
    if "keep-alive" in tokens:
        return True
    return version == "HTTP/1.1"


def route_key(headers: dict, target: str) -> str:
    """Host-or-path routing key: Host header (no port) else request path."""
    low = {}
    for k, v in (headers or {}).items():
        low[str(k).lower()] = str(v)
    host = (low.get("host", "") or "").strip().lower()
    if host:
        if host.startswith("["):
            end = host.find("]")
            return host[: end + 1] if end >= 0 else host
        return host.split(":")[0] or host
    t = target or "/"
    if t.startswith("http://") or t.startswith("https://"):
        auth = t.split("://", 1)[1].split("/", 1)[0].lower()
        if auth.startswith("["):
            end = auth.find("]")
            return auth[: end + 1] if end >= 0 else auth
        return auth.split(":")[0] or auth
    return t.split("?", 1)[0].split("#", 1)[0] or "/"
