def peek_sni(buf: bytes) -> str | None:
    try:
        if not isinstance(buf, (bytes, bytearray)):
            return None
        n = len(buf)
        if n < 5:
            return None
        if buf[0] != 0x16:
            return None
        ver = (buf[1] << 8) | buf[2]
        if ver < 0x0301 or ver > 0x0304:
            return None
        rec_len = (buf[3] << 8) | buf[4]
        if rec_len < 4:
            return None
        if n < 5 + rec_len:
            return None
        hs = 5
        if buf[hs] != 0x01:
            return None
        hs_len = (buf[hs + 1] << 16) | (buf[hs + 2] << 8) | buf[hs + 3]
        if hs_len + 4 > rec_len:
            return None
        pos = hs + 4
        end = hs + 4 + hs_len
        if end > n:
            return None
        if pos + 2 + 32 + 1 > end:
            return None
        pos += 2 + 32
        sess_len = buf[pos]
        pos += 1
        if pos + sess_len > end:
            return None
        pos += sess_len
        if pos + 2 > end:
            return None
        cs_len = (buf[pos] << 8) | buf[pos + 1]
        pos += 2
        if pos + cs_len > end:
            return None
        pos += cs_len
        if pos + 1 > end:
            return None
        comp_len = buf[pos]
        pos += 1
        if pos + comp_len > end:
            return None
        pos += comp_len
        if pos + 2 > end:
            return None
        ext_total = (buf[pos] << 8) | buf[pos + 1]
        pos += 2
        if pos + ext_total > end:
            return None
        ext_end = pos + ext_total
        while pos + 4 <= ext_end:
            ext_type = (buf[pos] << 8) | buf[pos + 1]
            ext_len = (buf[pos + 2] << 8) | buf[pos + 3]
            pos += 4
            if pos + ext_len > ext_end:
                return None
            if ext_type == 0:
                p = pos
                pe = pos + ext_len
                if p + 2 > pe:
                    return None
                list_len = (buf[p] << 8) | buf[p + 1]
                p += 2
                if p + list_len > pe:
                    return None
                lend = p + list_len
                while p + 3 <= lend:
                    ntype = buf[p]
                    nlen = (buf[p + 1] << 8) | buf[p + 2]
                    p += 3
                    if p + nlen > lend:
                        return None
                    if ntype == 0:
                        raw = bytes(buf[p:p + nlen])
                        try:
                            name = raw.decode("ascii")
                        except Exception:
                            return None
                        if not name or len(name) > 253:
                            return None
                        return name
                    p += nlen
                return None
            pos += ext_len
        return None
    except Exception:
        return None


def pick_by_sni(sni, table: dict, default):
    try:
        if not isinstance(sni, str) or not sni:
            return default
        if table is None:
            return default
        if sni in table:
            return table[sni]
        low = sni.lower()
        best = None
        best_len = -1
        for k, v in table.items():
            if not isinstance(k, str) or not k.startswith("*."):
                continue
            if len(k) <= 2:
                continue
            suffix = k[1:].lower()
            if not low.endswith(suffix):
                continue
            prefix = low[: len(low) - len(suffix)]
            if not prefix or "." in prefix:
                continue
            if len(suffix) > best_len:
                best_len = len(suffix)
                best = v
        if best is not None:
            return best
        return default
    except Exception:
        return default
