# nginx-ops reference (vendored)

Source: 0xDarkMatter/claude-mods nginx-ops skill, MIT.
Kept as parity reference for BRAT LB routing, upstream, TLS and tuning.

## Reverse Proxy Decision Tree

- Single backend: plain `proxy_pass http://127.0.0.1:3000`.
- Multiple: session persistence by IP → ip_hash; unequal capacity → weight; fewest conns → least_conn; default → round-robin.
- WebSocket: `Upgrade` + `Connection: upgrade` headers, long timeouts.
- gRPC: `grpc_pass`. SSE/streaming: `proxy_buffering off`.

## Minimal production TLS

- `listen 443 ssl`, certs fullchain + privkey, `TLSv1.2 TLSv1.3` only.
- Ciphers ECDHE+GCM suites, `ssl_prefer_server_ciphers off`.
- HSTS `max-age=63072000; includeSubDomains; preload` always.
- OCSP stapling on + verify, resolver with timeout.
- Session cache shared `SSL:10m`, tickets off.
- HTTP→HTTPS 301 redirect on port 80.

## Location priority (NOT config order)

1. `=` exact — wins immediately.
2. `^~` prefix — stops search, skips regex.
3. `~` / `~*` regex — first match in file order wins over prefix.
4. Plain prefix — longest wins.

## Proxy headers (always set)

`Host $host`, `X-Real-IP $remote_addr`, `X-Forwarded-For $proxy_add_x_forwarded_for`, `X-Forwarded-Proto $scheme`.

## Gotchas that bite

- `proxy_pass http://backend/` (trailing slash) strips the matched prefix; without slash it preserves.
- Large JWT/cookie headers → 502 unless `proxy_buffer_size 8k` + `proxy_buffers 4 16k`.
- Each client eats 2 fds (downstream + upstream): `worker_connections 4096` + `worker_rlimit_nofile`.
- `if` inside location is evil: implicit nested location. Map variables instead.
- Any `add_header`/`proxy_set_header` in a child block REPLACES all parent ones — redeclare all.
- Dynamic upstreams via variables need an explicit `resolver`.
- `alias` replaces the location path, `root` appends it.

## Tuning baselines

- `worker_processes auto`, `multi_accept on`, `sendfile on`.
- gzip level 5, min length 256, `gzip_proxied any`, json/js/css/mime types.
- Static: `expires 1y` + immutable for hashed assets; open_file_cache for hot files.
- Health endpoint `/health` with `access_log off`.
- Rate limit: `limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s`, burst 20 nodelay, status 429.

## Docker

- Upstream via service name (`server app:3000`), internal `expose` only, nginx publishes 80/443.
- SPA: `try_files $uri $uri/ /index.html`.
