# Nginx parity (refs/nginx-ops.md vs BRAT engine)

| Nginx behavior | BRAT status | Proof |
|---|---|---|
| Location priority `=` > `^~` > regex > prefix | MISSING — gateway routes by Host only, no path table | no test |
| `proxy_pass` trailing-slash strip | MISSING — raw-byte forward, no URI rewrite | no test |
| `Host` header forwarded | DONE — raw bytes proxied incl. Host | `balancer/tests/test_l7.py` Host routing asserts |
| `X-Real-IP` / `X-Forwarded-For` / `X-Forwarded-Proto` injected | MISSING — L7 forwards bytes untouched | no test |
| TLS 1.2+ + HSTS | PARTIAL — `balancer/engine/tls.py` terminates TLS 1.2+, no HSTS header (passthrough has no header injection) | `balancer/tests/test_tls.py` |
| HTTP keep-alive | DONE — 100 reqs/conn, per-request trace | `balancer/tests/test_l7.py` 25 asserts |
| Rate limit 429 | MISSING | no test |
| Active health checks + eject | DONE — 2s TCP dial, mark down/up, `/metrics` | `balancer/tests/test_lb.py` |
| Weighted round-robin | MISSING — RR/least-conn/ip-hash/ewma exist, no weights | `balancer/tests/test_algos.py` |
| ip-hash persistence | DONE | `balancer/tests/test_algos.py` |
| least_conn | DONE | `balancer/tests/test_algos.py` |
| `worker_connections` math (2 fds/client) | PARTIAL — `--max-conns` semaphore, no fd accounting | `balancer/engine/lb.py` |
| Graceful drain | DONE — drain ≤5s on SIGINT/SIGTERM | `balancer/engine/lb.py` |
| `if`-in-location avoidance | DONE — policy uses `match`, no `if`-routing | `balancer/examples/balancer.brat` |
| access_log off for health | MISSING — health checks unlogged? actually watch dials are silent, ok | no test |

Score: 8 done / 2 partial / 5 missing.
Top-3 missing for production: X-Forwarded-* injection, rate limit 429, weighted RR.
