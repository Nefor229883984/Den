# BRAT — убийца Rust для балансировщиков

Прод-язык: заимки без аннотаций времён, ошибки как значения, телеметрия как синтаксис.
Open-source с дня 0, Apache-2.0.

Честно о статусе: это v0.1, до продакшена не готово. Проверки владения
внутрифункциональные и неполные (см. LEDGER), `spawn` не защищает от гонок,
LLVM-бэкенда нет. Что действительно работает — перечислено ниже и проверяется
прогонами, а не обещаниями.

## Расклад

1. **Нет `'a` лайфтаймов в коде.** Инференс. 99% кода без аннотаций.
2. **Нет файтов с borrow-checker.** Flow-sensitive займы, ошибка сразу с именем переменной.
3. **Один `str`, один `vec`.** `ref str` — вью, `str` — владение. Литерал `[200, 404]`, `len`, `for x in v`, `match` с десахаром.
4. **Ошибки без паники.** `?` + `or` + `try/catch`. `null` запрещен.
5. **Нет async-цветов.** `spawn { }` + join. Гонки ловит проверка владения.
6. **Телеметрия — часть языка.** `log.info`, `metric.counter`, `trace.span` — синтаксис.
7. **Safe по дефолту.** `unsafe { }` только изолированно.
8. **Балансировщик живой.** TCP round-robin + 4 алгоритма, L7 Host-роутинг + keep-alive, TLS 1.2+ терминация, SNI-роутинг, JSONL + `/metrics`.
9. **Бэкенды настоящие.** Интерпретатор + C99-эмиттер (58/58 программ побайтово = интерпретатору, потоки ОС) + mono fast-path в сырой `long`/`double`. LLVM — только proof-of-concept, не бэкенд.
10. **Типы где надо.** Статические острова: аннотированное — проверено статически, остальное — динамика. Две проверки в `brat check`.

## Структура

- `lang/engine` — движок языка: `brat/` пакет, `borrow.py`, `typer.py`, `codegen_c.py`, `codegen_llvm.py`, `cli.py`
- `lang/examples` — `hello.brat`, `control.brat`, `own_good.brat`, `own_bad.brat`,
  `span.brat`
- `lang/tests` — `test_lang.py` (единая точка), `test_native.py`, `test_cli.py`, `test_codegen_c.py`, `test_pkg.py`, `test_fuzz.py`
- `lang/spec/SPEC.md` — спека
- `balancer/engine` — `lb.py`, `pool.py`, `gateway.py`, `tls.py`, `mkcert.py`, `sni.py`, `http_parse.py`, `algos.py`, `otel.py`, `waf.py`
- `balancer/tests` — по файлу на область, `test_lb.py` базовый регресс
- `balancer/examples/balancer.brat` — политика балансировки на BRAT
- `balancer/DESIGN.md` — ядро + телеметрия + проверенные замеры
- `bench` — `bench.py`, `rounds.py` (медиана), `HABR_DRAFT.md` отложен

## Быстрый старт

```
python lang\tests\test_lang.py
python balancer\tests\test_lb.py
python bench\rounds.py 2 20 2
```

## Дорожная карта

- Сейчас: единый рантайм, ownership-чек, C + LLVM JIT, живой LB с TLS/SNI/L7
- Дальше: `brat fmt/test`, трейты и дженерики, HTTP/2, io_uring на Linux, wrk-баттл
- v1.0: прод-балансировщик на самом BRAT, один бинарь, open-core PRO
