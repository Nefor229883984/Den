import importlib.util
import os
import re
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
_BRAT_MOD = None
_OWN_MOD = None
_CBACK2_MOD = None
_CBACK2_FAILED = False
_SCAFFOLD_MOD = None

def _load_mod(tag, filename):
    path = os.path.join(HERE, filename)
    spec = importlib.util.spec_from_file_location(tag, path)
    if spec is None or spec.loader is None:
        raise ImportError("cannot load " + filename)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def brat_mod():
    global _BRAT_MOD
    if _BRAT_MOD is None:
        _BRAT_MOD = _load_mod("brat_engine_cli", "brat.py")
    return _BRAT_MOD

def own_mod():
    global _OWN_MOD
    if _OWN_MOD is None:
        _OWN_MOD = _load_mod("brat_borrow_cli", "borrow.py")
    return _OWN_MOD

def codegen_c_mod():
    global _CBACK2_MOD, _CBACK2_FAILED
    if _CBACK2_MOD is not None:
        return _CBACK2_MOD
    if _CBACK2_FAILED:
        raise ImportError("codegen_c unavailable")
    try:
        _CBACK2_MOD = _load_mod("brat_codegen_c_cli", "codegen_c.py")
    except Exception as e:
        _CBACK2_FAILED = True
        raise ImportError(str(e))
    return _CBACK2_MOD

def scaffold_mod():
    global _SCAFFOLD_MOD
    if _SCAFFOLD_MOD is None:
        _SCAFFOLD_MOD = _load_mod("brat_scaffold_cli", "scaffold.py")
    return _SCAFFOLD_MOD

def normalize_equals(line):
    out = []
    i = 0
    n = len(line)
    in_str = False
    while i < n:
        c = line[i]
        if in_str:
            out.append(c)
            if c == "\\":
                if i + 1 < n:
                    out.append(line[i + 1])
                    i += 2
                    continue
            elif c == '"':
                in_str = False
            i += 1
            continue
        if c == '"':
            in_str = True
            out.append(c)
            i += 1
            continue
        if c == "/" and i + 1 < n and line[i + 1] == "/":
            out.append(line[i:])
            break
        if c == "=":
            prev = line[i - 1] if i - 1 >= 0 else ""
            nxt = line[i + 1] if i + 1 < n else ""
            if nxt == "=" or nxt == ">" or prev in ("=", "!", "<", ">", "+", "-", "*", "/", "%"):
                out.append(c)
                i += 1
                continue
            cur = "".join(out).rstrip(" \t")
            j = i + 1
            while j < n and line[j] in (" ", "\t"):
                j += 1
            if j >= n:
                if cur == "":
                    out = ["="]
                else:
                    out = [cur + " ="]
                i = j
                continue
            if cur == "":
                out = ["= "]
            else:
                out = [cur + " = "]
            i = j
            continue
        out.append(c)
        i += 1
    return "".join(out)

def count_braces(line):
    opens = 0
    closes = 0
    in_str = False
    i = 0
    n = len(line)
    while i < n:
        c = line[i]
        if in_str:
            if c == "\\":
                i += 2
                continue
            if c == '"':
                in_str = False
            i += 1
            continue
        if c == '"':
            in_str = True
            i += 1
            continue
        if c == "/" and i + 1 < n and line[i + 1] == "/":
            break
        if c == "{":
            opens += 1
        elif c == "}":
            closes += 1
        i += 1
    return opens, closes

def fmt_src(src):
    src = src.replace("\r\n", "\n").replace("\r", "\n")
    lines = src.splitlines()
    out = []
    depth = 0
    for raw in lines:
        stripped = raw.strip()
        if stripped == "":
            out.append("")
            continue
        norm = normalize_equals(stripped).strip()
        if norm == "":
            out.append("")
            continue
        orig = depth
        if norm.startswith("}"):
            depth = depth - 1 if depth > 0 else 0
        out.append("  " * depth + norm)
        o, c = count_braces(norm)
        depth = orig + (o - c)
        if depth < 0:
            depth = 0
    while out and out[-1] == "":
        out.pop()
    return "\n".join(out) + "\n"

def print_usage():
    sys.stderr.write("usage: brat file.brat [args...]\n")
    sys.stderr.write("       brat run file.brat [-- args...]\n")
    sys.stderr.write("       brat check file.brat [more...]\n")
    sys.stderr.write("       brat fmt file.brat [more...]\n")
    sys.stderr.write("       brat emit-c file.brat\n")
    sys.stderr.write("       brat test file.brat [more...]\n")
    sys.stderr.write("       brat build file.brat [-o out.exe]\n")
    sys.stderr.write("       brat pkg add <url> | brat pkg install\n")
    sys.stderr.write("       brat new NAME [--kind service|tool]\n")


def _read_src(path):
    """Source text for a diagnostic snippet, or "" when the file is unreadable.

    Every caller is already on its way to exit 1, so this reports the read
    failure instead of raising in the middle of building a diagnostic -- but it
    does not stay silent: an empty source otherwise prints a parse error for a
    file nobody managed to read.
    """
    try:
        with open(path, encoding="utf-8") as f:
            return f.read()
    except OSError as e:
        sys.stderr.write("brat: cannot read %s: %s\n" % (path, e))
        return ""


def parse_error_line(exc):
    """Line number of a BRAT lexer/parser error, or None if `exc` is not one.

    BRAT raises a bare `SyntaxError('... at line N')` with no filename, so a
    Python SyntaxError raised while compiling brat.py itself is told apart by
    its populated `filename`.
    """
    if getattr(exc, "filename", None) is not None:
        return None
    m = re.search(r"\bat line (\d+)\s*\Z", str(exc))
    return int(m.group(1)) if m else None


def syntax_error(path, src, exc):
    """SPEC.md 9: a parse error is always `file:line: error: ...` plus the
    offending source line -- never a Python traceback. Returns 1."""
    ln = parse_error_line(exc)
    if ln is None:
        sys.stderr.write("%s: error: %s\n" % (path, exc))
        return 1
    sys.stderr.write("%s:%d: error: %s\n" % (path, ln, exc))
    sys.stderr.write("  --> %s:%d\n" % (path, ln))
    lines = src.splitlines() if src else []
    if 1 <= ln <= len(lines):
        sys.stderr.write("  | %s\n" % lines[ln - 1].strip())
    return 1


def do_test(args):
    files = [a for a in args if a != "--"]
    if not files:
        print_usage()
        return 2
    failed = 0
    for path in files:
        p = subprocess.run([sys.executable, os.path.join(HERE, "brat.py"), path],
                           capture_output=True, text=True, timeout=300)
        if p.returncode == 0:
            sys.stdout.write("ok %s\n" % path)
        else:
            failed += 1
            tail = (p.stdout + p.stderr)[-300:]
            sys.stdout.write("FAIL %s exit=%d %s\n" % (path, p.returncode, tail))
    sys.stdout.write("%d passed, %d failed\n" % (len(files) - failed, failed))
    return 1 if failed else 0

def blame_parse_error(brat, files, exc):
    """Find which file a parser error came from and report it with a snippet.

    Only reached after borrow.py/typer.py already blew up, so the extra parse
    costs nothing on the happy path and its `_LINES` pollution cannot be
    observed: we are on our way to exit 1.
    """
    for path in files:
        src = _read_src(path)
        try:
            brat.parse_prog(brat.Cur(brat.lex(src)))
        except SyntaxError as inner:
            return syntax_error(path, src, inner)
    first = files[0] if files else ""
    return syntax_error(first, _read_src(first), exc)


def do_run(args):
    if "--" in args:
        files = args[:args.index("--")]
        extra = args[args.index("--") + 1:]
    else:
        files = args[:1]
        extra = args[1:]
    if not files:
        print_usage()
        return 2
    return brat_mod().run_file(files[0], extra)

def do_check(args):
    files = [a for a in args if a != "--"]
    if not files:
        print_usage()
        return 2
    brat = brat_mod()
    own = own_mod()
    own.load_brat = lambda path=None: brat
    try:
        rc = own.main(["check"] + files)
    except SyntaxError as e:
        return blame_parse_error(brat, files, e)
    try:
        tp = _load_mod("brat_typer_cli", "typer.py")
        tp.load_brat = lambda path=None: brat
        rc2 = tp.main(["check"] + files)
    except SyntaxError as e:
        return blame_parse_error(brat, files, e)
    except Exception as e:
        sys.stderr.write("brat check: typer failed, result is not a clean "
                         "bill: %s: %s\n" % (type(e).__name__, e))
        return rc or 1
    return rc or rc2

def do_fmt(args):
    files = [a for a in args if a != "--"]
    if not files:
        print_usage()
        return 2
    code = 0
    for path in files:
        try:
            src = open(path, encoding="utf-8").read()
        except OSError as e:
            sys.stderr.write("brat fmt: cannot read %s: %s\n" % (path, e))
            code = 1
            continue
        formatted = fmt_src(src)
        try:
            with open(path, "w", encoding="utf-8", newline="\n") as f:
                f.write(formatted)
        except OSError as e:
            sys.stderr.write("brat fmt: cannot write %s: %s\n" % (path, e))
            code = 1
    return code

def do_emit_c(args):
    gate = "--no-check" not in args
    files = [a for a in args if a not in ("--", "--no-check")]
    files = files[:files.index("--")] if "--" in files else files
    if not files:
        print_usage()
        return 2
    path = files[0]
    try:
        src = open(path, encoding="utf-8").read()
    except OSError as e:
        sys.stderr.write("brat emit-c: cannot read %s: %s\n" % (path, e))
        return 1
    if gate and not _gate_ownership(path):
        sys.stderr.write(
            "brat emit-c: refusing to emit %s: the ownership checker reported "
            "errors above. Emitted C skips every check `brat build` applies.\n"
            "Fix it, or pass --no-check to override deliberately.\n" % path)
        return 1
    try:
        cb = codegen_c_mod()
        out = cb.emit_file(path)
    except Exception as e:
        if parse_error_line(e) is not None:
            return syntax_error(path, src, e)
        sys.stderr.write("brat emit-c: %s: %s\n" % (type(e).__name__, e))
        return 1
    sys.stdout.write(out)
    if not out.endswith("\n"):
        sys.stdout.write("\n")
    return 0

def lock_path():
    return os.path.join(os.getcwd(), "brat.lock")


def read_lock():
    """Contents of brat.lock, or [] when there is no lockfile yet.

    A lockfile that exists but cannot be read or parsed is an error, not an
    empty lock. `brat pkg install` would otherwise proceed as if nothing were
    pinned and stop honouring the hashes it exists to enforce.
    """
    try:
        f = open(lock_path(), encoding="utf-8")
    except FileNotFoundError:
        return []
    with f:
        data = f.read()
    import json as _json
    try:
        items = _json.loads(data)
    except ValueError as e:
        raise SystemExit("brat pkg: %s is not valid JSON: %s" % (lock_path(), e))
    if not isinstance(items, list):
        raise SystemExit("brat pkg: %s wants a JSON list, have %s"
                         % (lock_path(), type(items).__name__))
    return items


def write_lock(items):
    import json as _json
    with open(lock_path(), "w", encoding="utf-8", newline="\n") as f:
        f.write(_json.dumps(items, indent=2, ensure_ascii=False) + "\n")


def fetch_url(url):
    import hashlib as _hl
    import urllib.request as _ur
    with _ur.urlopen(url, timeout=30) as r:
        body = r.read()
    try:
        text = body.decode("utf-8")
    except ValueError:
        raise RuntimeError("non-utf8 dep " + url)
    digest = _hl.sha256(body).hexdigest()
    return text, digest


def do_pkg(args):
    if not args:
        print_usage()
        return 2
    sub = args[0]
    if sub == "add" and len(args) == 2:
        url = args[1]
        name = url.rstrip("/").rsplit("/", 1)[-1]
        if not name.endswith(".brat"):
            sys.stderr.write("brat pkg: url must end with .brat\n")
            return 1
        try:
            text, digest = fetch_url(url)
        except Exception as e:
            sys.stderr.write("brat pkg: fetch %s: %s\n" % (url, e))
            return 1
        vendor = os.path.join(os.getcwd(), "vendor")
        try:
            os.makedirs(vendor, exist_ok=True)
            with open(os.path.join(vendor, name), "w", encoding="utf-8", newline="\n") as f:
                f.write(text)
        except OSError as e:
            sys.stderr.write("brat pkg: write %s\n" % e)
            return 1
        items = [it for it in read_lock() if it.get("file") != name]
        items.append({"file": name, "url": url, "sha256": digest})
        write_lock(items)
        sys.stdout.write("add %s %s\n" % (name, digest[:12]))
        return 0
    if sub == "install" and len(args) == 1:
        items = read_lock()
        if not items:
            sys.stderr.write("brat pkg: empty lock\n")
            return 1
        vendor = os.path.join(os.getcwd(), "vendor")
        os.makedirs(vendor, exist_ok=True)
        code = 0
        for it in items:
            try:
                text, digest = fetch_url(it["url"])
            except Exception as e:
                sys.stderr.write("brat pkg: fetch %s: %s\n" % (it.get("url"), e))
                code = 1
                continue
            if digest != it.get("sha256"):
                sys.stderr.write("brat pkg: HASH MISMATCH %s\n" % it.get("file"))
                code = 1
                continue
            with open(os.path.join(vendor, it["file"]), "w", encoding="utf-8", newline="\n") as f:
                f.write(text)
            sys.stdout.write("ok %s\n" % it["file"])
        return code
    print_usage()
    return 2


def do_new(args):
    """`brat new NAME [--kind service|tool]`: a project that runs on the first
    try. Exit 2 on bad usage, 1 when the target directory is refused."""
    sc = scaffold_mod()
    rest = [a for a in args if a != "--"]
    name = None
    kind = sc.DEFAULT_KIND
    i = 0
    while i < len(rest):
        a = rest[i]
        if a == "--kind" and i + 1 < len(rest):
            kind = rest[i + 1]
            i += 2
            continue
        if a.startswith("--kind="):
            kind = a.split("=", 1)[1]
            i += 1
            continue
        if a.startswith("-"):
            sys.stderr.write("brat new: unknown option %r\n" % a)
            print_usage()
            return 2
        if name is not None:
            sys.stderr.write("brat new: unexpected argument %r\n" % a)
            print_usage()
            return 2
        name = a
        i += 1
    if name is None:
        sys.stderr.write("brat new: NAME is required\n")
        print_usage()
        return 2
    if kind not in sc.KINDS:
        sys.stderr.write("brat new: unknown kind %r (want %s)\n"
                         % (kind, "|".join(sc.KINDS)))
        print_usage()
        return 2
    try:
        written = sc.write_project(name, kind, os.getcwd())
    except sc.ScaffoldError as e:
        sys.stderr.write("brat new: %s\n" % e)
        return 1
    sys.stdout.write("new %s (%s)\n" % (name, kind))
    for p in written:
        sys.stdout.write("  %s\n" % p)
    sys.stdout.write("\nnext:\n")
    for line in sc.run_hint(name, os.path.join(HERE, "cli.py"), os.getcwd()):
        sys.stdout.write("  %s\n" % line)
    return 0


def _gate_ownership(path):
    """Run the borrow checker before producing a native binary.

    `move` carries no runtime effect in any backend (SPEC.md 3), so the static
    checker is the only thing standing between a mistake and a silent alias.
    `brat run` deliberately does NOT gate, because the self-hosted toolchain
    (`bratb.brat`, `bratp.brat`) is run through it and does not pass its own
    rules yet. `brat build` is the production path, so it does.
    """
    brat = brat_mod()
    try:
        own = own_mod()
    except Exception as e:
        sys.stderr.write("brat build: ownership checker unavailable (%s); "
                         "refusing to build unverified code\n" % e)
        return False
    try:
        own.load_brat = lambda path=None: brat
    except Exception:
        sys.stderr.write("brat build: cannot bind checker to interpreter; "
                         "refusing to build unverified code\n")
        return False
    rc = own.main(["check", path])
    return rc == 0


def do_build(args):
    rest = [a for a in args if a != "--"]
    gate = "--no-check" not in rest
    rest = [a for a in rest if a != "--no-check"]
    out = None
    files = []
    i = 0
    while i < len(rest):
        if rest[i] == "-o" and i + 1 < len(rest):
            out = rest[i + 1]
            i += 2
            continue
        files.append(rest[i])
        i += 1
    if len(files) != 1:
        print_usage()
        return 2
    src = files[0]
    if out is None:
        out = os.path.splitext(src)[0] + ".exe"
    if gate and not _gate_ownership(src):
        sys.stderr.write(
            "brat build: refusing to build %s: the ownership checker reported "
            "errors above. `move` has no runtime effect (SPEC.md 3), so this is\n"
            "the only gate before a native binary. Fix it, or run with "
            "--no-check to override deliberately.\n" % src)
        return 1
    try:
        codegen = codegen_c_mod()
    except ImportError as e:
        sys.stderr.write("brat build: backend unavailable: %s\n" % e)
        return 1
    fd, cfile = tempfile.mkstemp(prefix="brat-build-", suffix=".c")
    os.close(fd)
    try:
        with open(cfile, "w", encoding="utf-8") as f:
            f.write(codegen.emit_file(os.path.abspath(src)))
    except Exception as e:
        if parse_error_line(e) is not None:
            return syntax_error(src, _read_src(src), e)
        sys.stderr.write("brat build: emit %s: %s\n" % (type(e).__name__, e))
        return 1
    r = subprocess.run([sys.executable, "-m", "ziglang", "cc", "-O2", "-I", HERE, cfile,
                        "-o", out], capture_output=True, text=True, timeout=300)
    try:
        os.unlink(cfile)
    except OSError:
        pass
    if r.returncode != 0:
        sys.stderr.write("brat build: cc failed:\n%s\n" % ((r.stdout + r.stderr)[-2000:]))
        return 1
    sys.stdout.write("build ok %s\n" % out)
    return 0


def main(argv=None):
    argv = sys.argv if argv is None else argv
    for _stream in (sys.stdout, sys.stderr):
        try:
            _stream.reconfigure(encoding='utf-8', errors='replace')
        except (AttributeError, ValueError):
            pass
    if len(argv) < 2:
        print_usage()
        return 2
    cmd = argv[1]
    rest = argv[2:]
    if cmd == "run":
        return do_run(rest)
    if cmd == "check":
        return do_check(rest)
    if cmd == "fmt":
        return do_fmt(rest)
    if cmd == "emit-c":
        return do_emit_c(rest)
    if cmd == "test":
        return do_test(rest)
    if cmd == "build":
        return do_build(rest)
    if cmd == "pkg":
        return do_pkg(rest)
    if cmd == "new":
        return do_new(rest)
    sys.stderr.write("brat: unknown command %r\n" % cmd)
    print_usage()
    return 2

if __name__ == "__main__":
    sys.exit(main())
