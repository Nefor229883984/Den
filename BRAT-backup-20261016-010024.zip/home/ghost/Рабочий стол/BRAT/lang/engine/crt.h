#ifndef BRAT_RT_H
#define BRAT_RT_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <setjmp.h>
#include <time.h>
#include <math.h>
#include <errno.h>
#if defined(_MSC_VER)
#define BTLS __declspec(thread)
#else
#define BTLS _Thread_local
#endif
#if defined(_WIN32)
#include <winsock2.h>
#include <ws2tcpip.h>
#else
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif
#if defined(BRAT_RT_SHARED)
#define BFN
#else
#define BFN static
#endif


#include <stdint.h>
typedef int64_t bint;
#define BINT_MIN INT64_MIN

#define BINT_FMT "%lld"


typedef enum { V_NIL, V_BOOL, V_INT, V_FLOAT, V_STR, V_VEC, V_STRUCT, V_TAG } VTag;
typedef struct Val Val;
typedef struct Vec Vec;
typedef struct Map Map;
struct Vec { Val *items; long len, cap; };
/* keys/vals keep INSERTION ORDER (the interpreter's dict does, and byte parity between the two backends depends on it); idx is the hash index: open addressing, slot holds pos+1 in keys/vals, 0 = empty, -1 = tombstone left by a delete. Lookup was a linear scan of keys -- O(n) per get made a 20k-key map take 22s; with the index the same work is milliseconds. */

struct Map { Val *keys; Val *vals; long len, cap; const char *type;
             long *idx; long idx_cap; long idx_used; };
struct Val { VTag tag; union { bint b; bint ival; double fval; char *str; Vec *vec; Map *map; struct { char *tag; Vec *args; } tv; } as; };
BFN void vraise(const char *msg);
BFN void vraisef(const char *fmt, const char *arg);
BFN long utf8_cplen(const char *s);
BFN void vjprint(Val v);

BFN long veq(Val a, Val b);

BFN Val vrepeat_n(Val s, bint k);
#ifdef BRAT_RT_SHARED
BTLS jmp_buf *volatile vjmp;
BTLS Val vunwind;
#endif

/* realloc that never yields NULL into a slot the caller keeps writing: a failed realloc leaves the old block allocated, so the check has to happen before the pointer is overwritten, otherwise the block leaks and every later access goes through NULL. */

BFN void *bgrow(void *p, size_t n) {
    void *q = realloc(p, n);
    if (!q) { vraise("out of memory"); }
    return q;
}

BFN long vput(char *o, const char *s) {
    long n = 0;
    while (s[n]) { o[n] = s[n]; n++; }
    return n;
}

BFN Val vnil(void) { Val v; v.tag = V_NIL; return v; }
BFN Val vbool(long b) { Val v; v.tag = V_BOOL; v.as.b = b ? 1 : 0; return v; }
BFN Val vint(bint n) { Val v; v.tag = V_INT; v.as.ival = n; return v; }
BFN Val vfloat(double n) { Val v; v.tag = V_FLOAT; v.as.fval = n; return v; }

BFN Val vlit(const char *s) { Val v; v.tag = V_STR; v.as.str = (char *)s; return v; }

static void vfatal_oom(void) {
    fputs("brat: out of memory\n", stderr);
    abort();
}
BFN Val vstrn(const char *s, long n) { Val v; v.tag = V_STR; v.as.str = (char *)malloc(n + 1); if (!v.as.str) vfatal_oom(); memcpy(v.as.str, s, n); v.as.str[n] = 0; return v; }
BFN Vec *vvec(void) {
    Vec *v = (Vec *)malloc(sizeof(Vec));
    if (!v) vfatal_oom();
    v->len = 0; v->cap = 4;
    v->items = (Val *)malloc(sizeof(Val) * 4);
    if (!v->items) { free(v); vfatal_oom(); }
    return v;
}
BFN Val vstr(const char *s) { Val v; v.tag = V_STR; v.as.str = strdup(s); if (!v.as.str) vfatal_oom(); return v; }
BFN Val vvecv(Vec *v) { Val r; r.tag = V_VEC; r.as.vec = v; return r; }
BFN Map *vmap(const char *type) {
    Map *m = (Map *)malloc(sizeof(Map));
    if (!m) vfatal_oom();
    m->len = 0; m->cap = 4;
    m->keys = (Val *)malloc(sizeof(Val) * 4);
    m->vals = (Val *)malloc(sizeof(Val) * 4);
    m->idx = (long *)calloc((size_t)8, sizeof(long));
    if (!m->keys || !m->vals || !m->idx) { free(m->keys); free(m->vals); free(m->idx); free(m); vfatal_oom(); }
    m->type = type;
    m->idx_cap = 8; m->idx_used = 0;
    return m;
}

BFN unsigned long vkey_hash(Val k) {
    unsigned long h = 1469598103934665603UL;
    switch (k.tag) {
    case V_STR: {
        const unsigned char *p = (const unsigned char *)k.as.str;
        while (*p) { h ^= *p++; h *= 1099511628211UL; }
        return h;
    }
    case V_INT:
        h ^= (unsigned long)k.as.ival; h *= 1099511628211UL;
        h ^= h >> 29; return h;
    case V_FLOAT: {
        double d = k.as.fval == 0.0 ? 0.0 : k.as.fval;
        unsigned long bits;
        memcpy(&bits, &d, sizeof bits);
        h ^= bits; h *= 1099511628211UL; h ^= h >> 29; return h;
    }
    case V_BOOL:
        h ^= (unsigned long)(k.as.b ? 1 : 0); h *= 1099511628211UL; return h;
    case V_NIL:
        h ^= 0x9e3779b97f4a7c15UL; return h;
    case V_TAG: {
        const unsigned char *p = (const unsigned char *)k.as.tv.tag;
        while (*p) { h ^= *p++; h *= 1099511628211UL; }
        h ^= (unsigned long)k.as.tv.args->len; h *= 1099511628211UL;
        h ^= h >> 29; return h;
    }
    default:
        h ^= (unsigned long)k.tag; h *= 1099511628211UL; return h;
    }
}

BFN void map_idx_rebuild(Map *m) {
    long want = m->idx_cap;
    while (want < 8 || (m->len + 1) * 4 >= want * 3) want *= 2;
    if (want != m->idx_cap || m->idx == 0) {
        long *ni = (long *)calloc((size_t)want, sizeof(long));
        if (!ni) { vraise("out of memory"); }
        free(m->idx);
        m->idx = ni; m->idx_cap = want;
    } else {
        for (long i = 0; i < m->idx_cap; i++) m->idx[i] = 0;
    }
    m->idx_used = 0;
    for (long i = 0; i < m->len; i++) {
        unsigned long h = vkey_hash(m->keys[i]);
        long mask = m->idx_cap - 1;
        long slot = (long)(h & (unsigned long)mask);
        while (m->idx[slot]) slot = (slot + 1) & mask;
        m->idx[slot] = i + 1;
        m->idx_used++;
    }
}

BFN long map_find(Map *m, Val k) {
    if (!m->idx || m->idx_cap == 0) map_idx_rebuild(m);
    long mask = m->idx_cap - 1;
    long slot = (long)(vkey_hash(k) & (unsigned long)mask);
    long first_tomb = -1;
    for (long probes = 0; probes < m->idx_cap; probes++) {
        long e = m->idx[slot];
        if (e == 0) return -1;
        if (e == -1) { if (first_tomb < 0) first_tomb = slot; }
        else if (veq(m->keys[e - 1], k)) return e - 1;
        slot = (slot + 1) & mask;
    }
    return -1;
}
BFN void map_idx_put(Map *m, long pos) {
    if (!m->idx) map_idx_rebuild(m);
    if (m->idx_used * 4 >= m->idx_cap * 3) map_idx_rebuild(m);
    long mask = m->idx_cap - 1;
    long slot = (long)(vkey_hash(m->keys[pos]) & (unsigned long)mask);
    while (m->idx[slot] && m->idx[slot] != -1) slot = (slot + 1) & mask;
    m->idx[slot] = pos + 1;
    m->idx_used++;
}
BFN Val vstruct(Map *m) { Val r; r.tag = V_STRUCT; r.as.map = m; return r; }

BFN Val vtagv_lit(const char *tag, Vec *args) { Val r; r.tag = V_TAG; r.as.tv.tag = (char *)tag; r.as.tv.args = args; return r; }
BFN Val vtagv(const char *tag, Vec *args) {
    Val r; r.tag = V_TAG;
    r.as.tv.tag = strdup(tag);
    if (!r.as.tv.tag) vfatal_oom();
    r.as.tv.args = args;
    return r;
}

BFN void vec_push(Vec *v, Val x) {
    if (v->len >= v->cap) { v->cap *= 2; v->items = (Val *)bgrow(v->items, sizeof(Val) * (size_t)v->cap); }
    v->items[v->len++] = x;
}
BFN void vec_push_all(Vec *dst, Vec *src) {
    for (long i = 0; i < src->len; i++) vec_push(dst, src->items[i]);
}
BFN void map_set_v(Map *m, Val k, Val v) {
    if (k.tag == V_VEC || k.tag == V_STRUCT) { vraise("bad map key"); }
    long at = map_find(m, k);
    if (at >= 0) { m->vals[at] = v; return; }
    if (m->len >= m->cap) { m->cap *= 2; m->keys = (Val *)bgrow(m->keys, sizeof(Val) * (size_t)m->cap); m->vals = (Val *)bgrow(m->vals, sizeof(Val) * (size_t)m->cap); }
    m->keys[m->len] = k; m->vals[m->len] = v; m->len++;
    map_idx_put(m, m->len - 1);
}

BFN void map_set(Map *m, const char *k, Val v) {
    Val key; key.tag = V_STR; key.as.str = (char *)k;
    map_set_v(m, key, v);
}
BFN Val *map_get_v(Map *m, Val k) {
    long at = map_find(m, k);
    return at >= 0 ? &m->vals[at] : 0;
}
BFN Val *map_get(Map *m, const char *k) {
    Val key; key.tag = V_STR; key.as.str = (char *)k;
    return map_get_v(m, key);
}
BFN long map_del_v(Map *m, Val k) {
    long at = map_find(m, k);
    if (at < 0) return 0;
    memmove(m->keys + at, m->keys + at + 1, sizeof(Val) * (size_t)(m->len - at - 1));
    memmove(m->vals + at, m->vals + at + 1, sizeof(Val) * (size_t)(m->len - at - 1));
    m->len--;
    
    map_idx_rebuild(m);
    return 1;
}

BFN char *vkey(Val k) {
    if (k.tag == V_STR) return strdup(k.as.str);
    if (k.tag == V_INT) { char b[32]; snprintf(b, sizeof b, BINT_FMT, (bint)k.as.ival); return strdup(b); }
    if (k.tag == V_FLOAT) { char b[64]; snprintf(b, sizeof b, "%.17g", k.as.fval); return strdup(b); }
    if (k.tag == V_BOOL) return strdup(k.as.b ? "true" : "false");
    vraise("bad map key");
}
BFN Val vmap_getv(Val m, Val k) {
    if (m.tag != V_STRUCT) { vraise("get of non-map"); }
    Val *o = map_get_v(m.as.map, k);
    return o ? *o : vnil();
}
BFN Val vmap_has(Val m, Val k) {
    if (m.tag != V_STRUCT) { vraise("has of non-map"); }
    Val *o = map_get_v(m.as.map, k);
    return vbool(o != 0);
}
BFN Val vmap_keys(Val m) {
    if (m.tag != V_STRUCT) { vraise("keys of non-map"); }
    Vec *o = vvec();
    for (long i = 0; i < m.as.map->len; i++) vec_push(o, m.as.map->keys[i]);
    return vvecv(o);
}
BFN Val vmap_del(Val m, Val k) {
    if (m.tag != V_STRUCT) { vraise("del of non-map"); }
    return vbool(map_del_v(m.as.map, k));
}

BFN bint vmapkey_reserved(Val k) {
    return k.tag == V_STR && k.as.str && strcmp(k.as.str, "$type") == 0;
}
BFN Val vmapkey_err(void) {
    Vec *e = vvec();
    vec_push(e, vstr("map key \"$type\" is reserved"));
    return vtagv("err", e);
}
BFN bint vmap_has_reserved(Map *m) {
    Val k; k.tag = V_STR; k.as.str = (char *)"$type";
    return map_find(m, k) >= 0;
}

BFN Val vmap_setv(Val m, Val k, Val v) {
    if (m.tag != V_STRUCT) { vraise("set of non-map"); }
    if (vmapkey_reserved(k)) { return vmapkey_err(); }
    map_set_v(m.as.map, k, v);
    return v;
}
BFN bint vlong(Val v);
BFN Val vset_at(Val m, Val k, Val v) {
    
    if (m.tag == V_STRUCT) {
        if (m.as.map->type[0]) { char *kk = vkey(k); vraisef("no field %s\n", kk); }
        if (vmapkey_reserved(k)) { return vmapkey_err(); }
        map_set_v(m.as.map, k, v);
        return v;
    }
    if (m.tag == V_VEC) {
        long i = vlong(k);
        if (i < 0 || i >= m.as.vec->len) { vraise("index out of range"); }
        m.as.vec->items[i] = v;
        return v;
    }
    vraise("setidx of non-indexable");
}
BFN Vec *viter_vec(Val v) {
    if (v.tag == V_VEC) return v.as.vec;
    if (v.tag == V_STRUCT) {
        Vec *o = vvec();
        for (long i = 0; i < v.as.map->len; i++) vec_push(o, v.as.map->keys[i]);
        return o;
    }
    vraise("not iterable");
}

BFN double vnum(Val v) {
    if (v.tag == V_INT) return (double)v.as.ival;
    if (v.tag == V_FLOAT) return v.as.fval;
    if (v.tag == V_BOOL) return (double)v.as.b;
    return 0;
}
BFN int vis_true(Val v) {
    switch (v.tag) {
    case V_NIL: return 0;
    case V_BOOL: return v.as.b;
    case V_INT: return v.as.ival != 0;
    case V_FLOAT: return v.as.fval != 0;
    case V_STR: return v.as.str[0] != 0;
    case V_VEC: return v.as.vec->len != 0;
    default: return 1;
    }
}


BFN const char *vfmt_double(double x) {
    static BTLS char buf[8][48];
    static BTLS long k = 0;
    char *b = buf[k++ & 7];
    int p;
    
    for (p = 1; p <= 17; p++) {
        snprintf(b, 48, "%.*g", p, x);
        if (strtod(b, NULL) == x) break;
    }
    
    if (strchr(b, 'e') && fabs(x) != 0.0 && fabs(x) >= 1e-4 && fabs(x) < 1e16) {
        for (p = 0; p <= 17; p++) {
            snprintf(b, 48, "%.*f", p, x);
            if (strtod(b, NULL) == x) break;
        }
    }
    if (!strpbrk(b, ".eEnN")) { strcat(b, ".0"); }
    return b;
}


BFN long vrepr_slen(const char *s) {
    long n = 0;
    for (const char *p = s; *p; p++) {
        if (*p == '\'' || *p == '\\' || *p == '\n' || *p == '\r' || *p == '\t') n += 2;
        else n += 1;
    }
    return n;
}

BFN void vprint_f(Val v, long q, FILE *f) {
    long i;
    switch (v.tag) {
    case V_NIL: fprintf(f, "None"); break;
    case V_BOOL: fprintf(f, v.as.b ? "True" : "False"); break;
    case V_INT: fprintf(f, BINT_FMT, (bint)v.as.ival); break;
    case V_FLOAT: fprintf(f, "%s", vfmt_double(v.as.fval)); break;
    case V_STR:
        if (!q) { fprintf(f, "%s", v.as.str); break; }
        fprintf(f, "'");
        for (const char *p = v.as.str; *p; p++) {
            if (*p == '\'' || *p == '\\') { fputc('\\', f); fputc(*p, f); }
            else if (*p == '\n') fprintf(f, "\\n");
            else if (*p == '\r') fprintf(f, "\\r");
            else if (*p == '\t') fprintf(f, "\\t");
            else fputc((unsigned char)*p, f);
        }
        fprintf(f, "'");
        break;
    case V_VEC:
        fprintf(f, "[");
        for (i = 0; i < v.as.vec->len; i++) { if (i) fprintf(f, ", "); vprint_f(v.as.vec->items[i], 1, f); }
        fprintf(f, "]");
        break;
    case V_STRUCT: {
        int ismap = !v.as.map->type[0];
        fprintf(f, "{");
        if (!ismap) fprintf(f, "'$type': '%s'", v.as.map->type);
        for (i = 0; i < v.as.map->len; i++) {
            if (i || !ismap) fprintf(f, ", ");
            vprint_f(v.as.map->keys[i], 1, f);
            fprintf(f, ": ");
            vprint_f(v.as.map->vals[i], 1, f);
        }
        fprintf(f, "}");
        break;
    }
    case V_TAG:
        fprintf(f, "('%s'", v.as.tv.tag);
        for (i = 0; i < v.as.tv.args->len; i++) { fprintf(f, ", "); vprint_f(v.as.tv.args->items[i], 1, f); }
        
        if (v.as.tv.args->len == 0) fprintf(f, ",");
        fprintf(f, ")");
        break;
    }
}

BFN void vprint(Val v) { vprint_f(v, 0, stdout); }

BFN long veq(Val a, Val b) {
    long i;
    if ((a.tag == V_INT || a.tag == V_FLOAT || a.tag == V_BOOL) &&
        (b.tag == V_INT || b.tag == V_FLOAT || b.tag == V_BOOL)) return vnum(a) == vnum(b);
    if (a.tag != b.tag) return 0;
    switch (a.tag) {
    case V_NIL: return 1;
    case V_STR: return !strcmp(a.as.str, b.as.str);
    case V_VEC:
        if (a.as.vec->len != b.as.vec->len) return 0;
        for (i = 0; i < a.as.vec->len; i++) if (!veq(a.as.vec->items[i], b.as.vec->items[i])) return 0;
        return 1;
    case V_STRUCT: {
        if (strcmp(a.as.map->type, b.as.map->type)) return 0;
        if (a.as.map->len != b.as.map->len) return 0;
        for (i = 0; i < a.as.map->len; i++) {
            Val *o = map_get_v(b.as.map, a.as.map->keys[i]);
            if (!o || !veq(a.as.map->vals[i], *o)) return 0;
        }
        return 1;
    }
    case V_TAG:
        if (strcmp(a.as.tv.tag, b.as.tv.tag)) return 0;
        if (a.as.tv.args->len != b.as.tv.args->len) return 0;
        for (i = 0; i < a.as.tv.args->len; i++) if (!veq(a.as.tv.args->items[i], b.as.tv.args->items[i])) return 0;
        return 1;
    default: return 0;
    }
}


BFN int vcmp(Val a, Val b) {
    if (a.tag == V_STR && b.tag == V_STR) {
        int r = strcmp(a.as.str, b.as.str);
        return r < 0 ? -1 : r > 0 ? 1 : 0;
    }
    if ((a.tag == V_INT || a.tag == V_FLOAT || a.tag == V_BOOL) &&
        (b.tag == V_INT || b.tag == V_FLOAT || b.tag == V_BOOL)) {
        double x = vnum(a), y = vnum(b);
        return x < y ? -1 : x > y ? 1 : 0;
    }
    if (a.tag == V_NIL || b.tag == V_NIL) {
        if (a.tag == b.tag) return 0;
        return a.tag == V_NIL ? -1 : 1;
    }
    if (a.tag != b.tag) return a.tag < b.tag ? -1 : 1;
    if (a.tag == V_VEC) {
        Vec *x = a.as.vec, *y = b.as.vec;
        long nn = x->len < y->len ? x->len : y->len;
        for (long i = 0; i < nn; i++) {
            int c = vcmp(x->items[i], y->items[i]);
            if (c) return c;
        }
        return x->len < y->len ? -1 : x->len > y->len ? 1 : 0;
    }
    if (a.tag == V_TAG) {
        int c = strcmp(a.as.tv.tag, b.as.tv.tag);
        if (c) return c < 0 ? -1 : 1;
        Vec *x = a.as.tv.args, *y = b.as.tv.args;
        long nn = x->len < y->len ? x->len : y->len;
        for (long i = 0; i < nn; i++) {
            c = vcmp(x->items[i], y->items[i]);
            if (c) return c;
        }
        return x->len < y->len ? -1 : x->len > y->len ? 1 : 0;
    }
    if (a.tag == V_STRUCT) {
        int c = strcmp(a.as.map->type, b.as.map->type);
        if (c) return c < 0 ? -1 : 1;
        long nn = a.as.map->len < b.as.map->len ? a.as.map->len : b.as.map->len;
        for (long i = 0; i < nn; i++) {
            c = vcmp(a.as.map->keys[i], b.as.map->keys[i]);
            if (c) return c;
            c = vcmp(a.as.map->vals[i], b.as.map->vals[i]);
            if (c) return c;
        }
        return a.as.map->len < b.as.map->len ? -1 : a.as.map->len > b.as.map->len ? 1 : 0;
    }
    return 0;
}
BFN int vcontains(Val c, Val x) {
    long i;
    if (c.tag == V_VEC) {
        for (i = 0; i < c.as.vec->len; i++) if (veq(c.as.vec->items[i], x)) return 1;
        return 0;
    }
    if (c.tag == V_STR && x.tag == V_STR) return strstr(c.as.str, x.as.str) != 0;
    if (c.tag == V_STRUCT) {
        Val *o = map_get_v(c.as.map, x);
        return o != 0;
    }
    vraise("in of non-container");
}

BFN long vsprint_len_q(Val v, long q);
BFN long vsprint_q(Val v, char *o, long q);



BFN Val vnum0(Val v) {
    if (v.tag == V_BOOL) return vint(v.as.b ? 1 : 0);
    return v;
}

#define VTXT_SLOTS 8
static char vtxt_buf[VTXT_SLOTS][512];
static long vtxt_next = 0;

BFN const char *vtxt(Val v) {
    char *b = vtxt_buf[vtxt_next++ % VTXT_SLOTS];
    if (v.tag == V_STR) { snprintf(b, 512, "%s", v.as.str); return b; }
    if (v.tag == V_INT) { snprintf(b, 512, BINT_FMT, (bint)v.as.ival); return b; }
    if (v.tag == V_FLOAT) { snprintf(b, 512, "%s", vfmt_double(v.as.fval)); return b; }
    long nn = vsprint_len_q(v, 0);
    if (nn < 511) {
        vsprint_q(v, b, 0);
        b[nn] = 0;
        return b;
    }
    
    char *heap = (char *)malloc((size_t)nn + 1);
    if (!heap) vfatal_oom();
    vsprint_q(v, heap, 0);
    heap[nn] = 0;
    static char *keep[VTXT_SLOTS];
    long k = vtxt_next % VTXT_SLOTS;
    free(keep[k]);
    keep[k] = heap;
    return heap;
}

BFN Val vadd(Val a, Val b) {
    if (a.tag == V_STR || b.tag == V_STR) {
        const char *sa = (a.tag == V_STR) ? a.as.str : vtxt(a);
        const char *sb = (b.tag == V_STR) ? b.as.str : vtxt(b);
        size_t la = strlen(sa), lb = strlen(sb);
        
        char *out = (char *)malloc(la + lb + 1);
        if (!out) { vraise("out of memory"); }
        Val r; r.tag = V_STR;
        r.as.str = out;
        memcpy(out, sa, la);
        memcpy(out + la, sb, lb);
        out[la + lb] = 0;
        return r;
    }
    a = vnum0(a); b = vnum0(b);
    if (a.tag == V_INT && b.tag == V_INT) {
        /* wrap, not UB: signed overflow is undefined in C and the interpreter wraps (SPEC section 10) */

        return vint((bint)((unsigned long long)a.as.ival + (unsigned long long)b.as.ival));
    }
    if ((a.tag == V_INT || a.tag == V_FLOAT) && (b.tag == V_INT || b.tag == V_FLOAT))
        return vfloat(vnum(a) + vnum(b));
    
    if (a.tag == V_VEC && b.tag == V_VEC) {
        Vec *o = vvec();
        vec_push_all(o, a.as.vec);
        vec_push_all(o, b.as.vec);
        return vvecv(o);
    }
    vraise("type error in +");
}
BFN Val vsub(Val a, Val b) {
    a = vnum0(a); b = vnum0(b);
    if (a.tag == V_INT && b.tag == V_INT)
        return vint((bint)((unsigned long long)a.as.ival - (unsigned long long)b.as.ival));
    if ((a.tag == V_INT || a.tag == V_FLOAT || a.tag == V_BOOL)
            && (b.tag == V_INT || b.tag == V_FLOAT || b.tag == V_BOOL))
        return vfloat(vnum(a) - vnum(b));
    vraise("type error in -");
}
BFN Val vmul(Val a, Val b) {
    a = vnum0(a); b = vnum0(b);
    if (a.tag == V_INT && b.tag == V_INT)
        return vint((bint)((unsigned long long)a.as.ival * (unsigned long long)b.as.ival));
    if ((a.tag == V_INT || a.tag == V_FLOAT) && (b.tag == V_INT || b.tag == V_FLOAT))
        return vfloat(vnum(a) * vnum(b));
    
    if (a.tag == V_STR && b.tag == V_INT) return vrepeat_n(a, b.as.ival);
    if (a.tag == V_INT && b.tag == V_STR) return vrepeat_n(b, a.as.ival);
    vraise("type error in *");
}
BFN Val vdiv(Val a, Val b) {
    a = vnum0(a); b = vnum0(b);
    if (a.tag == V_INT && b.tag == V_INT) {
        if (b.as.ival == 0) { vraise("div by zero"); }
        
        bint x = a.as.ival, y = b.as.ival;
        if (x == BINT_MIN && y == -1) { return vint(BINT_MIN); }
        bint q = x / y;
        if ((x % y) != 0 && ((x < 0) != (y < 0))) { q--; }
        return vint(q);
    }
    if ((a.tag == V_INT || a.tag == V_FLOAT) && (b.tag == V_INT || b.tag == V_FLOAT)) {
        double y = vnum(b);
        if (y == 0) { vraise("div by zero"); }
        return vfloat(vnum(a) / y);
    }
    vraise("type error in /");
}
BFN Val vmod(Val a, Val b) {
    a = vnum0(a); b = vnum0(b);
    if (a.tag == V_INT && b.tag == V_INT) {
        if (b.as.ival == 0) { vraise("div by zero"); }
        
        bint x = a.as.ival, y = b.as.ival;
        if (x == BINT_MIN && y == -1) { return vint(0); }
        bint r = x % y;
        if (r != 0 && ((r < 0) != (y < 0))) { r += y; }
        return vint(r);
    }
    
    if ((a.tag == V_INT || a.tag == V_FLOAT) && (b.tag == V_INT || b.tag == V_FLOAT)) {
        double x = vnum(a), y = vnum(b);
        if (y == 0) { vraise("div by zero"); }
        double r = fmod(x, y);
        if (r != 0 && ((r < 0) != (y < 0))) { r += y; }
        return vfloat(r);
    }
    vraise("type error in %%");
}
BFN Val vneg(Val a) {
    if (a.tag == V_INT) {
        if (a.as.ival == BINT_MIN) { return vint(BINT_MIN); }
        return vint((bint)(0ULL - (unsigned long long)a.as.ival));
    }
    if (a.tag == V_FLOAT) return vfloat(-a.as.fval);
    if (a.tag == V_BOOL) return vint(a.as.b ? -1 : 0);
    vraise("type error in unary -");
}
BFN Val vlen(Val a) {
    if (a.tag == V_STR) {
        long n = 0;
        for (const char *q = a.as.str; *q; q += utf8_cplen(q)) n++;
        return vint(n);
    }
    if (a.tag == V_VEC) return vint(a.as.vec->len);
    if (a.tag == V_STRUCT) return vint(a.as.map->len);
    vraise("len of non-sized");
}
BFN long utf8_cplen(const char *s) {
    unsigned char c = (unsigned char)*s;
    long need = 1;
    if (c < 0x80) return 1;
    if ((c & 0xE0) == 0xC0) need = 2;
    else if ((c & 0xF0) == 0xE0) need = 3;
    else if ((c & 0xF8) == 0xF0) need = 4;
    
    long have = 1;
    while (have < need && s[have]) have++;
    return have;
}
BFN const char *utf8_at(const char *s, long idx) {
    const char *p = s;
    while (idx > 0 && *p) {
        p += utf8_cplen(p);
        idx--;
    }
    return p;
}
BFN Val vat(Val a, Val i) {
    if (a.tag == V_STRUCT) {
        Val *o = map_get_v(a.as.map, i);
        if (!o) { vraise("no key"); }
        return *o;
    }
    bint k = (i.tag == V_INT || i.tag == V_FLOAT) ? (bint)vnum(i) : 0;
    if (i.tag != V_INT && i.tag != V_FLOAT) { vraise("index must be int"); }
    if (a.tag == V_STR) {
        const char *p = a.as.str;
        long n = 0;
        for (const char *q = p; *q; q += utf8_cplen(q)) n++;
        if (k < 0 || k >= n) { vraise("index out of range"); }
        const char *at = utf8_at(p, k);
        return vstrn(at, utf8_cplen(at));
    }
    if (a.tag == V_VEC) {
        if (k < 0 || k >= a.as.vec->len) { vraise("index out of range"); }
        return a.as.vec->items[k];
    }
    if (a.tag == V_TAG) {
        if (k < 1 || k > a.as.tv.args->len) { vraise("index out of range"); }
        return a.as.tv.args->items[k - 1];
    }
    vraise("index of non-indexable");
}

#ifndef BRAT_RT_SHARED
static BTLS jmp_buf *volatile vjmp;
static BTLS Val vunwind;
#endif


static BTLS Vec _vraise_slot;
static BTLS Val _vraise_item[1];
static BTLS char _vraise_msg[256];
static BTLS jmp_buf _vdead_slot;

/* Called by the top-level handler before it reports. A raise that happens while an error is already being reported must not unwind back into that handler: the emitter used to point vjmp at the handler's own setjmp, so such a raise longjmp'd straight back, raised again, and looped forever -- measured at 15M iterations in 20 s, writing its diagnostic to stderr without end, which filled a tmpfs to 100% and took the machine down. */

BFN void vunwind_disarm(void) { vjmp = &_vdead_slot; }
/* Every raise site goes through here. Jumping into a jmp_buf that was never
   setjmp'd is a wild address, and with unwinding disarmed that is exactly where
   four of the five sites would have landed while the top-level handler was
   already reporting. */
BFN void vunwind_do(void) {
    if (vjmp == &_vdead_slot) {
        fputs("brat: unwinding disarmed, refusing to jump to a frame that never setjmp'd\n", stderr);
        abort();
    }
    longjmp(*vjmp, 1);
    abort();
}

BFN void vraise(const char *msg) {
    if (!_vraise_slot.items) {
        _vraise_slot.items = _vraise_item;
        _vraise_slot.cap = 1;
    }
    _vraise_slot.len = 0;
    
    size_t i = 0;
    while (msg[i] && i + 1 < sizeof _vraise_msg) { _vraise_msg[i] = msg[i]; i++; }
    _vraise_msg[i] = 0;
    if (vjmp == &_vdead_slot) {
        fputs("brat: out of memory while reporting an error\n", stderr);
        abort();
    }
    vec_push(&_vraise_slot, vlit(_vraise_msg));
    vunwind = vtagv_lit("err", &_vraise_slot);
    vunwind_do();
}
BFN void vraisef(const char *fmt, const char *arg) {
    char buf[256];
    snprintf(buf, sizeof buf, fmt, arg);
    long n = (long)strlen(buf);
    while (n > 0 && (buf[n - 1] == '\n' || buf[n - 1] == '\r')) buf[--n] = 0;
    vraise(buf);
    abort();
}
BFN void vraisev(Val v) {
    Vec *a = vvec();
    vec_push(a, v);
    vunwind = vtagv("err", a);
    vunwind_do();
    abort();
}
static long vargc_g;
static char **vargv_g;
static char vbase_g[4096];
static int vbase_ready;
BFN void vbase_set(const char *b) {
    if (!b || !*b) return;
    char res[4096];
    const char *rp = realpath(b, res);
    const char *use = rp ? rp : b;
    strncpy(vbase_g, use, sizeof vbase_g - 1);
    vbase_g[sizeof vbase_g - 1] = 0;
    vbase_ready = 1;
}
BFN void vargs_set(long c, char **v) {
    vargc_g = c;
    vargv_g = v;
    
    if (!vbase_ready) {
        char tmp[4096];
        const char *src = (c > 0 && v && v[0]) ? v[0] : ".";
        const char *slash = NULL;
        for (const char *q = src; *q; q++) if (*q == '/') slash = q;
        if (slash) {
            size_t n = (size_t)(slash - src);
            if (n == 0) n = 1;
            if (n >= sizeof tmp) n = sizeof tmp - 1;
            memcpy(tmp, src, n);
            tmp[n] = 0;
        } else {
            tmp[0] = '.'; tmp[1] = 0;
        }
        char res[4096];
        const char *rp = realpath(tmp, res);
        if (rp) { strncpy(vbase_g, rp, sizeof vbase_g - 1); vbase_g[sizeof vbase_g - 1] = 0; }
        else { strncpy(vbase_g, tmp, sizeof vbase_g - 1); vbase_g[sizeof vbase_g - 1] = 0; }
        vbase_ready = 1;
    }
}

BFN void vnorm(char *s) {
    int abs = (*s == '/');
    char *comps[256];
    int n = 0;
    char *cur = s;
    while (*cur) {
        while (*cur == '/') cur++;
        char *seg = cur;
        while (*cur && *cur != '/') cur++;
        size_t len = (size_t)(cur - seg);
        if (len == 0) continue;
        if (len == 1 && seg[0] == '.') continue;
        if (len == 2 && seg[0] == '.' && seg[1] == '.') {
            if (n > 0) n--;
            continue;
        }
        if (n < (int)(sizeof comps / sizeof *comps)) comps[n++] = seg;
    }
    char *o = s;
    if (abs) *o++ = '/';
    for (int i = 0; i < n; i++) {
        if (i) *o++ = '/';
        char *c = comps[i];
        while (*c && *c != '/') *o++ = *c++;
    }
    *o = 0;
}

/* Confine `p` to the program directory (vbase_g). Returns NULL if the path
   escapes. Callers must still re-verify the opened fd (see _vfd_confined)
   because realpath() and fopen() are not atomic — a symlink swap between
   them is a classic TOCTOU path-traversal. */
BFN const char *vconfine(const char *p) {
    const char *free_env = getenv("BRAT_FILES");
    if (free_env && *free_env) return p;
    if (!p) return NULL;
    if (!vbase_ready || !vbase_g[0]) return NULL; /* base must be set first */

    static BTLS char res[8192];
    size_t bl = strlen(vbase_g);
    if (p[0] == '/') snprintf(res, sizeof res, "%s", p);
    else snprintf(res, sizeof res, "%s/%s", vbase_g, p);

    char real[8192];
    if (realpath(res, real)) snprintf(res, sizeof res, "%s", real);
    else vnorm(res);
    if (strncmp(res, vbase_g, bl) == 0 && (res[bl] == '/' || res[bl] == 0)) return res;
    return NULL;
}

/* Verify that the open fd `fd` still resolves inside vbase_g.
   Used after fopen() to close the realpath→fopen TOCTOU window. */
static int _vfd_confined(int fd) {
#if defined(__linux__)
    char link[8192];
    ssize_t n = readlink("/proc/self/fd/", link, sizeof link - 1);
    /* readlink on the fd directory itself is meaningless; build the fd path */
    (void)link;
    snprintf(link, sizeof link, "/proc/self/fd/%d", fd);
    n = readlink(link, link, sizeof link - 1); /* reuse buffer: link now holds fd path */
    if (n < 0) return 0;
    link[n] = 0;
    size_t bl = strlen(vbase_g);
    return strncmp(link, vbase_g, bl) == 0 && (link[bl] == '/' || link[bl] == 0);
#else
    (void)fd;
    return 1; /* non-Linux: no /proc, fall back to vconfine's realpath check */
#endif
}
BFN Val vargs(void) {
    Vec *o = vvec();
    for (long i = 1; i < vargc_g; i++) vec_push(o, vstr(vargv_g[i]));
    return vvecv(o);
}
BFN Val vexit(Val v) {
    exit((int)vlong(v));
}
BFN void veprint(Vec *a) {
    for (long i = 0; i < a->len; i++) {
        if (i) fprintf(stderr, " ");
        vprint_f(a->items[i], 0, stderr);
    }
    fprintf(stderr, "\n");
    fflush(stderr);
}
BFN Val vtime_ms(void) {
#if defined(_WIN32)
    FILETIME ft;
    GetSystemTimeAsFileTime(&ft);
    unsigned long long t = ((unsigned long long)ft.dwHighDateTime << 32) | ft.dwLowDateTime;
    return vint((bint)(t / 10000ULL));
#else
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    
    return vint((bint)((unsigned long long)ts.tv_sec * 1000ULL
                       + (unsigned long long)ts.tv_nsec / 1000000ULL));
#endif
}
BFN Val vsleep_ms(Val v) {
    bint ms = vlong(v);
    if (ms < 0) ms = 0;
#if defined(_WIN32)
    Sleep((DWORD)ms);
#else
    struct timespec ts;
    ts.tv_sec = ms / 1000;
    ts.tv_nsec = (ms % 1000) * 1000000L;
    nanosleep(&ts, NULL);
#endif
    return vint(0);
}
BFN Val venv_get(Val v) {
    if (v.tag != V_STR) return vnil();
    const char *r = getenv(v.as.str);
    return r ? vstr(r) : vnil();
}

typedef struct { char kind; char q; char ch; const char *body; } RTok;

static int rtok_match(RTok *t, char ch) {
    if (t->kind == 'l') return ch == t->ch;
    if (t->kind == 'd') return 1;
    if (t->kind == 's') {
        const char *body = t->body;
        int neg = 0, found = 0;
        if (*body == '^') { neg = 1; body++; }
        while (*body) {
            if (body[1] == '-' && body[2]) {
                if (ch >= body[0] && ch <= body[2]) { found = 1; break; }
                body += 3;
            } else {
                if (*body == ch) { found = 1; break; }
                body++;
            }
        }
        return neg ? !found : found;
    }
    return 0;
}


typedef struct { char op; char q; char ch; const char *body; long x, y; } RInst;
typedef struct { RInst *p; long n, cap; const char *pat; long i, plen; int err; int empty_seq; } RProg;

static long r_emit(RProg *g, char op, long x, long y) {
    if (g->n >= g->cap) {
        g->cap = g->cap ? g->cap * 2 : 64;
        g->p = (RInst *)bgrow(g->p, sizeof(RInst) * (size_t)g->cap);
    }
    RInst *in = &g->p[g->n];
    in->op = op; in->q = 0; in->ch = 0; in->body = NULL; in->x = x; in->y = y;
    return g->n++;
}

static long r_alt(RProg *g);



static long r_atom(RProg *g) {
    long sp = r_emit(g, 's', 0, 0);
    long body = -1;
    if (g->i >= g->plen) { g->err = 1; return -1; }
    char c = g->pat[g->i];
    if (c == '(') {
        g->i++;
        body = r_alt(g);
        if (g->err) return -1;
        if (g->i >= g->plen || g->pat[g->i] != ')') { g->err = 1; return -1; }
        g->i++;
    } else if (c == '[') {
        
        long j = g->i + 1;
        long m = j;
        while (m < g->plen && g->pat[m] != ']') m++;
        char *buf = (char *)malloc((size_t)(m - j + 2));
        if (!buf) vfatal_oom();
        int k = 0;
        if (j < g->plen && g->pat[j] == '^') buf[k++] = g->pat[j++];
        while (j < g->plen && g->pat[j] != ']') buf[k++] = g->pat[j++];
        buf[k] = 0;
        g->i = j + 1;
        body = r_emit(g, 'c', 0, 0);
        g->p[body].q = 's';
        g->p[body].body = buf;
    } else if (c == '.') {
        g->i++;
        body = r_emit(g, 'c', 0, 0);
        g->p[body].q = 'd';
    } else if (c == '^') {
        g->i++;
        body = r_emit(g, 'b', 0, 0);
    } else if (c == '$') {
        g->i++;
        body = r_emit(g, 'e', 0, 0);
    } else if (c == '\\') {
        char e = (g->i + 1 < g->plen) ? g->pat[g->i + 1] : '\\';
        g->i += 2;
        body = r_emit(g, 'c', 0, 0);
        if (e == 'd') { g->p[body].q = 's'; g->p[body].body = "0-9"; }
        else if (e == 'D') { g->p[body].q = 's'; g->p[body].body = "^0-9"; }
        else if (e == 'w') { g->p[body].q = 's'; g->p[body].body = "a-zA-Z0-9_"; }
        else if (e == 'W') { g->p[body].q = 's'; g->p[body].body = "^a-zA-Z0-9_"; }
        else if (e == 's') { g->p[body].q = 's'; g->p[body].body = " \t\n\r"; }
        else if (e == 'S') { g->p[body].q = 's'; g->p[body].body = "^ \t\n\r"; }
        else if (e == 'n') { g->p[body].q = 'l'; g->p[body].ch = '\n'; }
        else if (e == 't') { g->p[body].q = 'l'; g->p[body].ch = '\t'; }
        else if (e == 'r') { g->p[body].q = 'l'; g->p[body].ch = '\r'; }
        else { g->p[body].q = 'l'; g->p[body].ch = e; }
    } else {
        g->i++;
        body = r_emit(g, 'c', 0, 0);
        g->p[body].q = 'l';
        g->p[body].ch = c;
    }
    if (g->err) return -1;
    char q = 0;
    if (g->i < g->plen) {
        char cq = g->pat[g->i];
        if (cq == '*' || cq == '+' || cq == '?') { q = cq; g->i++; }
    }
    if (!q) {
        g->p[sp].op = 'j';
        
        g->p[sp].x = body;
        return sp;
    }
    if (q == '*') {
        long jmp = r_emit(g, 'j', 0, 0);
        g->p[jmp].x = sp;
        g->p[sp].x = body;
        g->p[sp].y = g->n;
        return sp;
    }
    if (q == '+') {
        
        g->p[sp].op = 'j';
        g->p[sp].x = body;
        long sp2 = r_emit(g, 's', 0, 0);
        g->p[sp2].x = body;
        g->p[sp2].y = g->n;
        return sp;
    }
    
    g->p[sp].x = body;
    g->p[sp].y = g->n;
    return sp;
}

static long r_seq(RProg *g) {
    
    long entry = r_emit(g, 'j', 0, 0);
    long first_atom = -1;
    while (g->i < g->plen && !g->err) {
        char c = g->pat[g->i];
        if (c == '|' || c == ')') break;
        long a = r_atom(g);
        if (g->err) return -1;
        if (first_atom < 0) first_atom = a;
    }
    if (g->err) return -1;
    g->p[entry].x = (first_atom < 0) ? entry : first_atom;
    g->empty_seq = (first_atom < 0);
    return entry;
}

static long r_alt(RProg *g) {
    
    long head = r_emit(g, 's', 0, 0);
    long first = r_seq(g);
    if (g->err) return -1;
    if (!(g->i < g->plen && g->pat[g->i] == '|')) {
        g->p[head].op = 'j';
        g->p[head].x = head + 1;
        return head;
    }
    long j1 = r_emit(g, 'j', 0, 0);   
    long sps[64];
    long jmps[64];
    int ns = 0, nj = 0;
    while (g->i < g->plen && g->pat[g->i] == '|') {
        g->i++;
        if (ns >= 63) { g->err = 1; return -1; }
        long sp = r_emit(g, 's', 0, 0);
        sps[ns++] = sp;
        long s0 = r_seq(g);
        if (g->err) return -1;
        long j = r_emit(g, 'j', 0, 0);
        jmps[nj++] = j;
        if (g->empty_seq) g->p[s0].x = j;   
    }
    long fail = r_emit(g, 'f', 0, 0);   
    long exit = g->n;
    g->p[head].x = head + 1;
    g->p[head].y = (ns > 0) ? sps[0] : fail;
    g->p[j1].x = exit;
    for (int k = 0; k < ns; k++) {
        g->p[sps[k]].x = sps[k] + 1;
        g->p[sps[k]].y = (k + 1 < ns) ? sps[k + 1] : fail;
    }
    for (int k = 0; k < nj; k++) g->p[jmps[k]].x = exit;
    return head;
}


static void re_close(RInst *p, long pc, const char *s, long si, long *out, long *nout, long *seen) {
    long stack[512];
#define RSTACK_MAX 512
    int sp = 0;
    stack[sp++] = pc;
    while (sp > 0) {
        long q = stack[--sp];
        if (q < 0 || seen[q]) continue;
        seen[q] = 1;
        RInst *in = &p[q];
        
        if (in->op == 'j') { if (sp < RSTACK_MAX) stack[sp++] = in->x; }
        else if (in->op == 's') { if (sp + 2 <= RSTACK_MAX) { stack[sp++] = in->x; stack[sp++] = in->y; } }
        else if (in->op == 'b') { if (si == 0 && sp < RSTACK_MAX) stack[sp++] = q + 1; }
        else if (in->op == 'e') { if (s[si] == 0 && sp < RSTACK_MAX) stack[sp++] = q + 1; }
        else if (in->op == 'f') {  }
        else out[(*nout)++] = q;   
    }
}

BFN int vre_match(Val sv, Val pv) {
    if (sv.tag != V_STR || pv.tag != V_STR) { vraise("re_match wants str"); }
    const char *s = sv.as.str, *pat = pv.as.str;
    RProg g;
    g.p = NULL; g.n = 0; g.cap = 0; g.pat = pat; g.i = 0; g.plen = (long)strlen(pat); g.err = 0;
    g.empty_seq = 0;
    long start = r_alt(&g);
    if (g.err || start < 0 || g.i != g.plen) { vraise("bad regex pattern"); }
    r_emit(&g, 'm', 0, 0);
    for (long k = 0; k < g.n; k++) {
        if (g.p[k].op == 'j' && g.p[k].x == k) g.p[k].x = g.n - 1;
    }
    long nprog = g.n;
    long *list = (long *)malloc(sizeof(long) * (size_t)(nprog + 1));
    long *next = (long *)malloc(sizeof(long) * (size_t)(nprog + 1));
    long *seen = (long *)malloc(sizeof(long) * (size_t)(nprog + 1));
    if (!list || !next || !seen) { free(list); free(next); free(seen); vfatal_oom(); }
    long slen = (long)strlen(s);
    for (long from = 0; from <= slen; from++) {
        long nlist = 0;
        memset(seen, 0, sizeof(long) * (size_t)(nprog + 1));
        re_close(g.p, start, s, from, list, &nlist, seen);
        for (long si = from; ; si++) {
            
            for (long k = 0; k < nlist; k++) {
                if (g.p[list[k]].op == 'm') { free(list); free(next); free(seen); free(g.p); return 1; }
            }
            if (!s[si] || nlist == 0) break;
            long nn = 0;
            memset(seen, 0, sizeof(long) * (size_t)(nprog + 1));
            for (long k = 0; k < nlist; k++) {
                RInst *in = &g.p[list[k]];
                if (in->op != 'c') continue;
                if (in->q == 'l') { if (s[si] != in->ch) continue; }
                else if (in->q == 'd') {  }
                else {
                    RTok t; t.kind = 's'; t.q = 0; t.ch = 0; t.body = in->body;
                    if (!rtok_match(&t, s[si])) continue;
                }
                re_close(g.p, list[k] + 1, s, si + 1, next, &nn, seen);
            }
            long *tmp = list; list = next; next = tmp;
            nlist = nn;
        }
        if (nlist > 0) {
            for (long k = 0; k < nlist; k++) {
                if (g.p[list[k]].op == 'm') { free(list); free(next); free(seen); free(g.p); return 1; }
            }
        }
    }
    free(list); free(next); free(seen); free(g.p);
    return 0;
}

BFN Val vquest(Val v) {
    if (v.tag == V_TAG && !strcmp(v.as.tv.tag, "err")) {
        vunwind = v;
        vunwind_do();
    }
    return v;
}
BFN Val vquest_ok(Val v) {
    if (v.tag == V_TAG && (!strcmp(v.as.tv.tag, "ok") || !strcmp(v.as.tv.tag, "some")))
        return v.as.tv.args->len ? v.as.tv.args->items[0] : vnil();
    return v;
}

BFN double vtime(void) {
    static double t0 = 0;
    double now = (double)clock() / CLOCKS_PER_SEC;
    if (!t0) t0 = now;
    return now;
}

BFN long vsprint_len(Val v);
BFN long vsprint(Val v, char *o);
BFN long vsprint_len_q(Val v, long q);
BFN long vsprint_q(Val v, char *o, long q);

BFN void vmetric(Val name, Val v) {
    printf("{\"ts\": %.7f, \"metric\": ", vtime());
    vjprint(name);
    printf(", \"vals\": ");
    vjprint(v);
    printf("}\n");
    fflush(stdout);
}BFN Val vfield(Val v, const char *k) {
    if (v.tag == V_STRUCT) {
        Val *o = map_get(v.as.map, k);
        if (!o) { vraisef("no field %s\n", k); }
        return *o;
    }
    vraisef("no field %s\n", k);
}


BFN Val verr(const char *msg) {
    Vec *e = vvec();
    vec_push(e, vstr(msg));
    return vtagv("err", e);
}

BFN Val verr_os(const char *rp) {
    char m[9000];
    snprintf(m, sizeof m, "[Errno %d] %s: '%s'", errno, strerror(errno), rp);
    return verr(m);
}
BFN Val vok1(const char *s) {
    Vec *a = vvec();
    vec_push(a, vstr(s));
    return vtagv("ok", a);
}
BFN Val vreadfile(Val p) {
    if (p.tag != V_STR) return verr("read_file wants a string path");
    const char *rp = vconfine(p.as.str);
    if (!rp) return verr("path outside the program directory");
    errno = 0;
    FILE *f = fopen(rp, "rb");
    if (!f) return verr_os(rp);
    if (!_vfd_confined(fileno(f))) { fclose(f); return verr("path escaped during open"); }
    char buf[4096];
    size_t n;
    size_t total = 0;
    char *data = NULL;
    while ((n = fread(buf, 1, sizeof buf, f)) > 0) {
        data = (char *)bgrow(data, total + n + 1);
        memcpy(data + total, buf, n);
        total += n;
    }
    
    int failed = ferror(f);
    int rerr = errno;
    fclose(f);
    if (failed) { errno = rerr; return verr_os(rp); }
    
    if (!data) return vok1("");
    data[total] = 0;
    Vec *a = vvec();
    vec_push(a, vstr(data));
    free(data);
    return vtagv("ok", a);
}

static int _vsk[64];
static int _vsk_ready = 0;

static void _vsk_init(void) {
    for (int i = 0; i < 64; i++) _vsk[i] = -1;
    _vsk_ready = 1;
}
/* A growable string. `vadd` allocates a fresh buffer and copies both operands,
   which makes `s = s + x` quadratic; this grows one buffer instead. The handle
   is opaque so no BRAT value ever aliases the buffer -- that is what keeps the
   append safe without an ownership proof. */
static int _vsk_put(int fd) {
    for (int i = 1; i < 64; i++) if (_vsk[i] < 0) { _vsk[i] = fd; return i; }
    return -1;
}
static int _vsk_get(long slot) {
    if (slot < 1 || slot >= 64) return -1;
    return _vsk[slot];
}
static Val _vok_int(long n) { Vec *a = vvec(); vec_push(a, vint(n)); return vtagv("ok", a); }
static Val _verr_c(const char *m) { Vec *a = vvec(); vec_push(a, vstr(m)); return vtagv("err", a); }

static void _vhost_port(const char *c, char *host, size_t hcap, int *port) {
    const char *colon = strrchr(c, ':');
    if (!colon) { host[0] = 0; *port = 0; return; }
    size_t hl = (size_t)(colon - c);
    if (hl >= hcap) hl = hcap - 1;
    memcpy(host, c, hl); host[hl] = 0;
    *port = atoi(colon + 1);
}

typedef struct { char *buf; long len, cap; int used; } VSbuf;
static VSbuf _vsb[64];
static int _vsb_next = 1;

static VSbuf *_vsb_get(long h) {
    if (h < 1 || h >= 64) return NULL;
    if (!_vsb[h].used) return NULL;
    return &_vsb[h];
}
BFN Val vsbuf(void) {
    for (int i = 1; i < 64; i++) {
        if (!_vsb[i].used) {
            _vsb[i].used = 1;
            _vsb[i].len = 0;
            _vsb[i].cap = 16;
            _vsb[i].buf = (char *)malloc((size_t)_vsb[i].cap);
            if (!_vsb[i].buf) { _vsb[i].used = 0; vfatal_oom(); }
            _vsb[i].buf[0] = 0;
            return vint(i);
        }
    }
    return _verr_c("too many builders");
}
BFN Val vsbuf_add(Val h, Val part) {
    VSbuf *b = _vsb_get((long)vlong(h));
    if (!b) return _verr_c("bad builder");
    if (part.tag != V_STR) return _verr_c("sbuf_add wants a string");
    size_t pl = strlen(part.as.str);
    while (b->len + (long)pl + 1 > b->cap) {
        b->cap *= 2;
        b->buf = (char *)bgrow(b->buf, (size_t)b->cap);
    }
    memcpy(b->buf + b->len, part.as.str, pl);
    b->len += (long)pl;
    b->buf[b->len] = 0;
    return vint(b->len);
}
BFN Val vsbuf_len(Val h) {
    VSbuf *b = _vsb_get((long)vlong(h));
    if (!b) return _verr_c("bad builder");
    return vint(b->len);
}
BFN Val vsbuf_str(Val h) {
    VSbuf *b = _vsb_get((long)vlong(h));
    if (!b) return _verr_c("bad builder");
    Vec *a = vvec();
    vec_push(a, vstrn(b->buf, b->len));
    return vtagv("ok", a);
}
BFN Val vtcp_listen(Val addr) {
    if (addr.tag != V_STR) return _verr_c("tcp_listen wants a string address");
    if (!_vsk_ready) _vsk_init();
    char host[256]; int port;
    _vhost_port(addr.as.str, host, sizeof host, &port);
    if (!host[0]) return _verr_c("address wants host:port");
    int fd = (int)socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return _verr_c("socket failed");
    int one = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, (const char *)&one, sizeof one);
    struct sockaddr_in sa;
    memset(&sa, 0, sizeof sa);
    sa.sin_family = AF_INET;
    sa.sin_port = htons((unsigned short)port);
    sa.sin_addr.s_addr = inet_addr(host);
    if (bind(fd, (struct sockaddr *)&sa, sizeof sa) != 0) { close(fd); return _verr_c("bind failed"); }
    if (listen(fd, 16) != 0) { close(fd); return _verr_c("listen failed"); }
    int slot = _vsk_put(fd);
    if (slot < 0) { close(fd); return _verr_c("too many sockets"); }
    return _vok_int(slot);
}
BFN Val vtcp_connect(Val addr) {
    if (addr.tag != V_STR) return _verr_c("tcp_connect wants a string address");
    if (!_vsk_ready) _vsk_init();
    char host[256]; int port;
    _vhost_port(addr.as.str, host, sizeof host, &port);
    if (!host[0]) return _verr_c("address wants host:port");
    int fd = (int)socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return _verr_c("socket failed");
    struct sockaddr_in sa;
    memset(&sa, 0, sizeof sa);
    sa.sin_family = AF_INET;
    sa.sin_port = htons((unsigned short)port);
    sa.sin_addr.s_addr = inet_addr(host);
    if (connect(fd, (struct sockaddr *)&sa, sizeof sa) != 0) { close(fd); return _verr_c("connect failed"); }
    int slot = _vsk_put(fd);
    if (slot < 0) { close(fd); return _verr_c("too many sockets"); }
    return _vok_int(slot);
}
BFN Val vtcp_accept(Val slot) {
    int lfd = _vsk_get((long)vlong(slot));
    if (lfd < 0) return _verr_c("bad socket slot");
    int fd = (int)accept(lfd, NULL, NULL);
    if (fd < 0) return _verr_c("accept failed");
    int ns = _vsk_put(fd);
    if (ns < 0) { close(fd); return _verr_c("too many sockets"); }
    return _vok_int(ns);
}

BFN Val vtcp_recv(Val slot, Val n) {
    int fd = _vsk_get((long)vlong(slot));
    if (fd < 0) return _verr_c("bad socket slot");
    long want = (long)vlong(n);
    if (want < 0) return _verr_c("recv wants n >= 0");
    char *buf = (char *)malloc((size_t)want + 1);
    if (!buf) vfatal_oom();
    long got = (long)recv(fd, buf, (size_t)want, 0);
    if (got < 0) { free(buf); return _verr_c("recv failed"); }
    buf[got] = 0;
    Vec *a = vvec();
    vec_push(a, vstrn(buf, got));
    free(buf);
    return vtagv("ok", a);
}
BFN Val vtcp_send(Val slot, Val data) {
    int fd = _vsk_get((long)vlong(slot));
    if (fd < 0) return _verr_c("bad socket slot");
    if (data.tag != V_STR) return _verr_c("tcp_send wants string data");
    long n = (long)send(fd, data.as.str, strlen(data.as.str), 0);
    if (n < 0) return _verr_c("send failed");
    return _vok_int(n);
}
BFN Val vtcp_close(Val slot) {
    long sl = (long)vlong(slot);
    int fd = _vsk_get(sl);
    if (fd < 0) return _verr_c("bad socket slot");
    _vsk[sl] = -1;
    close(fd);
    return _vok_int(0);
}
BFN Val vwritefile(Val p, Val t) {
    if (p.tag != V_STR || t.tag != V_STR) return verr("write_file wants string path and text");
    const char *rp = vconfine(p.as.str);
    if (!rp) return verr("path outside the program directory");
    errno = 0;
    FILE *f = fopen(rp, "wb");
    if (!f) return verr_os(rp);
    if (!_vfd_confined(fileno(f))) { fclose(f); return verr("path escaped during open"); }
    size_t n = strlen(t.as.str);
    fwrite(t.as.str, 1, n, f);
    fclose(f);
    Vec *a = vvec();
    vec_push(a, vint((bint)n));
    return vtagv("ok", a);
}
BFN Val vstr_of(Val v) {
    if (v.tag == V_STR) return vstr(v.as.str);
    
    long n = vsprint_len_q(v, 0);
    char *b = (char *)malloc(n + 1);
    vsprint_q(v, b, 0);
    b[n] = 0;
    Val r = vstrn(b, n);
    free(b);
    return r;
}
BFN Val vsplit(Val s, Val sep) {
    Vec *out = vvec();
    if (s.tag != V_STR) { vraise("no method split"); }
    const char *p = s.as.str;
    if (sep.tag != V_STR) {
        while (*p) {
            while (*p == ' ' || *p == '\t' || *p == '\n') p++;
            if (!*p) break;
            const char *q = p;
            while (*q && *q != ' ' && *q != '\t' && *q != '\n') q++;
            vec_push(out, vstrn(p, q - p));
            p = q;
        }
        return vvecv(out);
    }
    size_t dl = strlen(sep.as.str);
    if (!dl) { vec_push(out, vstr(p)); return vvecv(out); }
    const char *q;
    while ((q = strstr(p, sep.as.str)) != 0) {
        vec_push(out, vstrn(p, q - p));
        p = q + dl;
    }
    vec_push(out, vstr(p));
    return vvecv(out);
}
BFN Val vtrim(Val s) {
    if (s.tag != V_STR) { vraise("no method trim"); }
    const char *p = s.as.str;
    while (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r') p++;
    long n = strlen(p);
    while (n > 0 && (p[n-1] == ' ' || p[n-1] == '\t' || p[n-1] == '\n' || p[n-1] == '\r')) n--;
    return vstrn(p, n);
}

BFN long vcp_next(const char *p, unsigned *out) {
    unsigned c = (unsigned char)p[0];
    long n = 1;
    if (c >= 0xF0) { c &= 0x07; n = 4; }
    else if (c >= 0xE0) { c &= 0x0F; n = 3; }
    else if (c >= 0xC0) { c &= 0x1F; n = 2; }
    
    while (n > 1 && !p[n - 1]) n--;
    for (long i = 1; i < n; i++) c = (c << 6) | ((unsigned char)p[i] & 0x3F);
    *out = c;
    return n;
}


BFN long vcp_put(unsigned cp, char *out) {
    if (cp < 0x80) { out[0] = (char)cp; return 1; }
    if (cp < 0x800) {
        out[0] = (char)(0xC0 | (cp >> 6));
        out[1] = (char)(0x80 | (cp & 0x3F));
        return 2;
    }
    if (cp < 0x10000) {
        out[0] = (char)(0xE0 | (cp >> 12));
        out[1] = (char)(0x80 | ((cp >> 6) & 0x3F));
        out[2] = (char)(0x80 | (cp & 0x3F));
        return 3;
    }
    out[0] = (char)(0xF0 | (cp >> 18));
    out[1] = (char)(0x80 | ((cp >> 12) & 0x3F));
    out[2] = (char)(0x80 | ((cp >> 6) & 0x3F));
    out[3] = (char)(0x80 | (cp & 0x3F));
    return 4;
}


BFN unsigned vcp_upper(unsigned c) {
    if (c >= 'a' && c <= 'z') return c - 32;
    if (c >= 0xE0 && c <= 0xFE && c != 0xF7) return c - 32;        
    if (c >= 0x100 && c <= 0x17F && (c & 1)) return c - 1;         
    if (c >= 0x1C4 && c <= 0x1CC && (c & 1)) return c - 1;         
    if (c >= 0x391 && c <= 0x3AB && c != 0x3A2) {                  
        if (c >= 0x3AC) return c - 0x40;                           
        return c - 32;
    }
    if (c >= 0x430 && c <= 0x44F) return c - 32;                   
    if (c >= 0x450 && c <= 0x45F) return c - 80;                   
    return 0;
}


BFN unsigned vcp_lower(unsigned c) {
    if (c >= 'A' && c <= 'Z') return c + 32;
    if (c >= 0xC0 && c <= 0xDE && c != 0xD7) return c + 32;
    if (c >= 0x100 && c <= 0x17F && !(c & 1)) return c + 1;
    if (c >= 0x1C4 && c <= 0x1CC && !(c & 1)) return c + 1;
    
    if (c >= 0x391 && c <= 0x3A9 && c != 0x3A2) return c + 32;
    if (c >= 0x386 && c <= 0x38F) {
        
        switch (c) {
        case 0x386: case 0x388: case 0x389: case 0x38A:
        case 0x38C: case 0x38E: case 0x38F:
            return c + 0x40;
        default:
            return 0;
        }
    }
    if (c >= 0x400 && c <= 0x40F) return c + 80;
    if (c >= 0x410 && c <= 0x42F) return c + 32;
    return 0;
}


BFN unsigned vcp_lower_ctx(unsigned c, unsigned prev, const char *rest) {
    unsigned out = vcp_lower(c);
    if (!out) return 0;
    if (out == 0x3C3) {
        
        int prev_cased = (prev >= 'A' && prev <= 'Z') || (prev >= 0x391 && prev <= 0x3A9)
                      || (prev >= 0x410 && prev <= 0x44F);
        unsigned next = 0;
        if (*rest) vcp_next(rest, &next);
        int next_cased = (next >= 'a' && next <= 'z') || (next >= 'A' && next <= 'Z')
                      || (next >= 0x3B1 && next <= 0x3C9) || (next >= 0x430 && next <= 0x44F);
        if (prev_cased && !next_cased) return 0x3C2;
    }
    return out;
}

BFN Val vcase(Val s, int up) {
    if (s.tag != V_STR) { vraise("no method case"); }
    size_t len = strlen(s.as.str) + 8;
    char *o = (char *)malloc(len);
    if (!o) vfatal_oom();
    long on = 0;
    unsigned prev = 0;
    for (const char *p = s.as.str; *p; ) {
        unsigned cp = 0;
        long n = vcp_next(p, &cp);
        const char *rest = p + n;
        if (up && cp == 0xDF) {
            
            if (on + 4 >= (long)len) { len = len * 2 + 8; o = (char *)bgrow(o, len); }
            o[on++] = 'S'; o[on++] = 'S';
            p += n;
            prev = cp;
            continue;
        }
        unsigned m = up ? vcp_upper(cp) : vcp_lower_ctx(cp, prev, rest);
        if (!m) { m = cp; }
        if (m == cp) {
            if (on + 4 >= (long)len) { len = len * 2 + 8; o = (char *)bgrow(o, len); }
            memcpy(o + on, p, (size_t)n);
            on += n;
        } else {
            if (on + 5 >= (long)len) { len = len * 2 + 8; o = (char *)bgrow(o, len); }
            on += vcp_put(m, o + on);
        }
        prev = cp;
        p += n;
    }
    o[on] = 0;
    Val r; r.tag = V_STR; r.as.str = o;
    return r;
}
BFN long vaffix(Val s, Val p, int pre, int suf) {
    if (s.tag != V_STR || p.tag != V_STR) { vraise("no method affix"); }
    if (pre) return !strncmp(s.as.str, p.as.str, strlen(p.as.str));
    long ls = strlen(s.as.str), lp = strlen(p.as.str);
    if (suf) return lp <= ls && !strcmp(s.as.str + ls - lp, p.as.str);
    return strstr(s.as.str, p.as.str) != 0;
}
BFN Val vreplace(Val s, Val a, Val b) {
    if (s.tag != V_STR || a.tag != V_STR || b.tag != V_STR) { vraise("no method replace"); }
    const char *p = s.as.str, *pat = a.as.str, *rep = b.as.str;
    size_t pl = strlen(pat), rl = strlen(rep);
    if (!pl) {
        size_t sl = strlen(p);
        char *o = (char *)malloc((sl + 1) * (rl + 1) + 1);
        if (!o) vfatal_oom();
        char *w = o;
        strcpy(w, rep); w += rl;
        for (size_t i = 0; i < sl; i++) { *w++ = p[i]; memcpy(w, rep, rl); w += rl; }
        *w = 0;
        Val r; r.tag = V_STR; r.as.str = o;
        return r;
    }
    size_t total = strlen(p) + 1;
    char *o = (char *)malloc(total);
    if (!o) vfatal_oom();
    size_t n = 0;
    const char *q;
    while ((q = strstr(p, pat)) != 0) {
        size_t chunk = (size_t)(q - p);
        size_t need = n + chunk + rl + 1;
        if (need > total) { total = need * 2; o = (char *)bgrow(o, total); }
        memcpy(o + n, p, chunk); n += chunk;
        memcpy(o + n, rep, rl); n += rl;
        p = q + pl;
    }
    size_t rest = strlen(p) + 1;
    if (n + rest > total) o = (char *)bgrow(o, n + rest);
    memcpy(o + n, p, rest);
    Val r; r.tag = V_STR; r.as.str = o;
    return r;
}
BFN Val vindex_of(Val s, Val sub) {
    if (s.tag != V_STR || sub.tag != V_STR) { vraise("no method index_of"); }
    char *p = strstr(s.as.str, sub.as.str);
    if (!p) return vnil();
    
    long cps = 0;
    for (const char *q = s.as.str; q < p; ) {
        unsigned cp = 0;
        q += vcp_next(q, &cp);
        cps++;
    }
    return vint(cps);
}
BFN Val vrepeat_n(Val s, bint k) {
    if (s.tag != V_STR) { vraise("no method repeat"); }
    size_t sl = strlen(s.as.str);
    if (k <= 0 || !sl) return vstr("");
    if ((size_t)k > (size_t)-1 / (sl ? sl : 1)) { vraise("repeat overflow"); }
    char *o = (char *)malloc(sl * (size_t)k + 1);
    if (!o) vfatal_oom();
    for (bint i = 0; i < k; i++) memcpy(o + (size_t)i * sl, s.as.str, sl);
    o[sl * (size_t)k] = 0;
    Val r; r.tag = V_STR; r.as.str = o;
    return r;
}
BFN Val vrepeat(Val s, Val n) { return vrepeat_n(s, vlong(n)); }

BFN Val vlines(Val s) {
    if (s.tag != V_STR) { vraise("no method lines"); }
    Vec *o = vvec();
    if (!s.as.str[0]) return vvecv(o);
    const char *p = s.as.str;
    const char *start = p;
    for (;;) {
        if (*p == '\n' || *p == '\r') {
            vec_push(o, vstrn(start, (long)(p - start)));
            if (*p == '\r' && p[1] == '\n') p++;
            p++;
            start = p;
            if (!*start) break;
            continue;
        }
        if (*p == 0) {
            vec_push(o, vstrn(start, (long)(p - start)));
            break;
        }
        p++;
    }
    return vvecv(o);
}

BFN Val vsplit_once(Val s, Val sep) {
    if (s.tag != V_STR || sep.tag != V_STR) { vraise("no method split_once"); }
    if (!sep.as.str[0]) {
        Vec *o = vvec();
        vec_push(o, vstr(""));
        vec_push(o, vstr(s.as.str));
        return vvecv(o);
    }
    char *p = strstr(s.as.str, sep.as.str);
    if (!p) return vnil();
    Vec *o = vvec();
    vec_push(o, vstrn(s.as.str, (long)(p - s.as.str)));
    vec_push(o, vstr(p + strlen(sep.as.str)));
    return vvecv(o);
}
BFN Val vparse_int(Val s) {
    if (s.tag != V_STR) { Vec *a = vvec(); return vtagv("err", a); }
    const char *p = s.as.str;
    while (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r' || *p == '\f' || *p == '\v') p++;
    const char *q = p;
    if (*q == '+' || *q == '-') q++;
    if (!(*q >= '0' && *q <= '9')) { Vec *a = vvec(); vec_push(a, vstr("not a number")); return vtagv("err", a); }
    unsigned long long acc = 0;
    while (*q >= '0' && *q <= '9') { acc = acc * 10ULL + (unsigned long long)(*q - '0'); q++; }
    while (*q == ' ' || *q == '\t' || *q == '\n' || *q == '\r' || *q == '\f' || *q == '\v') q++;
    Vec *a = vvec();
    if (*q) { vec_push(a, vstr("not a number")); return vtagv("err", a); }
    
    bint v = (bint)acc;
    if (*p == '-') v = -v;
    vec_push(a, vint(v));
    return vtagv("ok", a);
}
BFN Val vjoin(Val v, Val sep) {
    if (v.tag != V_VEC || sep.tag != V_STR) { vraise("no method join"); }
    Vec *w = v.as.vec;
    size_t total = 1;
    long i;
    for (i = 0; i < w->len; i++) total += (size_t)vsprint_len_q(w->items[i], 0);
    if (w->len > 1) total += strlen(sep.as.str) * (size_t)(w->len - 1);
    char *out = (char *)malloc(total + 1);
    if (!out) vfatal_oom();
    long on = 0;
    for (i = 0; i < w->len; i++) {
        if (i) { size_t sl = strlen(sep.as.str); memcpy(out + on, sep.as.str, sl); on += (long)sl; }
        on += vsprint_q(w->items[i], out + on, 0);
    }
    out[on] = 0;
    Val r; r.tag = V_STR; r.as.str = out;
    return r;
}
BFN Val vtagof(Val v) {
    if (v.tag == V_NIL) return vstr("none");
    if (v.tag == V_TAG) return vstr(v.as.tv.tag);
    return vstr("plain");
}
BFN bint vlong(Val v) {
    if (v.tag == V_INT) return v.as.ival;
    if (v.tag == V_FLOAT) return (bint)v.as.fval;
    vraise("not a number");
}
BFN Vec *vvec_of(Val v) {
    if (v.tag != V_VEC) { vraise("not a vec"); }
    return v.as.vec;
}
BFN int vis_err(Val v) {
    return v.tag == V_TAG && !strcmp(v.as.tv.tag, "err");
}
BFN int vis_none(Val v) {
    return v.tag == V_NIL;
}

BFN const char *vtypename(Val v) {
    switch (v.tag) {
    case V_NIL: return "none";
    case V_BOOL: return "bool";
    case V_INT: return "i64";
    case V_FLOAT: return "f64";
    case V_STR: return "str";
    case V_VEC: return "vec";
    case V_STRUCT: return v.as.map->type && v.as.map->type[0] ? v.as.map->type : "map";
    case V_TAG: return v.as.tv.tag ? v.as.tv.tag : "tag";
    }
    return "value";
}
BFN Val vunwrap(Val v) {
    if (v.tag == V_TAG && (!strcmp(v.as.tv.tag, "ok") || !strcmp(v.as.tv.tag, "some")))
        return v.as.tv.args->len ? v.as.tv.args->items[0] : vnil();
    if (v.tag == V_TAG && !strcmp(v.as.tv.tag, "err")) {
        vunwind = v;
        vunwind_do();
    }
    
    vraisef("unwrap of %s (want Ok/Err/Some)", vtypename(v));
    return vnil();
}
BFN int vor_fb(Val v) {
    return v.tag == V_NIL;
}
BFN const char *vname(Val v) {
    if (v.tag != V_STR) { vraise("want str"); }
    return v.as.str;
}
BFN long vsprint_q(Val v, char *o, long q) {
    long n = 0, i;
    char tmp[64];
    switch (v.tag) {
    case V_NIL: memcpy(o, "None", 4); return 4;
    case V_BOOL: memcpy(o, v.as.b ? "True" : "False", v.as.b ? 4 : 5); return v.as.b ? 4 : 5;
    case V_INT: n = snprintf(tmp, sizeof tmp, BINT_FMT, (bint)v.as.ival); memcpy(o, tmp, n); return n;
    case V_FLOAT: { const char *s = vfmt_double(v.as.fval); n = (long)strlen(s); memcpy(o, s, n); return n; }
    case V_STR:
        if (!q) { n = strlen(v.as.str); memcpy(o, v.as.str, n); return n; }
        o[n++] = '\'';
        for (const char *p = v.as.str; *p; p++) {
            if (*p == '\'' || *p == '\\') { o[n++] = '\\'; o[n++] = *p; }
            else if (*p == '\n') { o[n++] = '\\'; o[n++] = 'n'; }
            else if (*p == '\r') { o[n++] = '\\'; o[n++] = 'r'; }
            else if (*p == '\t') { o[n++] = '\\'; o[n++] = 't'; }
            else o[n++] = *p;
        }
        o[n++] = '\'';
        return n;
    case V_VEC:
        o[n++] = '[';
        for (i = 0; i < v.as.vec->len; i++) {
            if (i) { o[n++] = ','; o[n++] = ' '; }
            n += vsprint_q(v.as.vec->items[i], o + n, 1);
        }
        o[n++] = ']';
        return n;
    case V_STRUCT: {
        int ismap = !v.as.map->type[0];
        o[n++] = '{';
        if (!ismap) {
            n += vput(o + n, "'$type': '");
            n += vput(o + n, v.as.map->type);
            o[n++] = '\'';
        }
        for (i = 0; i < v.as.map->len; i++) {
            if (i || !ismap) { o[n++] = ','; o[n++] = ' '; }
            n += vsprint_q(v.as.map->keys[i], o + n, 1);
            o[n++] = ':'; o[n++] = ' ';
            n += vsprint_q(v.as.map->vals[i], o + n, 1);
        }
        o[n++] = '}';
        return n;
    }
    case V_TAG: {
        o[0] = '('; o[1] = '\''; n = 2;
        n += vput(o + n, v.as.tv.tag);
        o[n++] = '\'';
        for (i = 0; i < v.as.tv.args->len; i++) {
            o[n++] = ','; o[n++] = ' ';
            n += vsprint_q(v.as.tv.args->items[i], o + n, 1);
        }
        if (v.as.tv.args->len == 0) o[n++] = ',';
        o[n++] = ')';
        return n;
    }
    }
    return 0;
}

BFN long vsprint(Val v, char *o) { return vsprint_q(v, o, 0); }

BFN long vsprint_len_q(Val v, long q) {
    long n = 0, i;
    char tmp[64];
    switch (v.tag) {
    case V_NIL: return 4;
    case V_BOOL: return v.as.b ? 4 : 5;
    case V_INT: return snprintf(tmp, sizeof tmp, BINT_FMT, (bint)v.as.ival);
    case V_FLOAT: return (long)strlen(vfmt_double(v.as.fval));
    case V_STR: return q ? vrepr_slen(v.as.str) + 2 : (long)strlen(v.as.str);
    case V_VEC:
        n = 2;
        for (i = 0; i < v.as.vec->len; i++) {
            if (i) n += 2;
            n += vsprint_len_q(v.as.vec->items[i], 1);
        }
        return n;
    case V_STRUCT: {
        int ismap = !v.as.map->type[0];
        n = 1;
        if (!ismap) n += 11 + (long)strlen(v.as.map->type);
        for (i = 0; i < v.as.map->len; i++) {
            if (i || !ismap) n += 2;
            n += vsprint_len_q(v.as.map->keys[i], 1) + 2 + vsprint_len_q(v.as.map->vals[i], 1);
        }
        return n + 1;
    }
    case V_TAG: {
        n = 3 + (long)strlen(v.as.tv.tag);
        for (i = 0; i < v.as.tv.args->len; i++) n += 2 + vsprint_len_q(v.as.tv.args->items[i], 1);
        if (v.as.tv.args->len == 0) n += 1;
        return n + 1;
    }
    }
    return 0;
}

BFN long vsprint_len(Val v) { return vsprint_len_q(v, 0); }
BFN void vlogv(const char *lvl, Vec *a) {
    long total = 0, i;
    for (i = 0; i < a->len; i++) {
        if (i) total += 1;
        total += vsprint_len(a->items[i]);
    }
    char *buf = (char *)malloc(total + 1);
    if (!buf) vfatal_oom();
    long n = 0;
    for (i = 0; i < a->len; i++) {
        if (i) buf[n++] = ' ';
        n += vsprint(a->items[i], buf + n);
    }
    buf[n] = 0;
    
    printf("{\"ts\": %.7f, \"lvl\": \"%s\", \"msg\": \"", vtime(), lvl);
    for (char *p = buf; *p; p++) {
        if (*p == '"' || *p == '\\') { putchar('\\'); putchar(*p); }
        else if (*p == '\n') printf("\\n");
        else if (*p == '\r') printf("\\r");
        else if (*p == '\t') printf("\\t");
        else if ((unsigned char)*p < 0x20) printf("\\u%04x", (unsigned char)*p);
        else putchar((unsigned char)*p);
    }
    printf("\"}\n");
    fflush(stdout);
    free(buf);
}
BFN Val vpush(Val v, Val x) {
    Vec *w = vvec_of(v);
    vec_push(w, x);
    return vint(w->len);
}
BFN Val vpop(Val v) {
    Vec *w = vvec_of(v);
    if (!w->len) return vnil();
    return w->items[--w->len];
}
BFN Val vfirst(Val v) {
    Vec *w = vvec_of(v);
    if (!w->len) return vnil();
    return w->items[0];
}
BFN Val vlast(Val v) {
    Vec *w = vvec_of(v);
    if (!w->len) return vnil();
    return w->items[w->len - 1];
}
static int vcmp_q(const void *pa, const void *pb) {
    return vcmp(*(const Val *)pa, *(const Val *)pb);
}
BFN Val vsort(Val v) {
    Vec *w = vvec_of(v);
    if (w->len > 1) qsort(w->items, (size_t)w->len, sizeof(Val), vcmp_q);
    return v;
}
BFN Val vrev(Val v) {
    Vec *w = vvec_of(v);
    Vec *o = vvec();
    for (long i = w->len - 1; i >= 0; i--) vec_push(o, w->items[i]);
    return vvecv(o);
}
BFN Val vins(Val v, Val i, Val x) {
    Vec *w = vvec_of(v);
    long k = vlong(i);
    
    if (k < 0) k = (k < -w->len) ? 0 : k + w->len;
    if (k > w->len) k = w->len;
    vec_push(w, x);
    memmove(w->items + k + 1, w->items + k, sizeof(Val) * (size_t)(w->len - 1 - k));
    w->items[k] = x;
    return vint(w->len);
}
BFN Val vdel_at(Val v, Val i) {
    Vec *w = vvec_of(v);
    long k = vlong(i);
    
    if (k < 0) {
        if (k < -w->len) { vraise("index out of range"); }
        k += w->len;
    }
    if (k < 0 || k >= w->len) { vraise("index out of range"); }
    Val r = w->items[k];
    memmove(w->items + k, w->items + k + 1, sizeof(Val) * (size_t)(w->len - 1 - k));
    w->len--;
    return r;
}
BFN Val vslice(Val v, Val a, Val b) {
    Vec *w = vvec_of(v);
    long n = w->len, x = vlong(a), y = vlong(b);
    if (x < 0) x = (x < -n) ? 0 : x + n;
    if (x < 0) x = 0;
    if (x > n) x = n;
    if (y < 0) y = (y < -n) ? 0 : y + n;
    if (y < 0) y = 0;
    if (y > n) y = n;
    Vec *o = vvec();
    for (long i = x; i < y; i++) vec_push(o, w->items[i]);
    return vvecv(o);
}
BFN Val vsum(Val v) {
    Vec *w = vvec_of(v);
    
    unsigned long long acc = 0;
    double dl = 0;
    int isf = 0;
    for (long i = 0; i < w->len; i++) {
        Val x = w->items[i];
        if (x.tag == V_INT || x.tag == V_BOOL) acc += (unsigned long long)x.as.ival;
        else if (x.tag == V_FLOAT) { dl += x.as.fval; isf = 1; }
        else { vraise("sum of non-numeric"); }
    }
    if (isf) return vfloat(dl + (double)(bint)acc);
    return vint((bint)acc);
}
BFN Val vmin(Val v) {
    Vec *w = vvec_of(v);
    if (!w->len) return vnil();
    Val r = w->items[0];
    for (long i = 1; i < w->len; i++) if (vcmp(w->items[i], r) < 0) r = w->items[i];
    return r;
}
BFN Val vmax(Val v) {
    Vec *w = vvec_of(v);
    if (!w->len) return vnil();
    Val r = w->items[0];
    for (long i = 1; i < w->len; i++) if (vcmp(w->items[i], r) > 0) r = w->items[i];
    return r;
}
BFN Val venum(Val v) {
    Vec *w = vvec_of(v);
    Vec *o = vvec();
    for (long i = 0; i < w->len; i++) {
        Vec *p = vvec();
        vec_push(p, vint(i));
        vec_push(p, w->items[i]);
        vec_push(o, vvecv(p));
    }
    return vvecv(o);
}
BFN Val vmap_get_or(Val m, Val k, Val d) {
    if (m.tag != V_STRUCT) { vraise("get_or of non-map"); }
    Val *o = map_get_v(m.as.map, k);
    return o ? *o : d;
}
BFN Val vmap_items(Val m) {
    if (m.tag != V_STRUCT) { vraise("items of non-map"); }
    Vec *o = vvec();
    for (long i = 0; i < m.as.map->len; i++) {
        Vec *p = vvec();
        vec_push(p, m.as.map->keys[i]);
        vec_push(p, m.as.map->vals[i]);
        vec_push(o, vvecv(p));
    }
    return vvecv(o);
}
BFN Val vmap_vals(Val m) {
    if (m.tag != V_STRUCT) { vraise("vals of non-map"); }
    Vec *o = vvec();
    for (long i = 0; i < m.as.map->len; i++) vec_push(o, m.as.map->vals[i]);
    return vvecv(o);
}
BFN Val vcopy(Val v) {
    if (v.tag == V_VEC) {
        Vec *o = vvec();
        for (long i = 0; i < v.as.vec->len; i++) vec_push(o, v.as.vec->items[i]);
        return vvecv(o);
    }
    if (v.tag == V_STRUCT) {
        Map *m = vmap(v.as.map->type);
        for (long i = 0; i < v.as.map->len; i++) map_set_v(m, v.as.map->keys[i], v.as.map->vals[i]);
        return vstruct(m);
    }
    if (v.tag == V_STR) return v;
    vraise("copy of non-container");
}
BFN Val vchars(Val s) {
    if (s.tag != V_STR) { vraise("no method chars"); }
    Vec *o = vvec();
    for (const char *p = s.as.str; *p; p += utf8_cplen(p)) vec_push(o, vstrn(p, utf8_cplen(p)));
    return vvecv(o);
}
BFN Val vstr_slice(Val s, Val a, Val b) {
    if (s.tag != V_STR) { vraise("no method slice"); }
    long n = 0;
    for (const char *q = s.as.str; *q; q += utf8_cplen(q)) n++;
    long x = vlong(a), y = vlong(b);
    if (x < 0) x = (x < -n) ? 0 : x + n;
    if (x < 0) x = 0;
    if (x > n) x = n;
    if (y < 0) y = (y < -n) ? 0 : y + n;
    if (y < 0) y = 0;
    if (y > n) y = n;
    if (y <= x) return vstr("");
    const char *p = utf8_at(s.as.str, x);
    const char *q = utf8_at(s.as.str, y);
    return vstrn(p, (long)(q - p));
}
BFN Val vparse_float(Val s) {
    if (s.tag != V_STR) { Vec *a = vvec(); return vtagv("err", a); }
    char *e;
    const char *p = s.as.str;
    while (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r' || *p == '\f' || *p == '\v') p++;
    double v = strtod(p, &e);
    while (*e == ' ' || *e == '\t' || *e == '\n' || *e == '\r' || *e == '\f' || *e == '\v') e++;
    Vec *a = vvec();
    
    if (e == p || *e || (p[0] == '0' && (p[1] == 'x' || p[1] == 'X'))) { vec_push(a, vstr("not a float")); return vtagv("err", a); }
    vec_push(a, vfloat(v));
    return vtagv("ok", a);
}
BFN Val vzip(Val a, Val b) {
    Vec *x = vvec_of(a);
    Vec *y = vvec_of(b);
    long n = x->len < y->len ? x->len : y->len;
    Vec *o = vvec();
    for (long i = 0; i < n; i++) {
        Vec *p = vvec();
        vec_push(p, x->items[i]);
        vec_push(p, y->items[i]);
        vec_push(o, vvecv(p));
    }
    return vvecv(o);
}
BFN Val vchunks(Val v, Val n) {
    Vec *w = vvec_of(v);
    long k = vlong(n);
    if (k <= 0) { vraise("chunks wants n > 0"); }
    Vec *o = vvec();
    for (long i = 0; i < w->len; i += k) {
        Vec *p = vvec();
        for (long j = i; j < i + k && j < w->len; j++) vec_push(p, w->items[j]);
        vec_push(o, vvecv(p));
    }
    return vvecv(o);
}

BFN void vjprint(Val v) {
    long i;
    switch (v.tag) {
    case V_NIL: printf("null"); break;
    case V_BOOL: printf(v.as.b ? "true" : "false"); break;
    case V_INT: printf(BINT_FMT, (bint)v.as.ival); break;
    case V_FLOAT: printf("%s", vfmt_double(v.as.fval)); break;
    case V_STR:
        printf("\"");
        for (const char *p = v.as.str; *p; p++) {
            if (*p == '"' || *p == '\\') { putchar('\\'); putchar(*p); }
            else if (*p == '\n') printf("\\n");
            else if (*p == '\r') printf("\\r");
            else if (*p == '\t') printf("\\t");
            else if ((unsigned char)*p < 0x20) printf("\\u%04x", (unsigned char)*p);
            else putchar((unsigned char)*p);
        }
        printf("\"");
        break;
    case V_VEC:
        printf("[");
        for (i = 0; i < v.as.vec->len; i++) { if (i) printf(", "); vjprint(v.as.vec->items[i]); }
        printf("]");
        break;
    case V_STRUCT: {
        int ismap = !v.as.map->type[0];
        printf("{");
        if (!ismap) printf("\"$type\": \"%s\"", v.as.map->type);
        for (i = 0; i < v.as.map->len; i++) {
            if (i || !ismap) printf(", ");
            vjprint(v.as.map->keys[i]);
            printf(": ");
            vjprint(v.as.map->vals[i]);
        }
        printf("}");
        break;
    }
    case V_TAG: {
        
        printf("[");
        printf("\"%s\"", v.as.tv.tag);
        for (i = 0; i < v.as.tv.args->len; i++) { printf(", "); vjprint(v.as.tv.args->items[i]); }
        printf("]");
        break;
    }
    default:
        vprint(v);
        break;
    }
}

BFN void vspan_items(Val v) {
    if (v.tag == V_VEC) {
        long i;
        for (i = 0; i < v.as.vec->len; i++) { if (i) printf(", "); vjprint(v.as.vec->items[i]); }
    } else {
        vjprint(v);
    }
}

BFN void vspan(Val v) {
    printf("{\"ts\": %.7f, \"span\": [", vtime());
    vspan_items(v);
    printf("]}\n");
    fflush(stdout);
}

BFN void vjson_str(const char *s) {
    putchar('"');
    for (const unsigned char *p = (const unsigned char *)s; *p; p++) {
        if (*p == '"') fputs("\\\"", stdout);
        else if (*p == '\\') fputs("\\\\", stdout);
        else if (*p == '\n') fputs("\\n", stdout);
        else if (*p == '\r') fputs("\\r", stdout);
        else if (*p == '\t') fputs("\\t", stdout);
        else if (*p == '\b') fputs("\\b", stdout);
        else if (*p == '\f') fputs("\\f", stdout);
        else if (*p < 0x20) printf("\\u%04x", *p);
        else putchar(*p);
    }
    putchar('"');
}

BFN void vstub_log(const char *name, Vec *a) {
    long i;
    printf("{\"stub\": ");
    vjson_str(name);
    printf(", \"args\": [");
    for (i = 0; i < a->len; i++) {
        Val v = a->items[i];
        if (i) printf(", ");
        if (v.tag == V_STR) vjson_str(v.as.str);
        else { printf("\""); vprint(v); printf("\""); }
    }
    printf("]}\n");
    fflush(stdout);
}
BFN void vfieldset(Val s, const char *k, Val v) {
    Val *o;
    if (s.tag != V_STRUCT || !(o = map_get(s.as.map, k))) { vraise("bad field set"); }
    *o = v;
}
BFN Val vcall_any(Val fn, Vec *a);
BFN Val vfold(Val obj, Val init, Val fn) {
    Vec *w = vvec_of(obj);
    Val acc = init;
    Vec *args = vvec();
    vec_push(args, init);
    vec_push(args, init);
    for (long i = 0; i < w->len; i++) {
        args->items[0] = acc;
        args->items[1] = w->items[i];
        acc = vcall_any(fn, args);
    }
    return acc;
}
BFN Val vpred(Val obj, Val fn, const char *meth) {
    Vec *w = vvec_of(obj);
    Vec *one = vvec();
    vec_push(one, vnil());
    for (long i = 0; i < w->len; i++) {
        one->items[0] = w->items[i];
        Val r = vcall_any(fn, one);
        if (meth[0] == 'a' && meth[1] == 'n' && vis_true(r)) return vbool(1);
        if (meth[0] == 'a' && meth[1] == 'l' && !vis_true(r)) return vbool(0);
        if (meth[0] == 'f' && vis_true(r)) return w->items[i];
    }
    if (meth[0] == 'f') return vnil();
    return vbool(meth[1] == 'l' ? 1 : 0);
}
BFN Val vpos(Val v, Val x) {
    Vec *w = vvec_of(v);
    for (long i = 0; i < w->len; i++) if (veq(w->items[i], x)) return vint(i);
    return vnil();
}

#define BRT_VDFR_MAX 1024
BTLS Vec *vdfr[BRT_VDFR_MAX];
BTLS long vdfsp;
BFN void vdfpush(void) {
    if (vdfsp >= BRT_VDFR_MAX) { vraise("defer nesting too deep"); }
    vdfr[vdfsp++] = NULL;
}
BFN void vdfadd(Val clo) {
    if (vdfsp <= 0) { vraise("defer outside a function"); }
    if (!vdfr[vdfsp - 1]) { vdfr[vdfsp - 1] = vvec(); }
    vec_push(vdfr[vdfsp - 1], clo);
}

BFN void vdfreset(long base) {
    while (vdfsp > base) {
        Vec *f = vdfr[--vdfsp];
        if (!f) continue;
        for (long i = f->len - 1; i >= 0; --i) {
            Val r = vcall_any(f->items[i], vvec());
            (void)r;
        }
    }
}
static BTLS Val vsortkey_fn;
static int vsortby_q(const void *pa, const void *pb) {
    Vec *one = vvec();
    vec_push(one, *(Val *)pa);
    Val ka = vcall_any(vsortkey_fn, one);
    one->len = 0;
    vec_push(one, *(Val *)pb);
    Val kb = vcall_any(vsortkey_fn, one);
    int r = vcmp(ka, kb);
    return r;
}
BFN Val vsort_by(Val v, Val fn) {
    Vec *w = vvec_of(v);
    vsortkey_fn = fn;
    if (w->len > 1) qsort(w->items, (size_t)w->len, sizeof(Val), vsortby_q);
    return v;
}
#define VARG(a, i) ((a)->len > (i) ? (a)->items[(i)] : vnil())
BFN Val vbuiltin(Val obj, const char *meth, Vec *a) {
    if (obj.tag == V_STR) {
        if (!strcmp(meth, "split")) { if (VARG(a, 0).tag == V_STR && !VARG(a, 0).as.str[0]) { vraise("empty separator"); } return vsplit(obj, VARG(a, 0)); }
        if (!strcmp(meth, "lines")) return vlines(obj);
        if (!strcmp(meth, "trim")) return vtrim(obj);
        if (!strcmp(meth, "lower")) return vcase(obj, 0);
        if (!strcmp(meth, "upper")) return vcase(obj, 1);
        if (!strcmp(meth, "starts_with")) return vbool(vaffix(obj, VARG(a, 0), 1, 0));
        if (!strcmp(meth, "ends_with")) return vbool(vaffix(obj, VARG(a, 0), 0, 1));
        if (!strcmp(meth, "contains")) return vbool(vaffix(obj, VARG(a, 0), 0, 0));
        if (!strcmp(meth, "parse_int")) return vparse_int(obj);
        if (!strcmp(meth, "replace")) return vreplace(obj, VARG(a, 0), VARG(a, 1));
        if (!strcmp(meth, "index_of")) return vindex_of(obj, VARG(a, 0));
        if (!strcmp(meth, "repeat")) return vrepeat(obj, VARG(a, 0));
        if (!strcmp(meth, "split_once")) return vsplit_once(obj, VARG(a, 0));
        if (!strcmp(meth, "copy")) return obj;
        if (!strcmp(meth, "chars")) return vchars(obj);
        if (!strcmp(meth, "parse_float")) return vparse_float(obj);
        if (!strcmp(meth, "slice")) return vstr_slice(obj, VARG(a, 0), VARG(a, 1));
    }
    if (obj.tag == V_VEC) {
        if (!strcmp(meth, "join")) return vjoin(obj, VARG(a, 0));
        if (!strcmp(meth, "push")) return vpush(obj, VARG(a, 0));
        if (!strcmp(meth, "pop")) return vpop(obj);
        if (!strcmp(meth, "first")) return vfirst(obj);
        if (!strcmp(meth, "last")) return vlast(obj);
        if (!strcmp(meth, "sort")) return vsort(obj);
        if (!strcmp(meth, "rev")) return vrev(obj);
        if (!strcmp(meth, "ins")) return vins(obj, VARG(a, 0), VARG(a, 1));
        if (!strcmp(meth, "del")) return vdel_at(obj, VARG(a, 0));
        if (!strcmp(meth, "slice")) return vslice(obj, VARG(a, 0), VARG(a, 1));
        if (!strcmp(meth, "sum")) return vsum(obj);
        if (!strcmp(meth, "min")) return vmin(obj);
        if (!strcmp(meth, "max")) return vmax(obj);
        if (!strcmp(meth, "enumerate")) return venum(obj);
        if (!strcmp(meth, "copy")) return vcopy(obj);
        if (!strcmp(meth, "zip")) return vzip(obj, VARG(a, 0));
        if (!strcmp(meth, "chunks")) return vchunks(obj, VARG(a, 0));
        if (!strcmp(meth, "slice")) return vslice(obj, VARG(a, 0), VARG(a, 1));
        if (!strcmp(meth, "pos")) return vpos(obj, VARG(a, 0));
    }
    if (obj.tag == V_STRUCT) {
        if (!strcmp(meth, "get")) return vmap_getv(obj, VARG(a, 0));
        if (!strcmp(meth, "has")) return vmap_has(obj, VARG(a, 0));
        if (!strcmp(meth, "keys")) return vmap_keys(obj);
        if (!strcmp(meth, "del")) return vmap_del(obj, VARG(a, 0));
        if (!strcmp(meth, "set")) return vmap_setv(obj, VARG(a, 0), VARG(a, 1));
        if (!strcmp(meth, "items")) return vmap_items(obj);
        if (!strcmp(meth, "vals")) return vmap_vals(obj);
        if (!strcmp(meth, "copy")) return vcopy(obj);
        if (!strcmp(meth, "get_or")) return vmap_get_or(obj, VARG(a, 0), VARG(a, 1));
    }
    vraisef("no method %s\n", meth);
}

typedef struct BTask BTask;
struct BTask {
    Val clo;
    Val result;
    int err;
    int started;   
    BTask *next;
#if defined(_WIN32)
    HANDLE h;
#else
    pthread_t t;
#endif
};
static BTask *btasks;
#if defined(_WIN32)
static CRITICAL_SECTION btlock;
static int btlock_init;
static void btask_lock(void) {
    if (!btlock_init) { InitializeCriticalSection(&btlock); btlock_init = 1; }
    EnterCriticalSection(&btlock);
}
static void btask_unlock(void) { LeaveCriticalSection(&btlock); }
static void btask_yield(void) { Sleep(0); }
#else
#include <sched.h>
static pthread_mutex_t btlock = PTHREAD_MUTEX_INITIALIZER;
static void btask_lock(void) { pthread_mutex_lock(&btlock); }
static void btask_unlock(void) { pthread_mutex_unlock(&btlock); }
static void btask_yield(void) { sched_yield(); }
#endif

BFN Val vcall_any(Val fn, Vec *a);

#if defined(_WIN32)
static DWORD WINAPI btask_run(void *p) {
#else

BFN Val verr_own(Val v) {
    if (v.tag != V_TAG || strcmp(v.as.tv.tag, "err")) return v;
    Vec *a = vvec();
    for (long i = 0; i < v.as.tv.args->len; i++) vec_push(a, v.as.tv.args->items[i]);
    return vtagv("err", a);
}
static void *btask_run(void *p) {
#endif
    BTask *t = (BTask *)p;
    jmp_buf jb;
    vjmp = &jb;
    if (setjmp(jb)) {
        t->err = 1;
        t->result = verr_own(vunwind);
    } else {
        Vec *a = vvec();
        t->result = vcall_any(t->clo, a);
        if (t->result.tag == V_TAG && !strcmp(t->result.as.tv.tag, "err")) t->err = 1;
    }
#if defined(_WIN32)
    return 0;
#else
    return NULL;
#endif
}

BFN void vspawn(Val clo) {
    if (clo.tag != V_TAG || strcmp(clo.as.tv.tag, "closure") || clo.as.tv.args->len != 2) {
        vraise("spawn wants closure");
    }
    
    BTask *t = (BTask *)calloc(1, sizeof(BTask));
    if (!t) { vraise("spawn failed: out of memory"); }
    t->clo = clo;
    btask_lock();
    t->next = btasks;
    btasks = t;
    btask_unlock();
    int created = 0;
#if defined(_WIN32)
    t->h = CreateThread(NULL, 0, btask_run, t, 0, NULL);
    created = (t->h != NULL);
#else
    created = (pthread_create(&t->t, NULL, btask_run, t) == 0);
#endif
    if (!created) {
        
        btask_lock();
        BTask **pp = &btasks;
        while (*pp && *pp != t) pp = &(*pp)->next;
        if (*pp) *pp = t->next;
        btask_unlock();
        free(t);
        vraise("spawn failed");
    }
    btask_lock();
    t->started = 1;
    btask_unlock();
}

BFN void vjoin_all(void) {
    for (;;) {
        btask_lock();
        BTask *list = btasks;
        btasks = NULL;
        btask_unlock();
        if (!list) return;
        int err = 0;
        Val errv = vnil();
        while (list) {
            BTask *nx = list->next;
            
            btask_lock();
            while (list->started == 0) {
                btask_unlock();
                btask_yield();
                btask_lock();
            }
            btask_unlock();
#if defined(_WIN32)
            WaitForSingleObject(list->h, INFINITE);
            CloseHandle(list->h);
#else
            pthread_join(list->t, NULL);
#endif
            if (list->err && !err) { err = 1; errv = list->result; }
            free(list);
            list = nx;
        }
        if (err) { vunwind = errv; vunwind_do(); }
    }
}

#endif
