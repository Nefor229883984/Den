# Bench draft: brat-lb (lb.py) TCP echo probe

## What was measured
`balancer\lb.py` (TCP round-robin, active health-check 2s) in front of
two in-process Python echo backends (`from:B1:` / `from:B2:`, same handler shape
as `test_lb.py`: recv 4096 -> sendall -> close). Probe `bench\bench.py`
(stdlib only: threads x sequential TCP round-trips, connect + send/shutdown/read-EOF)
ran against the LB listen port on 127.0.0.1. Wall-clock rps, p50/p99 connect ms
and roundtrip ms, error count. No wrk/nginx on this box — bench.py numbers only.

## Exact commands
```powershell
python "C:\Users\1F1C~1\AppData\Local\Temp\opencode\run_bench_b4.py"
# which spawns 2 echo backends + lb.py, then runs (LB port this run: 58272):
python bench\bench.py --target 127.0.0.1:58272 --conns 2 --reqs 20
python bench\bench.py --target 127.0.0.1:58272 --conns 16 --reqs 25
python balancer\test_lb.py
```

## Results (real, 2026-10-01 evening, single run each)
| conns x reqs | total | elapsed_s | ok | errors | rps | conn p50/p99 ms | roundtrip p50/p99 ms |
|---|---|---|---|---|---|---|---|
| 2 x 20 | 40 | 0.051 | 40 | 0 | 778.7 | 0.19 / 12.36 | 1.38 / 3.34 |
| 16 x 25 | 400 | 0.841 | 400 | 0 | 475.4 | 0.24 / 11.09 | 17.12 / 309.04 |

Raw tails:
```
backends: 58270 58271 lb: 58272
target=127.0.0.1:58272 conns=2 reqs_per_conn=20 total=40
elapsed_s=0.051 ok=40 errors=0 rps=778.7
connect_ms p50=0.19 p99=12.36 n=40
roundtrip_ms p50=1.38 p99=3.34 n=40
target=127.0.0.1:58272 conns=16 reqs_per_conn=25 total=400
elapsed_s=0.841 ok=400 errors=0 rps=475.4
connect_ms p50=0.24 p99=11.09 n=400
roundtrip_ms p50=17.12 p99=309.04 n=400
BENCH_VERIFY_DONE
```
`test_lb.py` after: ALL GREEN (round-robin ok, failover ok, metrics ok, logs ok: 10 routed, all JSON).

## Hardware
AMD Athlon X4 840 Quad Core Processor, Windows 10, Python 3.14.7 (`python --version` this session).

## File inventory (2026-10-01)
compiler/brat.py — lexer/parser/interpreter core (BRAT language front-end + runtime).
compiler/front2.py — second front-end variant (lexer/parser mirror of brat.py).
compiler/cback.py — C backend (emits C from BRAT AST; stub-level, drops some bodies).
compiler/own.py — ownership/borrow checker (ref/borrow/mut rules, leak detection).
compiler/llvm_spike.py — LLVM probe: prints NO_LLVM + expected IR (no llvmlite on host).
compiler/LLVM_NOTES.md — LLVM status notes: planned construct map, missing toolchain.
balancer/lb.py — live TCP round-robin LB: health-check 2s, JSONL log, /metrics.
balancer/algos.py — pick algorithms: RoundRobin / LeastConn / IpHash / EwmaPicker.
balancer/http_parse.py — stdlib HTTP/1.1 request parser on raw bytes.
balancer/otel.py — telemetry: sampling, batcher, OTLP convert, Prometheus extras.
balancer/test_lb.py — LB regression: 6 hits both nodes, kill one, 3 hits survivor, metrics+logs.
balancer/test_algos.py — algo asserts (round-robin order, least-conn avoids busy node).
balancer/test_http.py — HTTP parser asserts (GET parse, keep-alive, routing).
balancer/test_otel.py — OTel asserts (batch flush by count, sampling, OTLP mapping).
examples/hello.brat — minimal example: host ref, log.info, add(40,2), metric.counter.
examples/balancer.brat — LB policy example: pick_round_robin/proxy/fallback loop.
examples/control.brat — control-flow example: match/for over status codes.
examples/own_good.brat — ownership-passing example (should check clean).
examples/own_bad.brat — ownership-violation example (leak/undeclared var, should fail).
bench/bench.py — stdlib TCP load probe (threads x sequential round-trips, rps/p50/p99).
bench/HABR_DRAFT.md — this file: repro commands + numbers + inventory + limits.

## Honest limits
- Loopback only; no LAN/WAN, no TLS, no HTTP — raw TCP echo through a threaded Python LB (GIL-bound).
- Echo backends are trivial (`recv`+`sendall`); real upstreams would be slower.
- Single run per point, ephemeral ports, small concurrency (2 / 16 conns); p99 connect outliers (~11-12 ms) are first-accept/backlog noise; 16-conn roundtrip p99 (309.04 ms) is GIL/thread-scheduling tail on this 4-core box, not a steady-state claim.
- No LLVM codegen (no llvmlite, no lli/clang/gcc on PATH — see LLVM_NOTES.md); no TLS/H2/io_uring.
- No wrk/nginx/HAProxy comparison on this machine; claims stop at bench.py numbers above.

## Production push 2026-10-01 evening (median of 3, `bench/rounds.py`)

- light 2conns x 20reqs: MEDIAN rps=799.4 p50=1.60ms p99=2.95ms errors=0
- heavy 16conns x 25reqs: MEDIAN rps=934.9 p50=16.30ms p99=19.76ms errors=0
- Stable across rounds (709-803 / 932-936 rps), 0 errors everywhere.

New since morning:
- `compiler/llvm_run.py` — REAL LLVM JIT via llvmlite 0.50 (pip-installed today): `add(40,2)=42 fib(20)=6765` executed natively. `llvm_spike.py` NO_LLVM verdict is outdated, kept for history.
- `compiler/cback2.py` — full C99 emitter (if/else both shapes, while, fn, vec+len, strings), `test_cback2.py` green. No C compiler on host, .c saved under Temp\opencode.
- `compiler/brat.py` — match/for/vec/len merged into the single runtime; `front2.py` is history.
- `balancer/lb.py` — graceful shutdown (drain ≤5s), `--max-conns` 512, `--config` JSON, `lb_inflight` gauge.
- `balancer/sni.py` — ClientHello SNI sniff, wildcard+exact routing table, 200-buffer fuzz no-raise.
- `balancer/mkcert.py` — pure-stdlib RSA-2048 + X.509 SAN certs (~0.8s); `tls_front.py` TLS 1.2+ termination with sni in logs; `test_tls.py` green.
- `balancer/lb_l7.py` — keep-alive: 100 reqs/conn, per-request trace_id, 25 asserts green.
- `balancer/pool2.py` — 4 algo pools wired to algos.py pickers, race-clean.

Still honestly missing: HTTP/2, io_uring (Windows host — Linux roadmap), wrk/nginx comparison, C compile+run proof, OTLP binary export, keep-alive backend reuse.
