import socket
import statistics
import subprocess
import sys
import threading

import os as _o
_HERE = _o.path.dirname(_o.path.abspath(__file__))
BENCH = _o.path.join(_HERE, 'bench.py')
LB = _o.path.join(_HERE, '..', 'balancer', 'engine', 'lb.py')


def free_port():
    s = socket.socket()
    s.bind(('127.0.0.1', 0))
    p = s.getsockname()[1]
    s.close()
    return p


def echo_server(port, stop):
    srv = socket.socket()
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(('127.0.0.1', port))
    srv.listen(64)
    srv.settimeout(0.5)

    def handle(c):
        try:
            c.settimeout(3.0)
            data = c.recv(65536)
            if data:
                c.sendall(data)
        except OSError:
            pass
        finally:
            try:
                c.close()
            except OSError:
                pass

    def loop():
        while not stop.is_set():
            try:
                c, _ = srv.accept()
            except socket.timeout:
                continue
            threading.Thread(target=handle, args=(c,), daemon=True).start()
        srv.close()

    threading.Thread(target=loop, daemon=True).start()


def one_round(lp, conns, reqs):
    p = subprocess.run(
        [sys.executable, BENCH, '--target', '127.0.0.1:%d' % lp,
         '--conns', str(conns), '--reqs', str(reqs)],
        capture_output=True, text=True, timeout=120)
    assert p.returncode == 0, p.stdout + p.stderr
    vals = {}
    for line in p.stdout.splitlines():
        if '=' not in line:
            continue
        for tok in line.split():
            if '=' in tok:
                k, v = tok.split('=', 1)
                try:
                    vals[k] = float(v)
                except ValueError:
                    pass
    return vals


def main():
    conns, reqs, rounds = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3]) if len(sys.argv) > 3 else 3
    b1, b2, lp = free_port(), free_port(), free_port()
    s1, s2 = threading.Event(), threading.Event()
    echo_server(b1, s1)
    echo_server(b2, s2)
    lb = subprocess.Popen(
        [sys.executable, LB, '--listen', '127.0.0.1:%d' % lp,
         '--up', '127.0.0.1:%d,127.0.0.1:%d' % (b1, b2)],
        stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
    try:
        for _ in range(50):
            try:
                socket.create_connection(('127.0.0.1', lp), timeout=1).close()
                break
            except OSError:
                __import__('time').sleep(0.1)
        acc = {}
        for i in range(rounds):
            r = one_round(lp, conns, reqs)
            for k, v in r.items():
                acc.setdefault(k, []).append(v)
            print('round %d: rps=%.1f p50=%.2f p99=%.2f' % (i + 1, r.get('rps', 0), r.get('p50', 0), r.get('p99', 0)))
        med = {k: statistics.median(v) for k, v in acc.items()}
        print('MEDIAN rounds=%d: rps=%.1f p50=%.2f p99=%.2f errors=%.0f' % (
            rounds, med.get('rps', 0), med.get('p50', 0),
            med.get('p99', 0), med.get('errors', 0)))
    finally:
        lb.terminate()
        lb.wait(timeout=10)
        s1.set()
        s2.set()


if __name__ == '__main__':
    main()
