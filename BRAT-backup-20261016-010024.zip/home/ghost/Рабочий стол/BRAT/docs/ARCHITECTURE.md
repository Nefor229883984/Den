# ARCHITECTURE — backend and roadmap options

Status: draft for discussion. Nothing here is implemented; each option names
what it costs and what it buys, and the recommendation is argued, not asserted.

This document exists because two questions keep coming back: *when does Python
go away*, and *how does BRAT actually beat Rust*. Both need an answer that is
not "rewrite it".

---

## 1. Where Python actually is today

The single most important fact, and it is easy to miss: **Python is not in the
runtime path.**

```
brat build prog.brat ──► codegen_c.py ──► prog.c ──► zig cc -O2 ──► ./prog
        (Python)          (Python)                      (build time)   (no Python)
```

The emitted binary links only `crt.h` and libc. `brat run` uses the interpreter,
so Python is needed for *running*; `brat build` needs Python once, at build
time, and never again at run time.

So "get rid of Python" splits into three different projects, and they are worth
vastly different amounts:

| # | Question | Status |
|---|---|---|
| Q1 | Can a BRAT program ship without a Python install on the target machine? | **Already yes** — `brat build` output is a plain native binary. |
| Q2 | Can the *language toolchain* (checker, emitter, CLI) run without Python? | No. Requires self-hosting. |
| Q3 | Is the Python path fast? | Irrelevant to shipped programs; matters only for `brat run`. |

Any claim that "BRAT needs Python" is wrong for Q1 and right for Q2. The
roadmap below therefore treats Q2 — self-hosting — as the goal, not as a
precondition.

---

## 2. What must be fixed no matter which backend is chosen

These are correctness holes found by this audit. They are backend-independent
and must not be postponed behind a rewrite.

### 2.1 `vraise` via `longjmp` is unsafe at `-O2` — **confirmed by measurement**

Reproducer: a program that starts more threads than the process can create
(~250 on this box, 2 GB address-space cap, 8 MB default thread stacks).

```
$ zig cc -O0 … ; ./prog   →  unhandled: ('err', 'spawn failed')   exit=1
$ zig cc -O2 … ; ./prog   →  Segmentation fault                     exit=139
```

The fault is a single fixed instruction, a write to address `0x10`, and it
moves when unrelated code around it changes — i.e. it is the longjmp path
itself, not the caller.

`vraise` (`crt.h:721`) does `longjmp(*vjmp, 1)`. The setjmp that receives it
lives in generated `main`, and the frames between it and `vraise` hold
non-`volatile` locals that were modified after `setjmp` returned. That is
undefined behaviour by the letter of the C standard, and the optimiser is
entitled to do exactly this.

The repo already knows this shape: commit `b44d069` reverted a C-side `$type`
fix because `vraise` through `longjmp` broke `-O2`, and `25d1807` replaced it
with a design that needs no longjmp. The lesson was recorded for one call site
and not applied to the runtime as a whole.

**Fix direction:** make unwinding a return value, not a longjmp. Every
`vraise`-capable function already returns `Val`; an error can travel as an
`("err", reason)` result that callers propagate, which is also what the
language's own `Ok`/`Err` discipline says. This is the largest single piece of
work in the runtime and it is prerequisite to trusting optimisation.

### 2.2 Spawn has no resource limit — **this is what froze the machine**

`vspawn` (`crt.h:2292`) calls `pthread_create` per `spawn` and never caps
concurrency. Each thread reserves an 8 MB stack. Measured:

| spawns | interpreter | native |
|---|---|---|
| 200 | exit 0 | exit 0 |
| 300 | exit 0 | **segfault** |
| 1000 | exit 0 | **segfault** |

300 threads is not a pathological program; it is an ordinary server. On a
3.7 GB machine the address space is gone at roughly 450 threads, and the
intervening swap thrash is what made the box unresponsive — not a crash.

**Fix direction:** a bounded worker pool with a task queue, matching the
interpreter's semantics. Thread count must be a property of the runtime, not of
the program. Both backends have to agree, because parity is the contract.

### 2.3 Backend parity gaps found in this audit

Fixed in this session, all pinned in `test_diff.py`:

- `read_file`/`write_file` built an `err` tag with **no field**; a `match` arm
  `Err(reason)` binds that field, so the interpreter raised `IndexError` and
  the native backend hung.
- An empty file and a directory both produced an `ok` tag with **no field**
  natively — same out-of-bounds bind, same hang.
- The C sandbox accepted `sub/../../x` because `vconfine` compared a path that
  still contained the `..`. Native wrote outside the program directory while
  the interpreter refused.
- `vconfine` returned a pointer to a stack local.

### 2.4 No reclamation at all — **the deepest problem, measured**

The native runtime has **no mechanism to free a value**: no refcount, no
`vfree`, nothing (`grep` for `vfree|refcount|vdel|vrelease` over `crt.h`
returns nothing but `del`-the-map-method). `vadd`'s string path is *correct* —
`malloc`, two `memcpy`, NUL — but the string it returns is never released, so
`s = s + "x"` in a loop leaks.

```
$ ulimit -v 32768 ; ./prog     # n = 8000 concat steps
   -O0:  ('err', 'out of memory')     exit 1
   -O2:  Segmentation fault           exit 139
```

n = 8000 leaks exactly 8000²/2 = 32 MB, which is the observed address-space
threshold to the megabyte. Extrapolated, n = 100 000 leaks **5 GB** — on a
3.7 GB machine that is what makes the box stop responding. Both the segfault
and the slowness are this one design gap.

Per-backend comparison of the two failure modes is the important part:

- The **interpreter** does not have this bug: CPython's allocator reclaims the
  intermediate string immediately.
- The **native** backend accumulates all of them.

So the two backends do not merely differ in speed, they differ in *whether the
program terminates at all*. This is a parity violation in the strongest sense,
and it is why `str_concat` appears as `172.9 s` in §6 rather than as a failure.

**Fix direction:** reference counting on `Val`, or real ownership transfer
driven by the existing `borrow.py` checker, which already knows when a value
dies. Either is a large change and both backends must agree, because a program
that OOMs natively must OOM (or not) identically in the interpreter.

Note that this also means `brat build` output is not yet trustworthy for
long-running string-building work — a log assembler, a template renderer, a
CSV builder all hit it. It is not an exotic case.

### 2.5 Interpreter recursion limit — parity gap

`bench_recur(2000)` — `r(n) = n + r(n-1)`:

```
interpreter: dies   (Python default recursion limit, ~1000 frames)
native:      exit 0
```

The interpreter cannot run a recursion the native backend runs fine. Python's
default `sys.setrecursionlimit` is the binding constraint, not BRAT semantics.
Either BRAT deepens it for the interpreter, or the language documents a
recursion budget; right now the two backends disagree.

### 2.6 `vraise` via `longjmp` is undefined at `-O2` — **proven, three triggers**

Originally filed as the §2.1 hypothesis; it is now confirmed with three
independent triggers, all of which segfault at `-O2` and all of which work at
`-O0`:

| Trigger | Mechanism |
|---|---|
| `spawn` exhausts the thread limit | `pthread_create` fails → `vraise` |
| string concat exhausts memory | `malloc` fails → `vraise` |
| (fixed earlier) empty `ok` tag | match binds a field that is not there |

The `-O0`/`-O2` comparison for the second trigger is the cleanest evidence:
same source, same `ulimit -v 32768`, `-O0` prints `('err', 'out of memory')`
and `-O2` segfaults. The faulting instruction is stable and moves only when
unrelated code around it changes, which is the signature of the longjmp path
rather than of any caller.

`vraise` (`crt.h:721`) does `longjmp(*vjmp, 1)`. The receiving `setjmp` lives
in generated `main`, and frames between it and `vraise` hold non-`volatile`
locals modified after `setjmp` returned — undefined behaviour by the letter of
the C standard, and the optimiser is entitled to do exactly this.

The repo already knew this shape: `b44d069` reverted a C-side `$type` fix
because `vraise` through `longjmp` broke `-O2`, and `25d1807` replaced it with
a design that needs no longjmp. The lesson was recorded for one call site and
never applied to the runtime as a whole.

**This is now the single highest-priority bug in the runtime**, ahead of §2.4,
because §2.4's failure mode *routes through it*: an OOM that should produce
`('err', 'out of memory')` produces a segfault instead, so the runtime cannot
even report its own resource exhaustion.

**Fix direction:** make unwinding a return value, not a longjmp. Every
`vraise`-capable function already returns `Val`; an error can travel as an
`("err", reason)` result the caller propagates, which is also what the
language's own `Ok`/`Err` discipline says. Prerequisite to trusting `-O2` at
all, and prerequisite to self-hosting (§4 step 4).


---

## 3. Backend options

### Option A — keep and harden the C emitter *(recommended now)*

What it is: `codegen_c.py` emits C99, `zig cc` compiles it. Already works,
already fast enough to be compared with C.

- **Buys:** nothing to rebuild. Performance is C performance. The single
  external dependency (`zig`) is a build-time one, and it is drop-in
  replaceable with `cc`/`clang` because the output is plain C99.
- **Costs:** the C runtime is hand-written and hand-audited; the two bugs above
  live there. Every language feature must be written twice, once in
  `crt.h` and once in `runtime.py`.
- **Verdict:** this is the only option that improves the product *this week*.
  Options B–D are additive on top of it, not replacements for it.

### Option B — emit LLVM IR text instead of C

- **Buys:** LLVM's optimiser and passes instead of `crt.h` doing it by hand;
  no dependence on a C toolchain's header quirks; the emitted IR is inspectable
  and diffable, which is a real parity-testing advantage.
- **Costs:** the entire runtime has to be re-expressed as LLVM IR or as
  bitcode, or linked against a compiled runtime — i.e. the hand-audited C
  runtime does not disappear, it becomes a build artefact. Error unwinding
  still has to be solved first (§2.1); LLVM does not make longjmp safe.
- **Verdict:** premature. It rewrites the layer §2 says is broken without
  fixing §2.

### Option C — a purpose-built backend (own IR, own codegen)

What the user asked to think about: a fundamentally new architecture rather
than borrowing LLVM's.

- **Buys:** BRAT's ownership model is a genuine advantage here. There is no GC
  and no borrow checker, so the compiler *knows* when a value dies. A backend
  that exploits that can elide bounds checks on `Vec` indexing where the
  length is statically known, and avoid refcount traffic entirely — which is
  exactly where a naive C emitter leaves performance on the table. This is the
  one option that could plausibly beat Rust on BRAT's own terms rather than
  match it.
- **Costs:** a register allocator, an instruction selector, a backend per
  target, and a debugging experience worse than C's until it matures. Years.
- **Verdict:** the destination, not the next step. It should be taken *after*
  the language has a self-hosted frontend, so the backend is written in BRAT
  rather than in Python.

### Option D — self-host the compiler in BRAT *(the real "kill Python" step)*

- What it is: rewrite `borrow.py`, `parser.py`, `typer.py`, `codegen_c.py` in
  BRAT. The first working target is the C emitter, because the C backend
  already exists and `brat build` already produces a native binary — so a
  self-hosted emitter still emits C, and the bootstrapping loop closes.
- **Buys:** Q2 answered; the language stops depending on anything outside
  itself; and BRAT gets its first large, real application, which is the most
  reliable way to find the language's actual gaps.
- **Costs:** ~5000 lines of compiler to port, and the parity contract means
  every ported module must be byte-identical in its diagnostics.
- **Verdict:** the right long-term goal. It depends on §2.1, because a
  self-hosted compiler that segfaults under `-O2` is not a foundation.

---

## 4. Recommended order

1. **Fix §2.1 (unwinding without longjmp) and §2.2 (bounded spawn).** Neither
   is optional; both are measurable; both are pinned by tests already.
2. **Harden the C emitter** (Option A): drop the `zig` dependency to an
   optional one, since output is plain C99.
3. **Self-host** (Option D), starting with the emitter, targeting the existing
   C backend.
4. **Only then** consider Option C, using BRAT itself to write it.

Sequencing note: 1 → 2 → 3 is strictly ordered. Starting 3 before 1 means
writing a compiler on a runtime whose error path is undefined at `-O2`.

---

## 5. On "0 hallucinations"

Not a vague aspiration; it is three concrete properties, all already testable:

1. **No silent failure.** Every failure is impossible, reported, or handled —
   never swallowed into a default that looks like success. The WAF in
   `balancer/` still fails open (`except Exception: return ALLOW`) and is the
   clearest remaining violation.
2. **Determinism across backends.** `test_diff.py` compares bytes, not
   vibes. The filesystem-sandbox cases added in this audit are the model: the
   absolute paths in error messages are machine-dependent, so what is compared
   is the *class* of the error, not the string.
3. **No unreachable code.** A reader must not have to prove that a branch is
   dead before reasoning about a module.

---

## 6. On performance

`brat build` output is C compiled at `-O2`; it is within noise of idiomatic C
today. Beating Rust needs the compiler to *use* the ownership information
rather than merely survive it:

- bounds-check elision on `Vec` indexing where the length is known,
- no refcount traffic where ownership is provably linear,
- no unwinding machinery on the hot path (this is §2.6 again — the longjmp is
  not just a correctness bug, it is a pessimisation, because it forces
  `setjmp` state into every call frame).

The ownership model is the actual competitive claim, and it is the one thing
Rust cannot copy without giving up borrow checking.

### 6.1 Measured numbers, native vs interpreter

Single run each, `n = 100 000` (except as noted), checksummed so the work
cannot be optimised away. Best of 3 for the short cases.

| case | native | interpreter | note |
|---|---|---|---|
| `int_loop` | 0.0027 s | — | arithmetic, no allocation |
| `recur(2000)` | 0.0015 s | **fails** | interpreter hits Python recursion limit |
| `vec_push` | 0.0185 s | — | |
| `map_iter` | 0.0403 s | — | 20k-key map, iterate keys |
| `map_intkey` | 0.0542 s | — | 20k i64 keys, insert + get |
| `map_churn` | 0.1268 s | — | 100k set/has over 512 live keys |
| `str_split` | 0.1149 s | — | 100k splits of an 8-char string |
| `map_strint` | 0.1978 s | — | 20k string keys, insert + get |
| `str_concat` | **172.9 s** | faster | §2.4 — the leak, not the algorithm |

Whole-program comparison (7 cases, `n = 20000`): **native 0.075 s vs
interpreter 3.699 s — 49×**.

Reading of these numbers:

- **`map` is already competitive.** It is open addressing over an
  insertion-ordered `keys`/`vals` pair, FNV-1a on keys, 75 % load, tombstones
  honoured. `map_intkey` at 20k insert+get in 54 ms and `map_iter` at 40 ms are
  within a small factor of hand-written C. There is no low-hanging fruit here
  and it should not be rewritten.
- **Integer work is fine** — 0.0027 s for 100k arithmetic iterations.
- **One case destroys the whole profile.** `str_concat` is 2300× the cost of
  every other case combined, and it is not algorithmic: the C is `malloc` + two
  `memcpy`. It is §2.4. Fix that and the profile becomes defensible.
- The 49× whole-program figure is dominated by the interpreter's constant
  overhead, not by anything the native backend does badly.

