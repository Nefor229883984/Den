# Execution plan: the two heavy items

Written after the 2026-10-14 night session so the next run starts executing
instead of re-deriving. Each item states the failure, the chosen fix, why the
cheaper alternative was rejected, and how to know it worked. Measured numbers
only — every figure below was observed, not estimated.

---

## Item 1 — the native backend leaks every string (§2.4)

### The failure, measured

`s = s + "x"` in a loop:

| n | address space consumed |
|---|---|
| 8000 | 32 MB (8000²/2) — matches `ulimit -v` threshold to the megabyte |
| 100 000 | ≈ 5 GB → 172 s wall, machine unresponsive on 3.7 GB RAM |

No reclamation exists at all: `grep -n "vfree\|refcount\|vdrop\|vrelease"`
over `crt.h` returns nothing but `vdel_at` (a map method). The interpreter is
immune because CPython reclaims the intermediate immediately, so the two
backends differ not in speed but in *whether the program finishes*.

### Fix chosen — URC-style deferred reference counting

Naive RC costs an increment on every pointer assignment, which is why it is
usually a net loss for tight loops. Blackburn & McKinley's *Ulterior Reference
Counting* (OOPSLA 2003, `cs.utexas.edu/~mckinley/papers/urc-oopsla-2003.pdf`)
removes that cost by **deferring and coalescing** count updates: they are applied
lazily at points where the compiler can prove the old value is dead, rather than
on every store. That is exactly the profile BRAT needs — the leak is on the hot
path (`+` on strings), so the fix must not add a branch to it.

Shape:

1. `Val` gains a `unsigned long rc` for heap-backed values (strings, vecs, maps,
   tags). Only four kinds are refcounted; ints, floats, bools and nil stay
   immediate.
2. `vstr`, `vstrn`, `vvec`, `vmap`, `vtagv` start with `rc = 1`.
3. Assignment and parameter passing go through `vreten`/`vrel`: retain before a
   new reference is stored, release when one is overwritten.
4. Updates are **coalesced**: in `a = a + b`, the release of the old `a` is
   folded into the same operation rather than being a separate write.
5. Cycle collection is out of scope for v0.1 — document the limitation rather
   than shipping a partial collector. BRAT's ownership model already forbids the
   aliasing patterns that create the common cycles, so this is a real gap, not
   an excuse.

### Rejected alternatives

- **Free the LHS of `+` unconditionally.** Unsafe: `let a = x; x = x + "s"`
  leaves `a` dangling. BRAT permits that aliasing today.
- **Arena per statement.** Does not fix the loop case — the arena grows with the
  loop.
- **Tracing GC.** Introduces pauses, which is the one property the ownership
  model exists to avoid. Also needs a write barrier on every container write.

### Verification

1. `s = s + "x"` at n = 8000 must run under `ulimit -v 32768` — the threshold
   that currently fits to the megabyte.
2. n = 100 000 must finish in seconds, not 172 s, with flat RSS.
3. `test_diff` must stay at `diffs: 0` — this is the gate that matters, because
   every string operation changes byte output if a lifetime is wrong.

### Ordering constraint

Do item 2 (unwinding) first, or at least first. The leak's failure mode routes
through the error path, and that path is currently the least trustworthy thing in
the runtime. Fixing the leak before the error path means debugging blind.

---

## Item 2 — `vraise` through `longjmp` is undefined at `-O2` (§2.6)

### The failure, measured

Three independent triggers, all segfaulting at `-O2` and all working at `-O0`:

| Trigger | Mechanism |
|---|---|
| `spawn` exhausts the thread limit | `pthread_create` fails → `vraise` |
| string concat exhausts memory | `malloc` fails → `vraise` |
| empty `ok` tag (fixed earlier) | match binds a field that is not there |

Cleanest evidence, same source and same `ulimit -v 32768`:
`-O0` prints `('err', 'out of memory')`, `-O2` segfaults at one stable
instruction that moves only when unrelated neighbouring code changes — the
signature of the longjmp path rather than any caller.

The standard's letter: `longjmp` out of a frame whose non-`volatile` locals were
modified after `setjmp` returned is undefined, and the optimiser is entitled to
do exactly this. `vraise` (`crt.h:721`) does `longjmp(*vjmp, 1)`; the receiving
`setjmp` is in generated `main`, and frames between hold such locals.

The repo already knew this shape: `b44d069` reverted a C-side `$type` fix
because `vraise` through `longjmp` broke `-O2`; `25d1807` replaced it with a
design needing no longjmp. The lesson was recorded for one call site and never
applied to the runtime.

### What is already done

- `vraise` is now **allocation-free**: thread-local slot + `vlit` + `vtagv_lit`,
  message copied into a thread-local buffer. This fixed "the runtime could not
  report its own out-of-memory" (commit `d31d3ca`).
- All runtime allocations are guarded (`a94bf25`).
- `verr_own` copies a task's error result into the task's own storage, so a
  worker's error survives the cross-thread read (`ced78cb`) — a regression the
  `test_native` suite caught.

### What remains

After the allocation-free change the `-O2` behaviour under a tight limit moved
from segfault to **hang** (not finished in 180 s at `ulimit -v 32768`;
completes and prints `len=8000` at 36 MB). Cause not found. Most likely
explanation, **not verified**: libc's own slow path when it cannot extend the
heap, retried once per loop iteration — which would make it a symptom of item 1
rather than a separate bug. Confirm or refute this first; it determines whether
item 2 is still needed at all.

### Fix if it is still needed

The language already has `Ok`/`Err`, so the C runtime should too: make unwinding
a **return value**, not a longjmp. Every `vraise`-capable function already
returns `Val`; errors travel as `("err", reason)` and callers propagate. This
removes `setjmp` state from every frame, which is also a performance win.

Scope warning: this touches every function that can raise — hundreds of call
sites. Do **not** attempt it as one change. Convert in this order, running
`test_diff` after each:

1. `vreadfile` / `vwritefile` — already return `('err', …)`, so the conversion
   is mechanical and the tests can see it immediately.
2. The string methods (`split`, `replace`, `repeat`, `upper`).
3. `map` and `vec` operations.
4. `spawn` / `join_all`, which need the error to reach the joining thread
   anyway.

---

## Item 3 — smaller, still real

| Item | Status |
|---|---|
| Shared containers are unsynchronised across threads; the interpreter survives only on the GIL. `vec_push` on a shared `Vec` from two threads loses writes (3/200 observed). | **Open.** LEDGER already defers it to "user responsibility, roadmap v0.2", which makes it silent rather than safe. |
| The interpreter is bounded by Python's `sys.setrecursionlimit`; the native backend is not. | **Fixed** (`ced78cb`) — the budget is now a language number and both backends agree to depth 100 000. |
| `test_diff.py`'s `spawn_in_closure` was a data race by construction and passed only by luck. | **Fixed** — made deterministic with a join per spawn. |

---

## Rule for continuing

One item, one commit, `test_diff` at `diffs: 0` after each. If a change cannot be
finished and verified in the session, leave the evidence for what was measured
and stop, rather than leaving a half-converted runtime behind.
